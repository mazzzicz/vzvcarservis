(function () {
    // Get script element to read config
    const scriptTag = document.currentScript || (function () {
        const scripts = document.getElementsByTagName('script');
        return scripts[scripts.length - 1];
    })();
    const projectId = scriptTag.getAttribute('data-id');
    const month = scriptTag.getAttribute('data-month');

    if (!projectId) {
        console.error('SliderImage Widget: data-id attribute missing.');
        return;
    }

    // Fetch widget data
    const scriptSrc = scriptTag.src;
    const baseUrl = scriptSrc.substring(0, scriptSrc.lastIndexOf('/'));
    let apiUrl = `${baseUrl}/api.php?action=get_widget_data&id=${projectId}`;

    if (month) {
        apiUrl += `&month=${month}`;
    }

    // Prevent browser cache
    apiUrl += `&_=${new Date().getTime()}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(res => {
            if (res.success && res.data.active) {
                renderWidget(res.data);
            } else if (res.message) {
                console.log('SliderImage Widget:', res.message);
            }
        })
        .catch(err => console.error('SliderImage Widget Error:', err));

    function renderWidget(data) {
        const config = data.widget_config || {};
        const sliderConfig = data.slider_config || { animation: 'fade', interval: 5000 };
        const slides = data.slides || [];

        let goToSlide, nextSlide, prevSlide;

        if (slides.length === 0) return;

        let targetSelector = config.target_selector || '#banner-placeholder';
        if (window.location.pathname.indexOf('demo.php') !== -1 || (!document.querySelector(targetSelector) && document.querySelector('#banner-placeholder'))) {
            targetSelector = '#banner-placeholder';
        }
        const targetEl = document.querySelector(targetSelector);

        if (!targetEl) {
            console.error(`SliderImage Widget: Target element "${targetSelector}" not found.`);
            return;
        }

        // Create elements
        const container = document.createElement('div');
        container.className = 'sliderimage-container';

        // Ensure container has height for absolute-positioned slides
        // We now use the first-slide + height:auto approach for natural height
        container.style.width = '100%';
        container.style.height = 'auto';

        // Dots Container
        const dotsContainer = document.createElement('div');
        dotsContainer.className = 'sliderimage-dots';

        // Styles
        const css = `
            .sliderimage-container { 
                position: relative; 
                width: 100%; 
                overflow: hidden; 
                line-height: 0;
                touch-action: pan-y;
                perspective: 1000px;
                margin-bottom: 20px;
            }
            .sliderimage-slide {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.8s ease;
                z-index: 0;
                backface-visibility: hidden;
                -webkit-backface-visibility: hidden;
            }
            .sliderimage-slide img {
                width: 100%;
                height: auto; /* Allow natural height */
                display: block;
            }
            .sliderimage-slide.active {
                opacity: 1;
                visibility: visible;
                z-index: 10;
            }
            /* When another slide is active, the first one stays as a ghost to keep height, 
               unless we are in a complex animation. For simple fade, it works perfectly. */
            .sliderimage-slide.first-slide:not(.active) {
                opacity: 0;
            }
            
            .sliderimage-slide.inactive-absolute {
                position: absolute;
                top: 0;
                left: 0;
                z-index: 1;
            }

            /* Dots */
            .sliderimage-dots {
                position: absolute;
                bottom: 15px;
                left: 50%;
                transform: translateX(-50%);
                display: flex;
                gap: 10px;
                z-index: 20;
            }
            .sliderimage-dot {
                width: 12px;
                height: 12px;
                background: rgba(255, 255, 255, 0.5);
                border-radius: 50%;
                cursor: pointer;
                transition: background 0.3s, transform 0.3s;
                box-shadow: 0 1px 3px rgba(0,0,0,0.3);
            }
            .sliderimage-dot.active {
                background: #fff;
                transform: scale(1.2);
            }
            .sliderimage-dot:hover {
                background: rgba(255, 255, 255, 0.8);
            }
            
            /* Arrows */
            .sliderimage-arrow {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                width: 40px;
                height: 40px;
                background: rgba(0, 0, 0, 0.3);
                color: white;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                transition: background 0.3s;
                z-index: 100; /* High z-index */
                font-size: 20px;
                user-select: none;
            }
            .sliderimage-arrow:hover {
                background: rgba(0, 0, 0, 0.6);
            }
            .sliderimage-arrow-prev { left: 10px; }
            .sliderimage-arrow-next { right: 10px; }
            
            /* Animations */
            
            /* Slide */
            .anim-slide .sliderimage-slide { transition: transform 0.5s ease; opacity: 1; visibility: visible; transform: translateX(100%); position: absolute; }
            .anim-slide .sliderimage-slide.active { transform: translateX(0); position: relative; }
            .anim-slide .sliderimage-slide.prev-out { transform: translateX(-100%); position: absolute; }
            .anim-slide .sliderimage-slide.next-in { transform: translateX(0); position: relative; z-index: 11; }
            
            /* Zoom */
            .anim-zoom .sliderimage-slide { transform: scale(1.1); opacity: 0; transition: transform 1s, opacity 1s; }
            .anim-zoom .sliderimage-slide.active { transform: scale(1); opacity: 1; }
            
            /* Flip (Simple) */
            .anim-flip .sliderimage-slide { transform: rotateY(90deg); opacity: 0; transition: transform 0.8s, opacity 0.8s; }
            .anim-flip .sliderimage-slide.active { transform: rotateY(0); opacity: 1; }
            
            /* Cube - Dynamic 3D */
            .anim-cube {
                perspective: 1000px; /* Depth */
            }
            .anim-cube .sliderimage-slide {
                position: absolute;
                top: 0; left: 0;
                width: 100%;
                height: 100%;
                backface-visibility: hidden;
                -webkit-backface-visibility: hidden;
                transform-style: preserve-3d;
                -webkit-transform-style: preserve-3d;
                opacity: 0;
                transition: transform 1s ease-in-out, opacity 1s;
                visibility: hidden;
            }
            .anim-cube .sliderimage-slide.active {
                opacity: 1;
                visibility: visible;
                z-index: 2;
                /* Note: Height is now handled by the container's aspect-ratio */
            }
            /* Note: For 3D absolute positioning to work and container to have height, 
               we might need JS to set container height or one static slide.
               For now, we'll keep .active as relative to prop open the container? 
               Actually, during animation, if we make them absolute, container might collapse if not set.
               We can rely on the 'relative' positioning of the active slide at rest.
            */

            
            /* ... rest of CSS ... */
            


            /* Cards */
            .anim-cards { perspective: 1000px; }
            .anim-cards .sliderimage-slide { transition: transform 0.6s ease, opacity 0.6s; position: absolute; top:0; left:0; transform-origin: center bottom; }
            .anim-cards .sliderimage-slide.active { z-index: 2; opacity: 1; transform: translateX(0) scale(1); }
            
            /* Fold covers entire container for 3D */
            .anim-fold { perspective: 1000px; overflow: visible !important; } 
            .anim-fold .sliderimage-slide { 
                position: absolute; top: 0; left: 0; width: 100%; height: 100%;
                transform-style: preserve-3d;
                backface-visibility: hidden;
                transition: transform 0.8s ease-in-out;
                opacity: 0; visibility: hidden;
            }

            .anim-bounce .sliderimage-slide { transform: translateY(-20px); opacity: 0; transition: transform 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275), opacity 0.5s; }
            .anim-bounce .sliderimage-slide.active { transform: translateY(0); opacity: 1; }
            
            ${config.custom_css || ''}

            /* The first slide is relative to give the container its natural height */
            /* We place this at the end to override animation-specific absolute positioning */
            .sliderimage-container .sliderimage-slide.first-slide {
                position: relative !important;
                opacity: 1 !important;
                visibility: visible !important;
                height: auto !important;
            }

            .sliderimage-ai-notice {
                position: absolute;
                bottom: 6px;
                left: 8px;
                z-index: 35;
                font-size: 10px;
                color: rgba(255, 255, 255, 0.85);
                text-shadow: 0 1px 3px rgba(0, 0, 0, 0.9), 0 0 2px rgba(0, 0, 0, 0.9);
                pointer-events: auto;
                font-family: inherit;
                line-height: 1;
            }
            .sliderimage-ai-notice a {
                color: inherit;
                text-decoration: none !important;
            }
        `;

        const style = document.createElement('style');
        style.textContent = css;
        document.head.appendChild(style);

        // Apply animation class
        if (sliderConfig.animation && sliderConfig.animation !== 'fade') {
            container.classList.add('anim-' + sliderConfig.animation);
        }

        // Render Slides and Dots
        slides.forEach((slide, index) => {
            // Slide
            const slideEl = document.createElement('div');
            slideEl.className = `sliderimage-slide ${index === 0 ? 'active first-slide' : ''}`;

            let content = '';
            let imgTag = `<img src="${slide.url}" alt="Banner">`;

            if (slide.click_url) {
                content += `<a href="${slide.click_url}" style="display:block;">${imgTag}</a>`;
            } else {
                content += imgTag;
            }
            slideEl.innerHTML = content;
            container.appendChild(slideEl);

            // Dot
            if (slides.length > 1) {
                const dot = document.createElement('div');
                dot.className = `sliderimage-dot ${index === 0 ? 'active' : ''}`;
                dot.onclick = (e) => {
                    e.stopPropagation(); // Prevent swipe or other clicks
                    goToSlide(index);
                };
                dotsContainer.appendChild(dot);
            }
        });

        if (slides.length > 1) {
            container.appendChild(dotsContainer);
        }

        // AI Act Notice element in bottom-left
        const showAiNotice = config.show_ai_notice !== false && config.show_ai_notice !== 'false' && config.show_ai_notice !== 0 && config.show_ai_notice !== '0';
        if (showAiNotice) {
            const aiNotice = document.createElement('div');
            aiNotice.className = 'sliderimage-ai-notice';
            aiNotice.innerHTML = 'Generováno AI | <a href="https://dealnet.cz" target="_blank" rel="noopener">dealnet.cz</a>';
            container.appendChild(aiNotice);
        }

        // Arrows
        if (slides.length > 1) {
            const prevArrow = document.createElement('div');
            prevArrow.className = 'sliderimage-arrow sliderimage-arrow-prev';
            prevArrow.innerHTML = '&#10094;'; // <
            container.appendChild(prevArrow);

            const nextArrow = document.createElement('div');
            nextArrow.className = 'sliderimage-arrow sliderimage-arrow-next';
            nextArrow.innerHTML = '&#10095;'; // >
            container.appendChild(nextArrow);
        }

        // Insert widget
        const shouldReplace = !!config.replace_content && config.replace_content !== 'false' && config.replace_content !== 0 && config.replace_content !== '0';
        const targetEls = document.querySelectorAll(targetSelector);
        
        if (targetEls.length > 0) {
            targetEls.forEach((el, index) => {
                if (shouldReplace && el.nodeName !== 'BODY') {
                    el.innerHTML = '';
                }
                // Insert our slider only into the first matching element
                if (index === 0) {
                    if (shouldReplace) {
                        el.appendChild(container);
                    } else {
                        el.insertBefore(container, el.firstChild);
                    }
                }
            });
        } else {
            console.error(`SliderImage Widget: No elements matching "${targetSelector}" found.`);
            return;
        }

        // Logic
        // Logic
        if (slides.length > 1) {
            let currentIndex = 0;
            let timer = null;
            const intervalTime = parseInt(sliderConfig.interval) || 5000;
            const slideEls = container.querySelectorAll('.sliderimage-slide');
            const dotEls = container.querySelectorAll('.sliderimage-dot');

            const startTimer = () => {
                if (timer) clearInterval(timer);
                if (intervalTime > 0) {
                    timer = setInterval(nextSlide, intervalTime);
                }
            };

            const stopTimer = () => {
                if (timer) clearInterval(timer);
                timer = null;
            };

            const updateDots = (index) => {
                dotEls.forEach(d => d.classList.remove('active'));
                if (dotEls[index]) dotEls[index].classList.add('active');
            };

            // Responsive Cube Depth
            if (sliderConfig.animation === 'cube' || sliderConfig.animation === 'cube-horizontal') {
                const resizeObserver = new ResizeObserver(entries => {
                    for (let entry of entries) {
                        let depth;
                        if (sliderConfig.animation === 'cube-horizontal') {
                            const w = entry.contentRect.width;
                            depth = Math.round(w / 2);
                        } else {
                            const h = entry.contentRect.height;
                            depth = Math.round(h / 2);
                        }
                        container.style.setProperty('--cube-depth', depth + 'px');
                    }
                });
                resizeObserver.observe(container);
            }

            // Transition function
            goToSlide = (newIndex, direction = 'next') => {
                if (newIndex === currentIndex) return;

                const prevIndex = currentIndex;
                const prevEl = slideEls[prevIndex];
                const nextEl = slideEls[newIndex];
                currentIndex = newIndex;

                updateDots(currentIndex);

                // Animation specific Logic
                if (sliderConfig.animation === 'slide') {
                    // Standard Slide Logic - Reset classes first
                    slideEls.forEach(el => {
                        el.classList.remove('active', 'prev-out', 'next-in', 'inactive-absolute');
                        if (sliderConfig.animation === 'slide') el.style.transform = '';
                    });

                    if (direction === 'next') {
                        prevEl.style.transform = 'translateX(0)';
                        nextEl.style.transform = 'translateX(100%)';
                        void nextEl.offsetWidth; // Force Reflow
                        prevEl.classList.add('prev-out');
                        prevEl.style.transform = 'translateX(-100%)';
                        nextEl.classList.add('active');
                        nextEl.style.transform = 'translateX(0)';
                    } else {
                        prevEl.style.transform = 'translateX(0)';
                        nextEl.style.transform = 'translateX(-100%)';
                        void nextEl.offsetWidth;
                        prevEl.style.transform = 'translateX(100%)';
                        nextEl.classList.add('active');
                        nextEl.style.transform = 'translateX(0)';
                    }

                } else if (sliderConfig.animation === 'cube' || sliderConfig.animation === 'cube-horizontal') {
                    // CUBE Logic (Vertical or Horizontal)
                    const isVertical = sliderConfig.animation === 'cube'; // 'cube' = Vertical (Legacy default)

                    // 1. Lock Container Height IMMEDIATELY
                    const rect = prevEl.getBoundingClientRect();
                    const containerHeight = rect.height || container.offsetHeight;

                    container.style.height = containerHeight + 'px';
                    container.style.overflow = 'visible'; // ALLOW 3D PROTRUSION

                    // 2. Setup Depth
                    // Vertical uses Height/2, Horizontal uses Width/2
                    let depthVal = parseInt(getComputedStyle(container).getPropertyValue('--cube-depth'));

                    // Recalculate if not set or if we need to switch axis context dynamically
                    // (Note: ResizeObserver handles updates, but let's ensure instant init matches axis)
                    if (!depthVal) {
                        if (isVertical) {
                            depthVal = Math.round(containerHeight / 2);
                        } else {
                            const containerWidth = container.offsetWidth;
                            depthVal = Math.round(containerWidth / 2);
                        }
                        container.style.setProperty('--cube-depth', depthVal + 'px');
                    }
                    const pivot = `50% 50% -${depthVal}px`;

                    // 3. Prepare Participants
                    slideEls.forEach((el, index) => {
                        el.style.transition = 'none';
                        if (index !== prevIndex && index !== newIndex) {
                            el.style.display = 'none';
                            el.style.opacity = '0';
                            el.classList.remove('active');
                        }
                    });

                    // 4. Position Participants
                    prevEl.style.position = 'absolute';
                    prevEl.style.top = '0';
                    prevEl.style.left = '0';
                    prevEl.style.width = '100%';
                    prevEl.style.zIndex = '2';
                    prevEl.style.opacity = '1';
                    prevEl.style.visibility = 'visible';
                    prevEl.style.display = 'block';

                    nextEl.style.position = 'absolute';
                    nextEl.style.top = '0';
                    nextEl.style.left = '0';
                    nextEl.style.width = '100%';
                    nextEl.style.zIndex = '1';
                    nextEl.style.opacity = '1';
                    nextEl.style.visibility = 'visible';
                    nextEl.style.display = 'block';

                    if (isVertical) {
                        // VERTICAL (Rotate X)
                        if (direction === 'next') {
                            prevEl.style.transformOrigin = pivot;
                            prevEl.style.transform = 'rotateX(0deg)';

                            nextEl.style.transformOrigin = pivot;
                            nextEl.style.transform = 'rotateX(-90deg)';

                            void nextEl.offsetWidth;

                            prevEl.style.transition = 'transform 1s ease-in-out';
                            nextEl.style.transition = 'transform 1s ease-in-out';

                            prevEl.style.transform = 'rotateX(90deg)';
                            nextEl.style.transform = 'rotateX(0deg)';
                        } else {
                            prevEl.style.transformOrigin = pivot;
                            prevEl.style.transform = 'rotateX(0deg)';

                            nextEl.style.transformOrigin = pivot;
                            nextEl.style.transform = 'rotateX(90deg)';

                            void nextEl.offsetWidth;

                            prevEl.style.transition = 'transform 1s ease-in-out';
                            nextEl.style.transition = 'transform 1s ease-in-out';

                            prevEl.style.transform = 'rotateX(-90deg)';
                            nextEl.style.transform = 'rotateX(0deg)';
                        }
                    } else {
                        // HORIZONTAL (Rotate Y)
                        if (direction === 'next') {
                            // Next slide comes from RIGHT (standard carousel)
                            // Imagine cube face to the right is at 90deg?
                            // Front=0, Right=90, Back=180, Left=-90
                            // Rotate World Left (-90): Front->Left (-90), Right->Front (0)

                            prevEl.style.transformOrigin = pivot;
                            prevEl.style.transform = 'rotateY(0deg)';

                            nextEl.style.transformOrigin = pivot;
                            nextEl.style.transform = 'rotateY(90deg)';

                            void nextEl.offsetWidth;

                            prevEl.style.transition = 'transform 1s ease-in-out';
                            nextEl.style.transition = 'transform 1s ease-in-out';

                            prevEl.style.transform = 'rotateY(-90deg)'; // Move Left
                            nextEl.style.transform = 'rotateY(0deg)';   // Move Center
                        } else {
                            // Next slide comes from LEFT
                            prevEl.style.transformOrigin = pivot;
                            prevEl.style.transform = 'rotateY(0deg)';

                            nextEl.style.transformOrigin = pivot;
                            nextEl.style.transform = 'rotateY(-90deg)';

                            void nextEl.offsetWidth;

                            prevEl.style.transition = 'transform 1s ease-in-out';
                            nextEl.style.transition = 'transform 1s ease-in-out';

                            prevEl.style.transform = 'rotateY(90deg)'; // Move Right
                            nextEl.style.transform = 'rotateY(0deg)';  // Move Center
                        }
                    }

                    // Cleanup
                    setTimeout(() => {
                        // Finalize states
                        nextEl.classList.add('active');
                        nextEl.style.position = 'relative';
                        nextEl.style.transform = '';
                        nextEl.style.transformOrigin = '';
                        nextEl.style.zIndex = '';
                        nextEl.style.opacity = '1';

                        prevEl.classList.remove('active');
                        prevEl.style.display = 'none';
                        prevEl.style.transform = '';
                        prevEl.style.opacity = '0';

                        // Unlock container
                        container.style.height = '';
                        container.style.overflow = '';
                    }, 1000);

                } else if (sliderConfig.animation === 'fold') {
                    // FOLD (Leporelo) Logic

                    // Lock Container
                    const rect = prevEl.getBoundingClientRect();
                    container.style.height = (rect.height || container.offsetHeight) + 'px';
                    container.style.overflow = 'visible';

                    slideEls.forEach((el, index) => {
                        el.style.transition = 'none';
                        if (index !== prevIndex && index !== newIndex) el.style.display = 'none';
                    });

                    prevEl.style.position = 'absolute';
                    prevEl.style.zIndex = '2';
                    prevEl.style.display = 'block';
                    prevEl.style.opacity = '1';
                    prevEl.style.visibility = 'visible';

                    nextEl.style.position = 'absolute';
                    nextEl.style.zIndex = '1';
                    nextEl.style.display = 'block';
                    nextEl.style.opacity = '1';
                    nextEl.style.visibility = 'visible';

                    if (direction === 'next') {
                        // Fold: Prev folds LEFT (hinge right), Next folds IN from RIGHT (hinge left)
                        // Actually better: standard book fold?
                        // Let's do: Prev rotates Y -90deg (origin left), Next rotates Y 0 (from 90deg, origin right not fitting?)
                        // "Leporelo" usually means continuous z-fold.
                        // Let's do: Prev folds AWAY to left (Origin Left, RotY -90), Next folds IN from right (Origin Right, RotY 90 -> 0)

                        prevEl.style.transformOrigin = 'left center';
                        prevEl.style.transform = 'rotateY(0deg)';

                        nextEl.style.transformOrigin = 'right center'; // Pivot at right edge?
                        // Wait, if next comes from right, and folds in, maybe origin LEFT?
                        // Let's try: Origin Left for both to mimic page turning? No, Leporelo is zigzag.
                        // Let's do "Cube without depth" basically, or contiguous faces.

                        // Implementation: Pivot at adjacent edges.
                        // Edge between Prev and Next is... imaginary.
                        // Let's keep it simple: Prev rotates out Left, Next rotates in From Right.

                        prevEl.style.transformOrigin = '0% 50%'; // Left edge
                        nextEl.style.transformOrigin = '100% 50%'; // Right edge

                        nextEl.style.transform = 'rotateY(90deg)';

                        void nextEl.offsetWidth;

                        prevEl.style.transition = 'transform 1s ease-in-out';
                        nextEl.style.transition = 'transform 1s ease-in-out';

                        prevEl.style.transform = 'rotateY(-90deg)';
                        nextEl.style.transform = 'rotateY(0deg)';
                    } else {
                        // Prev Direction
                        prevEl.style.transformOrigin = '100% 50%'; // Right Edge
                        nextEl.style.transformOrigin = '0% 50%';   // Left Edge

                        nextEl.style.transform = 'rotateY(-90deg)';

                        void nextEl.offsetWidth;

                        prevEl.style.transition = 'transform 1s ease-in-out';
                        nextEl.style.transition = 'transform 1s ease-in-out';

                        prevEl.style.transform = 'rotateY(90deg)';
                        nextEl.style.transform = 'rotateY(0deg)';
                    }

                    setTimeout(() => {
                        nextEl.classList.add('active');
                        nextEl.style.position = 'relative';
                        nextEl.style.transform = '';
                        nextEl.style.zIndex = '';
                        prevEl.classList.remove('active');
                        prevEl.style.display = 'none';
                        container.style.height = '';
                        container.style.overflow = '';
                    }, 1000);

                } else if (sliderConfig.animation === 'cards') {
                    // CARDS Logic

                    // Lock Container
                    const rect = prevEl.getBoundingClientRect();
                    container.style.height = (rect.height || container.offsetHeight) + 'px';
                    container.style.overflow = 'hidden'; // Cards can be hidden

                    slideEls.forEach((el, index) => {
                        el.style.transition = 'none';
                        if (index !== prevIndex && index !== newIndex) el.style.display = 'none';
                    });

                    prevEl.style.position = 'absolute';
                    prevEl.style.display = 'block';
                    prevEl.style.opacity = '1';
                    prevEl.style.visibility = 'visible';

                    nextEl.style.position = 'absolute';
                    nextEl.style.display = 'block';
                    nextEl.style.opacity = '1';
                    nextEl.style.visibility = 'visible';

                    if (direction === 'next') {
                        // Next comes IN from Right, Prev scales down
                        prevEl.style.zIndex = '1';
                        prevEl.style.transform = 'scale(1)';

                        nextEl.style.zIndex = '2';
                        nextEl.style.transform = 'translateX(100%) shadow(0 0 0 rgba(0,0,0,0))';

                        void nextEl.offsetWidth;

                        prevEl.style.transition = 'transform 0.8s ease, filter 0.8s';
                        nextEl.style.transition = 'transform 0.8s cubic-bezier(0.2, 1, 0.3, 1)'; // Smooth easing

                        prevEl.style.transform = 'scale(0.9)'; // Recede
                        prevEl.style.filter = 'brightness(0.7)';

                        nextEl.style.transform = 'translateX(0)'; // Slide over
                        nextEl.style.boxShadow = '-10px 0 20px rgba(0,0,0,0.3)';

                    } else {
                        // Backwards: Prev slides OUT to right, Next scales UP from back
                        prevEl.style.zIndex = '2';
                        prevEl.style.transform = 'translateX(0)';

                        nextEl.style.zIndex = '1';
                        nextEl.style.transform = 'scale(0.9)';
                        nextEl.style.filter = 'brightness(0.7)';

                        void nextEl.offsetWidth;

                        prevEl.style.transition = 'transform 0.8s cubic-bezier(0.2, 1, 0.3, 1)';
                        nextEl.style.transition = 'transform 0.8s ease, filter 0.8s';

                        prevEl.style.transform = 'translateX(100%)';

                        nextEl.style.transform = 'scale(1)';
                        nextEl.style.filter = 'brightness(1)';
                    }

                    setTimeout(() => {
                        nextEl.classList.add('active');
                        nextEl.style.position = 'relative';
                        nextEl.style.transform = '';
                        nextEl.style.filter = '';
                        nextEl.style.boxShadow = '';
                        nextEl.style.zIndex = '';

                        prevEl.classList.remove('active');
                        prevEl.style.display = 'none';
                        prevEl.style.transform = '';
                        prevEl.style.filter = '';

                        container.style.height = '';
                        container.style.overflow = '';
                    }, 800);

                } else {
                    // Fade, Zoom, Flip, Bounce (Legacy handled by CSS classes mostly)
                    // Clear classes first
                    slideEls.forEach(el => {
                        el.classList.remove('active', 'prev-out', 'next-in', 'inactive-absolute');
                        el.style.transform = '';
                    });

                    prevEl.classList.add('inactive-absolute');
                    nextEl.classList.add('active');

                    // Specific JS helpers if needed, but CSS handles opacity/transform

                    setTimeout(() => {
                        prevEl.classList.remove('inactive-absolute');
                    }, 1000);
                }

                startTimer(); // Ensure timer restarts
            };

            nextSlide = () => {
                const newIndex = (currentIndex + 1) % slideEls.length;
                goToSlide(newIndex, 'next');
            };

            prevSlide = () => {
                const newIndex = (currentIndex - 1 + slideEls.length) % slideEls.length;
                goToSlide(newIndex, 'prev');
            };

            // Expose
            window._sliderGoTo = goToSlide;

            // Arrow Listeners
            const arrowPrev = container.querySelector('.sliderimage-arrow-prev');
            const arrowNext = container.querySelector('.sliderimage-arrow-next');

            if (arrowPrev) {
                arrowPrev.addEventListener('click', (e) => {
                    e.preventDefault(); e.stopPropagation();
                    prevSlide();
                    startTimer(); // Reset timer
                });
            }
            if (arrowNext) {
                arrowNext.addEventListener('click', (e) => {
                    e.preventDefault(); e.stopPropagation();
                    nextSlide();
                    startTimer(); // Reset timer
                });
            }

            // Swipe
            let touchStartX = 0;
            let touchEndX = 0;

            container.addEventListener('touchstart', e => {
                touchStartX = e.changedTouches[0].screenX;
                stopTimer(); // Pause on hold?
            }, { passive: true });

            container.addEventListener('touchend', e => {
                touchEndX = e.changedTouches[0].screenX;
                if (touchEndX < touchStartX - 50) nextSlide();
                if (touchEndX > touchStartX + 50) prevSlide();
                startTimer();
            }, { passive: true });

            // Auto-rotate init
            startTimer();
        }
    }
})();