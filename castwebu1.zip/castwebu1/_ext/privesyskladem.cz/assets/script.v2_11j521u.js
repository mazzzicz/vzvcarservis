var CART_ICON_HTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>';

// --- GLOBÁLNÍ POSLUCHAČ PRO "ESC" ---
document.addEventListener('keyup', function (e) {
    if (document.body.classList.contains('gallery-active')) return;
    if (e.key === 'Escape' || e.keyCode === 27) {
        if (document.body.classList.contains('zoom-open')) {
            closeImageZoom();
        } else if (document.body.classList.contains('search-open')) {
            closeSearchModal();
        } else if (document.body.classList.contains('lightbox-open')) {
            closeLightbox();
        } else if (document.body.classList.contains('cart-open')) {
            closeSlideCart();
        } else if (document.body.classList.contains('megamenu-open')) {
            closeMegamenu();
        }
    }
});

// --- POMOCNÁ FUNKCE (DEBOUNCE) ---
function debounce(func, wait) {
    var timeout;
    return function () {
        var context = this, args = arguments;
        var later = function () {
            timeout = null;
            func.apply(context, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
};


// --- MEGAMENU FUNCTIONS ---
function openMegamenu(targetCatId) {
    document.body.classList.add('megamenu-open');
    document.body.classList.add('no-scroll');

    // Reset visibility first
    var allSections = document.querySelectorAll('.megamenu-section');
    var grid = document.querySelector('.megamenu-grid');

    // Default state: Show all, Standard Grid
    allSections.forEach(s => s.style.display = '');
    if (grid) grid.classList.remove('single-view');

    // Filtered state if targetCatId is provided
    if (targetCatId) {
        if (grid) grid.classList.add('single-view');
        allSections.forEach(function (s) {
            if (s.id === 'megamenu-cat-' + targetCatId) {
                s.style.display = 'block';
            } else {
                s.style.display = 'none';
            }
        });
    }
}

function closeMegamenu() {
    document.body.classList.remove('megamenu-open');
    document.body.classList.remove('no-scroll');
    // Reset on close to be safe
    setTimeout(function () {
        var allSections = document.querySelectorAll('.megamenu-section');
        allSections.forEach(function (s) { s.style.display = ''; });
        var grid = document.querySelector('.megamenu-grid');
        if (grid) grid.classList.remove('single-view');
    }, 300);
}

// --- INICIALIZACE STRÁNKY ---
document.addEventListener('DOMContentLoaded', function () {

    // --- 1. Ovládání mobilního menu (Sidebar) ---
    var navToggle = document.querySelector('.nav-toggle');
    var sidebar = document.getElementById('sidebar');
    var mobileOverlay = document.getElementById('mobile-overlay');

    function closeMobileMenu() {
        navToggle.classList.remove('is-active');
        sidebar.classList.remove('is-active');
        mobileOverlay.classList.remove('is-active');
        document.body.classList.remove('no-scroll'); // Povolit rolování
    }

    if (navToggle && sidebar && mobileOverlay) {
        navToggle.addEventListener('click', function () {
            var isActive = navToggle.classList.toggle('is-active');
            sidebar.classList.toggle('is-active');
            mobileOverlay.classList.toggle('is-active');

            if (isActive) {
                document.body.classList.add('no-scroll'); // Zakázat rolování
            } else {
                document.body.classList.remove('no-scroll');
            }
        });
        mobileOverlay.addEventListener('click', function () {
            closeMobileMenu();
        });

        // Přidání logiky pro nový zavírací křížek v sidebaru
        var sidebarClose = document.getElementById('menu-close-btn');
        if (sidebarClose) {
            sidebarClose.addEventListener('click', function (e) {
                e.preventDefault();
                closeMobileMenu();
            });
        }
    }

    // --- Megamenu Control ---
    var megamenuTrigger = document.getElementById('megamenu-trigger');
    var megamenuOverlay = document.getElementById('megamenu-overlay');
    var megamenuClose = document.getElementById('megamenu-close-btn');

    if (megamenuTrigger) {
        megamenuTrigger.addEventListener('click', function (e) { e.preventDefault(); openMegamenu(); });
    }
    if (megamenuClose) {
        megamenuClose.addEventListener('click', function (e) { e.preventDefault(); closeMegamenu(); });
    }
    if (megamenuOverlay) {
        megamenuOverlay.addEventListener('click', function (e) {
            if (e.target === megamenuOverlay) closeMegamenu();
        });
    }

    // --- Horizontal Megamenu Interaction (Light Dropdown) ---
    var horizontalItems = document.querySelectorAll('.megamenu-nav-item.has-dropdown');

    // 1. Toggle on click
    horizontalItems.forEach(function (item) {
        var link = item.querySelector('.nav-link-item');
        if (link) {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                e.stopPropagation(); // Prevent document click from closing immediately

                // Close others
                horizontalItems.forEach(other => {
                    if (other !== item) other.classList.remove('dropdown-active');
                });

                // Toggle current
                item.classList.toggle('dropdown-active');
            });
        }
    });

    // 2. Close when clicking outside
    document.addEventListener('click', function (e) {
        if (!e.target.closest('.megamenu-nav-item')) {
            horizontalItems.forEach(item => {
                item.classList.remove('dropdown-active');
            });
        }
    });

    // --- 2. Ovládání stromu kategorií ---
    var categoryToggles = document.querySelectorAll('.toggle-submenu');
    for (var i = 0; i < categoryToggles.length; i++) {
        categoryToggles[i].addEventListener('click', function (e) {
            e.preventDefault();
            this.parentElement.classList.toggle('is-open');
        });
    }

    // --- 2.1 Ovládání dolního menu (Bottom Nav Dropdowns) ---
    // --- 2.1 Ovládání dolního menu (Bottom Nav Dropdowns) ---
    var bottomNavLinks = document.querySelectorAll('.bottom-nav-links .has-dropdown > a');
    bottomNavLinks.forEach(function (link) {
        link.addEventListener('click', function (e) {
            var parent = this.parentElement;
            if (parent.classList.contains('has-dropdown')) {
                // Check if we should allow clicking through or just toggle
                // Toggle on arrow/click, and allow navigation if item is already active
                if (!parent.classList.contains('is-open')) {
                    e.preventDefault();
                    parent.classList.add('is-open');
                } else {
                    // Item is open, allow nav or toggle back? 
                    // To be safe and simple: toggle
                    // parent.classList.remove('is-open');
                }
            }
        });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function (e) {
        if (!e.target.closest('.bottom-nav-links .nav-item')) {
            document.querySelectorAll('.bottom-nav-links .nav-item.is-open').forEach(function (item) {
                item.classList.remove('is-open');
            });
        }
    });

    // --- 3. Ovládání sbalitelného filtru ---
    var filterHeader = document.getElementById('filter-header');
    var filterSection = document.querySelector('.filter-section');
    if (filterHeader && filterSection) {
        filterHeader.addEventListener('click', function (e) {
            var clickedElement = e.target;
            if (clickedElement.closest('a') || clickedElement.closest('button') || clickedElement.closest('.remove-filter-chip')) {
            } else {
                filterSection.classList.toggle('is-open');
            }
            if (clickedElement.closest('button.toggle-filter')) {
                e.preventDefault();
                filterSection.classList.toggle('is-open');
            }
        });
    }

    // --- 4. Ovládání odstraňování "chipsů" filtru ---
    var chipsContainer = document.getElementById('active-filters-summary');
    var mainFilterForm = document.getElementById('filter-form');
    if (chipsContainer && mainFilterForm) {
        chipsContainer.addEventListener('click', function (e) {
            var chip = e.target.closest('.remove-filter-chip');
            if (chip) {
                e.preventDefault();
                var type = chip.getAttribute('data-type');
                var value = chip.getAttribute('data-value');
                if (type === 'price') {
                    var minInput = mainFilterForm.querySelector('[name="min_price"]');
                    var maxInput = mainFilterForm.querySelector('[name="max_price"]');
                    if (minInput) minInput.value = '';
                    if (maxInput) maxInput.value = '';
                } else {
                    var checkbox = mainFilterForm.querySelector('[name="' + type + '[]"][value="' + value + '"]');
                    if (checkbox) checkbox.checked = false;
                }
                mainFilterForm.submit();
            }
        });
    }

    // --- 5. Logika pro "Načíst další" ---
    var productGrid = document.getElementById('product-grid');
    var loadMoreBtn = document.getElementById('load-more-btn');
    if (loadMoreBtn && productGrid) {
        loadMoreBtn.addEventListener('click', function () {
            var currentPage = parseInt(this.getAttribute('data-page'), 10);
            var category_id = this.getAttribute('data-category_id');
            var currentQuery = window.location.search;
            if (currentQuery.charAt(0) === '?') currentQuery = currentQuery.substring(1);

            var pageQuery = 'page=' + currentPage;
            var categoryQuery = 'category_id=' + encodeURIComponent(category_id);

            // Změna pro podporu velkého množství filtrů (POST)
            var ajaxUrl = '/ajax_load_products.php';

            // Získání dat z formuláře (pro aktuální filtry)
            var formData = new FormData();
            var filterForm = document.getElementById('filter-form');
            if (filterForm) {
                formData = new FormData(filterForm);
            }

            // Přidání stránkovacích dat
            formData.append('page', currentPage);
            formData.append('category_id', category_id);

            loadMoreBtn.innerHTML = 'Načítám...';
            loadMoreBtn.disabled = true;

            var xhr = new XMLHttpRequest();
            xhr.open('POST', ajaxUrl, true);
            // FormData automaticky nastaví Content-Type header

            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.html) {
                            productGrid.innerHTML += response.html;
                            if (typeof initCardsWithVariants === 'function') initCardsWithVariants(productGrid);
                        }
                        if (response.count < 50) {
                            loadMoreBtn.style.display = 'none';
                        } else {
                            loadMoreBtn.setAttribute('data-page', currentPage + 1);
                            loadMoreBtn.innerHTML = 'Načíst další produkty';
                            loadMoreBtn.disabled = false;
                        }
                    } catch (e) { loadMoreBtn.innerHTML = 'Chyba při načítání'; }
                } else if (xhr.readyState === 4) { loadMoreBtn.innerHTML = 'Chyba při načítání'; }
            };
            xhr.send(formData);
        });
    }

    // --- 6. LOGIKA PRO LIGHTBOX (HLAVNÍ) ---
    document.body.addEventListener('click', function (e) {
        var link = e.target.closest('a.product-image-link');
        if (link) {
            e.preventDefault();

            // Build Gallery List
            var allLinks = document.querySelectorAll('a.product-image-link');
            lightboxItems = [];
            var clickIndex = -1;

            for (var i = 0; i < allLinks.length; i++) {
                var l = allLinks[i];
                // Determine URL (same logic as below)
                var u = l.getAttribute('data-ajax-url');
                if (!u) {
                    var h = l.getAttribute('href');
                    var sep = (h.indexOf('?') !== -1) ? '&' : '?';
                    u = h + sep + 'ajax=1';
                }
                lightboxItems.push(u);

                if (l === link) clickIndex = i;
            }

            openLightbox(lightboxItems[clickIndex], clickIndex);
        }
    });
    var closeBtn = document.getElementById('lightbox-close');
    var overlay = document.getElementById('lightbox-overlay');
    if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
    if (overlay) {
        overlay.addEventListener('click', function (e) {
            if (e.target === overlay) closeLightbox();
        });
    }

    // --- 7. LOGIKA PRO VYSOUVACÍ KOŠÍK ---
    var openCartBtn = document.getElementById('open-cart-btn');
    var closeCartBtn = document.getElementById('slide-cart-close');
    var cartOverlay = document.getElementById('slide-cart-overlay');
    if (openCartBtn) {
        openCartBtn.addEventListener('click', function (e) {
            e.preventDefault();
            openSlideCart();
        });
    }
    if (closeCartBtn) closeCartBtn.addEventListener('click', closeSlideCart);
    if (cartOverlay) cartOverlay.addEventListener('click', closeSlideCart);

    // --- 8. LOGIKA PRO INTERAKTIVNÍ KOŠÍK (sdílená) ---
    var slideCartContent = document.getElementById('slide-cart-content');
    if (slideCartContent) setupCartListeners(slideCartContent);
    var checkoutCartContent = document.getElementById('checkout-cart-content');
    if (checkoutCartContent) setupCartListeners(checkoutCartContent);

    // --- 9. LOGIKA PRO DETAIL PRODUKTU (na plné stránce) ---
    initializeProductDetailScripts(document.body);

    // --- 10. LOGIKA PRO POKLADNU (OPRAVENO PRO DPD) ---
    initializeCheckoutForm();

    // --- 11. LOGIKA PRO ZOOM LIGHTBOX ---
    var zoomOverlay = document.getElementById('image-zoom-overlay');
    var zoomContent = document.getElementById('image-zoom-content');
    var zoomClose = document.getElementById('image-zoom-close');
    if (zoomOverlay) {
        zoomOverlay.addEventListener('click', function (e) {
            if (e.target === zoomOverlay) closeImageZoom();
        });
    }
    if (zoomClose) zoomClose.addEventListener('click', closeImageZoom);

    // --- 12. LOGIKA PRO VYHLEDÁVÁNÍ ---
    var searchIcon = document.getElementById('search-icon-btn');
    var searchModal = document.getElementById('search-modal');
    var searchOverlay = document.getElementById('search-overlay');
    var searchCloseBtn = document.getElementById('search-modal-close');
    var searchInput = document.getElementById('search-input-field');
    var searchSuggester = document.getElementById('search-suggester');
    var searchLoader = document.getElementById('search-loader');
    var searchActiveIndex = -1;
    if (searchIcon && searchModal && searchInput) {
        searchIcon.addEventListener('click', function () {
            // Přidáme třídu pro zobrazení
            document.body.classList.add('search-open');
            searchOverlay.classList.add('is-visible');
            searchModal.classList.add('is-visible');

            // Reset a focus
            searchInput.value = '';
            setTimeout(function () { searchInput.focus(); }, 50);
        });
        searchCloseBtn.addEventListener('click', closeSearchModal);
        searchOverlay.addEventListener('click', closeSearchModal);

        searchInput.addEventListener('keyup', debounce(function (e) {
            if (e.key === 'ArrowDown' || e.keyCode === 40 ||
                e.key === 'ArrowUp' || e.keyCode === 38 ||
                e.key === 'Enter' || e.keyCode === 13) { return; }
            var term = searchInput.value;
            if (term.length < 3) { searchSuggester.innerHTML = ''; return; }
            searchLoader.style.display = 'block';
            var xhr = new XMLHttpRequest();
            xhr.open('GET', '/ajax_search.php?term=' + encodeURIComponent(term), true);
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    searchLoader.style.display = 'none';
                    try {
                        var response = JSON.parse(xhr.responseText);
                        buildSuggester(response.results);
                        searchActiveIndex = -1;
                    } catch (e) { console.error('Chyba parsování JSON z vyhledávání'); }
                } else if (xhr.readyState === 4) { searchLoader.style.display = 'none'; }
            };
            xhr.send();
        }, 300));

        searchInput.addEventListener('keydown', function (e) {
            var items = searchSuggester.querySelectorAll('a.suggester-item');
            if (items.length === 0) return;
            if (e.key === 'ArrowDown' || e.keyCode === 40) {
                e.preventDefault();
                searchActiveIndex++;
                if (searchActiveIndex >= items.length) searchActiveIndex = 0;
                updateSearchActive(items);
            }
            else if (e.key === 'ArrowUp' || e.keyCode === 38) {
                e.preventDefault();
                searchActiveIndex--;
                if (searchActiveIndex < 0) searchActiveIndex = items.length - 1;
                updateSearchActive(items);
            }
            else if (e.key === 'Enter' || e.keyCode === 13) {
                e.preventDefault();
                if (searchActiveIndex > -1 && items[searchActiveIndex]) {
                    window.location.href = items[searchActiveIndex].href;
                } else {
                    var term = searchInput.value.trim();
                    if (term.length >= 2) {
                        window.location.href = '/?q=' + encodeURIComponent(term);
                    }
                }
            }
        });
    }

    function updateSearchActive(items) {
        for (var i = 0; i < items.length; i++) {
            items[i].classList.remove('search-active');
        }
        if (items[searchActiveIndex]) {
            items[searchActiveIndex].classList.add('search-active');
            items[searchActiveIndex].scrollIntoView({ block: 'nearest' });
        }
    }

    function buildSuggester(results) {
        if (!searchSuggester) return;
        if (results.length === 0) {
            searchSuggester.innerHTML = '<div class="suggester-item"><span class="suggester-info">Nebyly nalezeny žádné výsledky.</span></div>';
            return;
        }
        var html = '';
        for (var i = 0; i < results.length; i++) {
            var item = results[i];
            html += '<a href="' + item.url + '" class="suggester-item">';
            html += '  <img src="' + item.image + '" alt="" class="suggester-image">';
            html += '  <div class="suggester-info">';
            html += '    <span class="suggester-name">' + item.name + '</span>';
            html += '    <span class="suggester-meta">' + item.type + ' / ' + item.status + '</span>';
            html += '  </div>';
            html += '  <span class="suggester-price">' + item.price + '</span>';
            html += '</a>';
        }
        searchSuggester.innerHTML = html;
    }

    // --- Global Quantity Control Logic ---
    document.body.addEventListener('click', function (e) {
        var btn = e.target.closest('.qty-btn');
        if (btn) {
            e.preventDefault();
            var isPlus = btn.classList.contains('qty-plus');
            var wrapper = btn.closest('.qty-control');
            if (!wrapper) return;
            var input = wrapper.querySelector('input[type="number"]');
            if (!input) return;

            var stepAttr = input.getAttribute('step');
            var step = parseFloat(stepAttr) || 1;
            var min = parseFloat(input.getAttribute('min')) || 1;
            var max = parseFloat(input.getAttribute('max')) || Infinity;
            var val = parseFloat(input.value) || 0;

            if (isPlus) {
                val += step;
            } else {
                val -= step;
            }

            if (val < min) val = min;
            if (val > max) val = max;

            // Round to avoid floating point issues (e.g. 0.1 + 0.2 = 0.30000000000000004)
            // But only if step is not an integer
            if (step % 1 !== 0) {
                var decimals = stepAttr.toString().split('.')[1]?.length || 2;
                val = parseFloat(val.toFixed(decimals));
            }

            input.value = val;
            // Trigger change event for any listeners
            input.dispatchEvent(new Event('change', { bubbles: true }));
        }
    });
});


// --- GLOBÁLNÍ FUNKCE PRO LIGHTBOX (HLAVNÍ) ---
var lightboxItems = [];
var lightboxIndex = -1;

function openLightbox(ajaxUrl, index) {
    if (typeof index === 'number') {
        lightboxIndex = index;
    }

    var overlay = document.getElementById('lightbox-overlay');
    var content = document.getElementById('lightbox-content');
    if (!overlay || !content) return;

    document.body.classList.add('lightbox-open');
    overlay.classList.add('is-visible');

    // Check if nav buttons exist
    var prevBtn = document.getElementById('lb-prev');
    var nextBtn = document.getElementById('lb-next');

    // Create navigation if missing
    if (!prevBtn) {
        prevBtn = document.createElement('button');
        prevBtn.id = 'lb-prev';
        prevBtn.className = 'lightbox-nav-btn lightbox-prev';
        prevBtn.innerHTML = '&#10094;'; // Left arrow
        prevBtn.onclick = function (e) { e.stopPropagation(); lightboxPrev(); };
        overlay.appendChild(prevBtn);
    }

    if (!nextBtn) {
        nextBtn = document.createElement('button');
        nextBtn.id = 'lb-next';
        nextBtn.className = 'lightbox-nav-btn lightbox-next';
        nextBtn.innerHTML = '&#10095;'; // Right arrow
        nextBtn.onclick = function (e) { e.stopPropagation(); lightboxNext(); };
        overlay.appendChild(nextBtn);
    }

    // Show/Hide buttons based on items count
    if (lightboxItems.length > 1) {
        prevBtn.style.display = 'flex';
        nextBtn.style.display = 'flex';
    } else {
        prevBtn.style.display = 'none';
        nextBtn.style.display = 'none';
    }

    content.innerHTML = '<p>Načítám...</p>';

    var xhr = new XMLHttpRequest();
    xhr.open('GET', ajaxUrl, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            content.innerHTML = xhr.responseText;
            initializeProductDetailScripts(content);
        } else if (xhr.readyState === 4) {
            content.innerHTML = '<p>Chyba při načítání obsahu.</p>';
        }
    };
    xhr.send();
}

function lightboxPrev() {
    if (lightboxItems.length <= 1) return;
    lightboxIndex--;
    if (lightboxIndex < 0) lightboxIndex = lightboxItems.length - 1;
    openLightbox(lightboxItems[lightboxIndex], lightboxIndex);
}

function lightboxNext() {
    if (lightboxItems.length <= 1) return;
    lightboxIndex++;
    if (lightboxIndex >= lightboxItems.length) lightboxIndex = 0;
    openLightbox(lightboxItems[lightboxIndex], lightboxIndex);
}

function closeLightbox() {
    var overlay = document.getElementById('lightbox-overlay');
    var content = document.getElementById('lightbox-content');
    if (!overlay) return;
    document.body.classList.remove('lightbox-open');
    overlay.classList.remove('is-visible');
    content.innerHTML = '';
}

// Global Key Handler for Lightbox Arrows
document.addEventListener('keydown', function (e) {
    if (document.body.classList.contains('gallery-active')) return;
    if (!document.body.classList.contains('lightbox-open')) return;

    if (e.key === 'ArrowLeft') lightboxPrev();
    if (e.key === 'ArrowRight') lightboxNext();
});


// --- GLOBÁLNÍ FUNKCE PRO LIGHTBOX (ZOOM) ---
function openImageZoom(imageUrl) {
    var zoomOverlay = document.getElementById('image-zoom-overlay');
    var zoomContent = document.getElementById('image-zoom-content');
    if (!zoomOverlay || !zoomContent) return;
    zoomContent.src = imageUrl;
    zoomOverlay.classList.add('is-visible');
    document.body.classList.add('zoom-open');
}
function closeImageZoom() {
    var zoomOverlay = document.getElementById('image-zoom-overlay');
    var zoomContent = document.getElementById('image-zoom-content');
    if (!zoomOverlay) return;
    zoomOverlay.classList.remove('is-visible');
    document.body.classList.remove('zoom-open');
    zoomContent.src = '';
}


// --- GLOBÁLNÍ FUNKCE PRO VYSOUVACÍ KOŠÍK ---
function openSlideCart(htmlContent) {
    var overlay = document.getElementById('slide-cart-overlay');
    var cart = document.getElementById('slide-out-cart');
    // If elements don't exist, try to create them (optional, but good for robustness)
    if (!overlay || !cart) return;

    document.body.classList.add('cart-open');
    overlay.classList.add('is-visible');
    cart.classList.add('is-visible');

    // Safety check: ensure htmlContent is a string and not an event object
    if (htmlContent && typeof htmlContent === 'string') {
        var contentContainer = document.getElementById('slide-cart-content');
        if (contentContainer) {
            contentContainer.innerHTML = htmlContent;
        }
    } else {
        updateCartContents();
    }
}
function closeSlideCart() {
    var overlay = document.getElementById('slide-cart-overlay');
    var cart = document.getElementById('slide-out-cart');
    if (!overlay || !cart) return;
    document.body.classList.remove('cart-open');
    overlay.classList.remove('is-visible');
    cart.classList.remove('is-visible');
}
function updateCartBadge(itemCount) {
    var badge = document.getElementById('cart-badge');
    if (!badge) return;
    if (itemCount > 0) {
        badge.textContent = itemCount;
        badge.style.display = 'flex';
    } else {
        badge.style.display = 'none';
    }
}
function updateCartContents() {
    var slideCartContainer = document.getElementById('slide-cart-content');
    var checkoutCartContainer = document.getElementById('checkout-cart-content');
    if (slideCartContainer) slideCartContainer.innerHTML = '<p>Načítám...</p>';
    if (checkoutCartContainer) checkoutCartContainer.innerHTML = '<p>Načítám...</p>';
    var xhr = new XMLHttpRequest();
    xhr.open('GET', '/cart-ajax?action=get', true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            if (slideCartContainer) slideCartContainer.innerHTML = xhr.responseText;
            if (checkoutCartContainer) checkoutCartContainer.innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}


// --- PŘEPOČET CENY SLUŽEBA (SHARED) ---
function recalculateTotal() {
    var basePriceEl = document.getElementById('base-cart-price');
    var finalPriceEl = document.getElementById('final-price');
    var form = document.getElementById('checkout-form');

    if (basePriceEl && form) {
        // Robustní parsování basePrice (odstranění mezer)
        var basePrice = parseFloat(basePriceEl.value.replace(/\s/g, '').replace(',', '.')) || 0;

        // VAT EXEMPTION DETECTION (EU B2B logic)
        var dicVal = (form.querySelector('input[name="dic"]')?.value || '').trim();
        var selectedCountry = form.querySelector('input[name="country"]:checked')?.value || 'cz';
        var isVatExempt = (selectedCountry !== 'cz' && dicVal !== '');

        // 1. Nejprve aktualizujeme ceny dopravy podle aktuálního košíku
        console.log('Recalculate: basePrice=' + basePrice + ', country=' + selectedCountry + ', isVatExempt=' + isVatExempt);
        updateShippingPrices(basePrice, selectedCountry);


        var shippingPrice = 0;
        var paymentPrice = 0;

        var selectedShipping = form.querySelector('input[name="shipping"]:checked');
        if (selectedShipping) {
            shippingPrice = parseFloat(selectedShipping.getAttribute('data-price')) || 0;
        }

        var selectedPayment = form.querySelector('input[name="payment"]:checked');
        if (selectedPayment) {
            paymentPrice = parseFloat(selectedPayment.getAttribute('data-price')) || 0;
        }

        var total = basePrice + shippingPrice + paymentPrice;

        if (isVatExempt) {
            total = total / 1.21;
        }

        console.log('Recalculate: shippingPrice=' + shippingPrice + ', paymentPrice=' + paymentPrice + ', basePrice=' + basePrice + ', total=' + total + ' (Exempt: ' + isVatExempt + ')');

        // Formátování ceny
        var symbol = (window.shopSettings && window.shopSettings.currency_symbol) ? window.shopSettings.currency_symbol : 'Kč';
        var co = (window.shopSettings && window.shopSettings.checkout_rounding) ? window.shopSettings.checkout_rounding : {};
        var decimals = (co.decimals !== undefined) ? co.decimals : ((window.shopSettings && window.shopSettings.currency_decimals !== undefined) ? window.shopSettings.currency_decimals : 2);
        var rounding = (co.rounding) ? co.rounding : ((window.shopSettings && window.shopSettings.currency_rounding) ? window.shopSettings.currency_rounding : 'math');

        var factor = Math.pow(10, decimals);
        var roundedTotal = total;
        if (rounding === 'up') roundedTotal = Math.ceil(total * factor) / factor;
        else if (rounding === 'down') roundedTotal = Math.floor(total * factor) / factor;
        else roundedTotal = Math.round(total * factor) / factor;

        var formatted = roundedTotal.toFixed(decimals).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " " + symbol;

        // Update ALL final-price elements (both in checkout and slide cart)
        document.querySelectorAll('#final-price, .cart-total-price').forEach(function (el) {
            el.textContent = formatted;
        });

        // Update labels for VAT
        var totalLabels = document.querySelectorAll('.cart-total span:first-child');
        totalLabels.forEach(function (lbl) {
            if (isVatExempt) {
                lbl.innerHTML = 'Celkem k úhradě <strong>(bez DPH)</strong>:';
                if (!lbl.parentNode.querySelector('.vat-exempt-note')) {
                    var note = document.createElement('div');
                    note.className = 'vat-exempt-note';
                    note.style.fontSize = '0.7em';
                    note.style.color = '#c65102';
                    note.style.marginTop = '4px';
                    note.textContent = 'Osvobozeno od DPH (§ 64 ZDPH)';
                    lbl.parentNode.appendChild(note);
                }
            } else {
                lbl.innerHTML = 'Celkem k úhradě (včetně DPH):';
                var note = lbl.parentNode.querySelector('.vat-exempt-note');
                if (note) note.remove();
            }
        });

    }
}

function updateShippingPrices(cartTotal, country) {
    var form = document.getElementById('checkout-form');
    if (!form) return;

    form.querySelectorAll('input[name="shipping"]').forEach(function (inp) {
        var ratesJson = inp.getAttribute('data-rates');
        if (ratesJson) {
            try {
                var rates = JSON.parse(ratesJson);
                var countryRules = rates[country] || rates['cz'] || [];
                var bestPrice = 0;
                var maxFrom = -1;

                countryRules.forEach(function (rule) {
                    console.log('Checking rule: from=' + rule.from + ', price=' + rule.price + ' against cartTotal=' + cartTotal);
                    if (cartTotal >= rule.from && rule.from > maxFrom) {
                        bestPrice = rule.price;
                        maxFrom = rule.from;
                    }
                });
                console.log('Best price found for ' + inp.value + ': ' + bestPrice);


                inp.setAttribute('data-price', bestPrice);

                // Update UI label
                var row = inp.closest('.shipping-method-row');
                var priceDisplay = row ? row.querySelector('.price') : null;
                if (priceDisplay) {
                    if (bestPrice === 0) {
                        priceDisplay.textContent = 'zdarma';
                    } else {
                        var symbol = (window.shopSettings && window.shopSettings.currency_symbol) ? window.shopSettings.currency_symbol : 'Kč';
                        var formatted = bestPrice.toLocaleString('cs-CZ', { minimumFractionDigits: 0, maximumFractionDigits: 2 }).replace('.', ',') + " " + symbol;
                        priceDisplay.textContent = formatted;
                    }
                }
            } catch (e) { console.error("Chyba při parsování sazeb pro dopravu", inp.value, e); }
        }
    });
}


// --- GLOBÁLNÍ FUNKCE PRO OVLÁDÁNÍ KOŠÍKU ---
function setupCartListeners(container) {
    container.addEventListener('click', function (e) {
        var addAccBtn = e.target.closest('.add-accessory-to-cart-btn');
        if (addAccBtn) {
            e.preventDefault();
            var productId = addAccBtn.getAttribute('data-product-id');
            if (productId) {
                addAccessoryToCart(productId, addAccBtn);
            }
            return;
        }

        var sku = null, action = null, newQty = null;
        var removeBtn = e.target.closest('.cart-item-remove');
        if (removeBtn) {
            e.preventDefault(); sku = removeBtn.getAttribute('data-sku'); action = 'remove';
        }
        var plusBtn = e.target.closest('.cart-qty-plus');
        if (plusBtn) {
            e.preventDefault(); sku = plusBtn.getAttribute('data-sku'); action = 'update';
            var input = container.querySelector('.cart-qty-input[data-sku="' + sku + '"]');
            var step = parseFloat(input.getAttribute('step')) || 1;
            newQty = parseFloat(input.value) + step;
        }
        var minusBtn = e.target.closest('.cart-qty-minus');
        if (minusBtn) {
            e.preventDefault(); sku = minusBtn.getAttribute('data-sku'); action = 'update';
            var input = container.querySelector('.cart-qty-input[data-sku="' + sku + '"]');
            var step = parseFloat(input.getAttribute('step')) || 1;
            newQty = parseFloat(input.value) - step;
            if (newQty < 0) newQty = 0;
        }
        if (action && sku) {
            var formData = new FormData();
            formData.append('action', action);
            formData.append('sku', sku);
            if (newQty !== null) formData.append('quantity', newQty);

            // DETECT IF WE ARE ON CHECKOUT PAGE (for hiding the button)
            if (document.body.classList.contains('page-template-pokladna') || window.location.pathname.indexOf('pokladna') !== -1) {
                formData.append('is_checkout', '1');
            }

            var slideCartContainer = document.getElementById('slide-cart-content');
            var checkoutCartContainer = document.getElementById('checkout-cart-content');

            // Capture scroll positions before update
            // We need to capture both, just in case
            // Capture scroll positions before update
            // We need to capture both, just in case
            var slideScroll = slideCartContainer ? slideCartContainer.scrollTop : 0;
            // Capture Window scroll to prevent jump if needed
            var windowScroll = window.scrollY || window.pageYOffset;
            var checkoutScroll = checkoutCartContainer ? checkoutCartContainer.scrollTop : 0;

            // Lock height to prevent collapse (which forces scroll to top)
            // Lock height to prevent collapse (which forces scroll to top)
            // Lock height to prevent collapse (which forces scroll to top)
            if (slideCartContainer) {
                slideCartContainer.style.height = slideCartContainer.offsetHeight + 'px';
            }
            if (checkoutCartContainer) {
                checkoutCartContainer.style.height = checkoutCartContainer.offsetHeight + 'px';
            }

            // Don't wipe content, just add loading state
            if (slideCartContainer) slideCartContainer.classList.add('is-loading');
            if (checkoutCartContainer) checkoutCartContainer.classList.add('is-loading');

            var xhr = new XMLHttpRequest();
            xhr.open('POST', '/cart_ajax.php', true);
            xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    if (slideCartContainer) slideCartContainer.classList.remove('is-loading');
                    if (checkoutCartContainer) checkoutCartContainer.classList.remove('is-loading');
                    try {
                        var response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // GA4 Tracking for additions (increase quantity)
                            if (typeof gtag === 'function' && action === 'update' && newQty > (parseInt(input.value) || 0) && response.sku && response.name) {
                                const diffQty = newQty - (parseInt(input.value) || 0);
                                const unitPrice = parseFloat(response.price) || 0;
                                const eventData = {
                                    currency: 'CZK',
                                    value: unitPrice * diffQty,
                                    items: [{
                                        item_id: response.sku,
                                        item_name: response.name,
                                        price: unitPrice,
                                        quantity: diffQty
                                    }]
                                };
                                gtag('event', 'add_to_cart', eventData);
                                if (typeof fbq === 'function') {
                                    fbq('track', 'AddToCart', {
                                        content_ids: [response.sku],
                                        content_type: 'product',
                                        value: unitPrice * diffQty,
                                        currency: 'CZK'
                                    });
                                }
                                if (window.shopSettings && window.shopSettings.sem_id) {
                                    const novatUnitPrice = parseFloat((unitPrice / 1.21).toFixed(2));
                                    if (typeof window.SEM === 'function') {
                                        if (typeof window.SEM === 'function') window.SEM('track', 'AddToCart', {
                                            currency: 'CZK',
                                            value: parseFloat((novatUnitPrice * (typeof diffQty !== 'undefined' ? diffQty : qty)).toFixed(2)),
                                            content_type: 'product',
                                            contents: [{ id: response.sku, content_name: response.name, unit_price: unitPrice, quantity: (typeof diffQty !== 'undefined' ? diffQty : qty) }]
                                        });
                                    }
                                }
                                console.log('GA4 add_to_cart (qty increase) sent:', eventData);
                            }
                            if (slideCartContainer) {
                                // Restore scroll before removing minHeight if possible, or after
                                slideCartContainer.innerHTML = response.cart_html;
                                slideCartContainer.scrollTop = slideScroll;

                                // Unlock height after a moment
                                setTimeout(function () {
                                    slideCartContainer.style.height = '';
                                    // Ensure scroll check again
                                    slideCartContainer.scrollTop = slideScroll;
                                }, 50);
                            }
                            if (checkoutCartContainer) {
                                checkoutCartContainer.innerHTML = response.cart_html;
                                checkoutCartContainer.scrollTop = checkoutScroll;
                                // Restore window scroll immediately after HTML injection
                                window.scrollTo(0, windowScroll);
                                setTimeout(function () {
                                    checkoutCartContainer.style.height = '';
                                }, 50);
                                // TRIGGER RECALCULATION
                                recalculateTotal();
                            }
                            updateCartBadge(response.item_count);
                        }
                    } catch (e) { }
                }
            };
            xhr.send(formData);
        }
    });
}


function addAccessoryToCart(productId, btn) {
    if (!productId) return;
    if (btn && btn.classList.contains('is-loading')) return;

    if (btn) {
        btn.classList.add('is-loading');
    }

    var formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', productId);
    formData.append('quantity', 1);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '/cart_ajax.php', true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (btn) {
                btn.classList.remove('is-loading');
            }
            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        updateCartContents();
                        updateCartBadge(response.item_count || response.total_items);
                        if (typeof showNotification === 'function') {
                            showNotification(response.message || 'Položka byla přidána do košíku.', 'success');
                        }
                    } else {
                        if (typeof showNotification === 'function') {
                            showNotification(response.message || 'Chyba při přidávání do košíku.', 'error');
                        }
                    }
                } catch (e) {
                    console.error(e);
                }
            }
        }
    };
    xhr.send(formData);
}


// --- 10. LOGIKA PRO POKLADNU (S PŘEPOČTEM CENY) ---
function initializeCheckoutForm() {
    var form = document.getElementById('checkout-form');
    if (!form) return;

    var step1 = document.getElementById('step-1');
    var step2 = document.getElementById('step-2');
    var ind1 = document.getElementById('indicator-step-1');
    var ind2 = document.getElementById('indicator-step-2');
    var btnGoStep2 = document.getElementById('btn-go-to-step-2');
    var btnBackStep1 = document.getElementById('btn-back-to-step-1');

    function showStep(stepNumber) {
        var sameContainer = document.getElementById('delivery-same-container');
        var step2WidgetInfo = document.getElementById('step2-widget-info');
        var step2WidgetName = document.getElementById('step2-widget-name');
        var deliveryWrap = document.getElementById('delivery-address-wrapper');
        var shipping = form.querySelector('input[name="shipping"]:checked');

        if (stepNumber === 1) {
            step1.style.display = 'block';
            step2.style.display = 'none';
            ind1.classList.add('active');
            ind2.classList.remove('active');

            // If shipping is widget, hide delivery same checkbox
            if (shipping && shipping.classList.contains('has-widget')) {
                if (sameContainer) sameContainer.style.display = 'none';
                if (deliveryWrap) {
                    deliveryWrap.style.maxHeight = '0';
                    deliveryWrap.style.opacity = '0';
                }
            } else {
                if (sameContainer) sameContainer.style.display = 'block';
            }

            window.scrollTo(0, 0);
        } else {
            step1.style.display = 'none';
            step2.style.display = 'block';
            ind1.classList.remove('active');
            ind2.classList.add('active');

            if (shipping && shipping.classList.contains('has-widget')) {
                var widgetType = shipping.getAttribute('data-widget');
                var typeId = (widgetType === 'packeta') ? 'zasilkovna' : (widgetType === 'ppl' ? 'ppl' : 'dpd');
                var pointNameInput = document.getElementById(typeId + '_name');
                var pointName = pointNameInput ? pointNameInput.value : '';

                if (step2WidgetInfo) step2WidgetInfo.style.display = 'block';
                if (step2WidgetName) step2WidgetName.textContent = pointName;
            } else {
                if (step2WidgetInfo) step2WidgetInfo.style.display = 'none';
            }

            window.scrollTo(0, 0);
        }
    }

    if (btnGoStep2) {
        btnGoStep2.addEventListener('click', function () {
            var isShippingFirst = !!step1.querySelector('.delivery-shipping-box');
            if (isShippingFirst) {
                var shipping = form.querySelector('input[name="shipping"]:checked');
                var payment = form.querySelector('input[name="payment"]:checked');
                if (!shipping) { showNotification('Vyberte prosím způsob dopravy.', 'warning'); return; }
                if (shipping.classList.contains('has-widget')) {
                    var widgetType = shipping.getAttribute('data-widget');
                    var typeId = (widgetType === 'packeta') ? 'zasilkovna' : (widgetType === 'ppl' ? 'ppl' : (widgetType === 'gls' ? 'gls' : 'dpd'));
                    var pointIdInput = document.getElementById(typeId + '_id');
                    if (!pointIdInput || !pointIdInput.value) { showNotification('Pro zvolenou dopravu musíte vybrat výdejní místo.', 'warning'); return; }
                }
                if (!payment) { showNotification('Vyberte prosím způsob platby.', 'warning'); return; }
            } else {
                var requiredFields = step1.querySelectorAll('input[required]');
                var firstInvalid = null;
                var allValid = true;

                requiredFields.forEach(function (f) {
                    if (f.offsetParent === null) {
                        f.classList.remove('error');
                        return;
                    }
                    if (!f.value.trim() || (f.type === 'email' && !f.value.includes('@'))) {
                        f.classList.add('error');
                        allValid = false;
                        if (!firstInvalid) firstInvalid = f;
                    } else {
                        f.classList.remove('error');
                    }
                });

                if (!allValid) {
                    if (firstInvalid) firstInvalid.focus();
                    showNotification('Prosím vyplňte všechna povinná pole správně.', 'warning');
                    return;
                }
            }

            showStep(2);
        });
    }

    form.addEventListener('submit', function (e) {
        // If we are in step 1, don't allow submit but try to go to step 2
        if (step1.style.display !== 'none') {
            e.preventDefault();
            btnGoStep2.click();
            return;
        }

        var isShippingFirst = !!step1.querySelector('.delivery-shipping-box');
        if (!isShippingFirst) {
            // Validate Step 2 - Shipping & Payment
            var shipping = form.querySelector('input[name="shipping"]:checked');
            var payment = form.querySelector('input[name="payment"]:checked');

            if (!shipping) {
                e.preventDefault();
                showNotification('Vyberte prosím způsob dopravy.', 'warning');
                return;
            }

            if (shipping.classList.contains('has-widget')) {
                var widgetType = shipping.getAttribute('data-widget');
                var typeId = (widgetType === 'packeta') ? 'zasilkovna' : (widgetType === 'ppl' ? 'ppl' : (widgetType === 'gls' ? 'gls' : 'dpd'));
                var pointIdInput = document.getElementById(typeId + '_id');
                var pointId = pointIdInput ? pointIdInput.value : '';
                if (!pointId) {
                    e.preventDefault();
                    showNotification('Pro zvolenou dopravu musíte vybrat výdejní místo.', 'warning');
                    return;
                }
            }

            if (!payment) {
                e.preventDefault();
                showNotification('Vyberte prosím způsob platby.', 'warning');
                return;
            }
        } else {
            var requiredFields = step2.querySelectorAll('input[required]');
            var firstInvalid = null;
            var allValid = true;

            requiredFields.forEach(function (f) {
                if (f.offsetParent === null) {
                    f.classList.remove('error');
                    return;
                }
                if (!f.value.trim() || (f.type === 'email' && !f.value.includes('@'))) {
                    f.classList.add('error');
                    allValid = false;
                    if (!firstInvalid) firstInvalid = f;
                } else {
                    f.classList.remove('error');
                }
            });

            if (!allValid) {
                e.preventDefault();
                if (firstInvalid) firstInvalid.focus();
                showNotification('Prosím vyplňte všechna povinná pole správně.', 'warning');
                return;
            }
        }

        // Terms Check
        var terms = document.getElementById('f_terms');
        if (terms && !terms.checked) {
            e.preventDefault();
            showNotification('Pro dokončení objednávky musíte souhlasit s obchodními podmínkami.', 'warning');
            return;
        }
    });
    if (btnBackStep1) btnBackStep1.addEventListener('click', function () { showStep(1); });


    // --- PŘEPOČET CENY Logic removed from here and moved to shared scope ---
    // But we need to keep listeners

    // Listeners for shipping/payment changes
    // Using event delegation or direct attach?
    // Logic below was not fully visible but we can assume listeners were attached or need to be.
    // Based on original file lines 800+ (not shown fully), there were likely listeners calling recalculateTotal.
    // We will re-add them below.

    var inputs = form.querySelectorAll('input[name="shipping"], input[name="payment"], input[name="country"]');
    inputs.forEach(function (inp) {
        inp.addEventListener('change', recalculateTotal);
    });

    var dicInput = form.querySelector('input[name="dic"]');
    if (dicInput) {
        dicInput.addEventListener('input', recalculateTotal);
    }

    // Initial calc
    recalculateTotal();

    // Continue with widgets logic...
    var shippingWidgetOverlay = document.getElementById('shipping-widget-overlay');
    var shippingWidgetClose = document.getElementById('shipping-widget-close');
    var shippingWidgetContent = document.getElementById('shipping-widget-content');
    var openWidgetBtns = document.querySelectorAll('.btn-open-widget');
    var checkoutPplMapActive = false;

    if (shippingWidgetClose) {
        shippingWidgetClose.addEventListener('click', function () {
            checkoutPplMapActive = false;
            shippingWidgetOverlay.style.display = 'none';
            var m = document.getElementById('ppl-parcelshop-map');
            if (m) m.style.display = 'none';
        });
    }

    function openPacketaWidget() {
        var apiKey = 'a033c6f5889374c4';
        if (typeof Packeta === 'undefined') { showNotification('Chyba: Knihovna Zásilkovny se nenačetla.', 'error'); return; }
        var selectedCountry = form.querySelector('input[name="country"]:checked')?.value || 'cz';
        var options = { country: selectedCountry, language: (selectedCountry === 'sk' ? 'sk' : 'cs') };
        Packeta.Widget.pick(apiKey, function (point) {
            if (point) {
                saveWidgetSelection('zasilkovna', point.id, point.name || point.nameStreet);
            }
        }, options);
    }

    function openPplWidget(retries) {
        if (typeof retries === 'undefined') {
            retries = 0;
            checkoutPplMapActive = true;

            var container = document.getElementById('ppl-parcelshop-map');
            if (container) {
                // DO NOT clear innerHTML! PPL might have already injected scripts/checkers there.
                var selectedCountry = (form.querySelector('input[name="country"]:checked')?.value || 'cz').toLowerCase();
                var shipping = form.querySelector('input[name="shipping"]:checked');
                var shippingName = shipping ? shipping.closest('.shipping-method-row').querySelector('span').textContent : '';

                // Robust check for SK
                var isSk = (selectedCountry === 'sk' ||
                    shippingName.toLowerCase().indexOf('slovensko') !== -1 ||
                    shippingName.toLowerCase().indexOf('slovenská') !== -1);

                var activeCountry = isSk ? 'SK' : 'CZ';
                var activeLang = isSk ? 'sk' : 'cs';

                console.log('PPL Widget requested. Country:', activeCountry, 'Lang:', activeLang, 'Shipping:', shippingName);
                container.setAttribute('data-country', activeCountry);
                container.setAttribute('data-language', activeLang);
                container.style.display = 'block';
            }
        }
        if (!checkoutPplMapActive) return;

        var container = document.getElementById('ppl-parcelshop-map');
        shippingWidgetOverlay.style.display = 'flex';

        window.removeEventListener('message', receivePplMessage);
        window.addEventListener('message', receivePplMessage);
        document.removeEventListener('ppl-parcelshop-map', receivePplCustomEvent);
        document.addEventListener('ppl-parcelshop-map', receivePplCustomEvent);

        setTimeout(function () {
            if (!checkoutPplMapActive) return;
            var pplApi = window.ppl || window.PPL || (typeof ppl !== 'undefined' ? ppl : null);
            if (pplApi && pplApi.parcelshop) {
                console.log('Initializing PPL Map (Checkout Robust)...');
                checkoutPplMapActive = false; // Stop further retries
                var selectedCountry = (form.querySelector('input[name="country"]:checked')?.value || 'cz').toLowerCase();
                var shipping = form.querySelector('input[name="shipping"]:checked');
                var shippingName = shipping ? shipping.closest('.shipping-method-row').querySelector('span').textContent : '';

                var isSk = (selectedCountry === 'sk' ||
                    shippingName.toLowerCase().indexOf('slovensko') !== -1 ||
                    shippingName.toLowerCase().indexOf('slovenská') !== -1);

                var activeCountry = isSk ? 'SK' : 'CZ';
                var activeLang = isSk ? 'sk' : 'cs';

                try {
                    pplApi.parcelshop.map({
                        elementId: 'ppl-parcelshop-map',
                        language: activeLang,
                        country: activeCountry
                    });
                } catch (e) {
                    console.warn('PPL manual init:', e);
                }
            } else {
                if (retries < 30 && checkoutPplMapActive) {
                    openPplWidget(retries + 1);
                } else if (retries >= 30) {
                    // Check if map actually appeared via auto-init before alerting
                    var hasContent = container && container.innerHTML.length > 50;
                    if (!hasContent) {
                        showNotification('Chyba: Knihovna PPL se nenačetla. Zkuste prosím stránku obnovit (F5).', 'error');
                    }
                }
            }
        }, 400);
    }

    function receivePplCustomEvent(event) {
        var point = event.detail;
        if (point && point.id) {
            processPplSelection(point);
        }
    }

    function processPplSelection(point) {
        if (!point) return;
        checkoutPplMapActive = false; // Stop retries
        saveWidgetSelection('ppl', point.id || point.ID || point.code || point.CODE, point.name + ', ' + point.street + ', ' + point.city);
        shippingWidgetOverlay.style.display = 'none';
        var m = document.getElementById('ppl-parcelshop-map');
        if (m) m.style.display = 'none';
        window.removeEventListener('message', receivePplMessage);
        document.removeEventListener('ppl-parcelshop-map', receivePplCustomEvent);
    }

    function receivePplMessage(event) {
        var data = event.data || event.detail;
        if (!data) return;
        if (typeof data === 'string') {
            try { data = JSON.parse(data); } catch (e) { return; }
        }

        var isSelection = data.event === 'pplPickupPointSelected' ||
            data.type === 'pplPickupPointSelected' ||
            data.event === 'pointSelected' ||
            data.event === 'onSelect';

        if (isSelection) {
            var point = data.point || data.data || data;
            if (point && (point.id || point.code || point.ID || point.CODE)) {
                processPplSelection(point);
            }
        }
    }

    // --- GLOBÁLNÍ FUNKCE PRO GLS CALLBACK ---
    window.processGlsCallback = function (id, fullName) {
        if (!id || !fullName) return;
        saveWidgetSelection('gls', id, fullName);

        // Close modal
        var over = document.getElementById('shipping-widget-overlay');
        var cont = document.getElementById('shipping-widget-content');
        if (over) over.style.display = 'none';
        if (cont) cont.innerHTML = '';

        window.removeEventListener('message', receiveGlsMessage);
    };

    function openGlsWidget() {
        var callbackUrl = encodeURIComponent('https://vakuovani.getup.cz/gls_callback.php');
        var selectedCountry = form.querySelector('input[name="country"]:checked')?.value || 'cz';
        var glsCountry = selectedCountry.toUpperCase();
        var glsLang = (selectedCountry === 'sk' ? 'sk' : 'cs');
        var glsUrl = 'https://ps-maps.gls-czech.com?find=1&header=0&ctrcode=' + glsCountry + '&lng=' + glsLang + '&returnUrl=' + callbackUrl;

        shippingWidgetOverlay.style.display = 'flex';
        shippingWidgetContent.innerHTML = '<iframe id="gls-iframe" src="' + glsUrl + '" style="width:100% !important; height:100% !important; border:none; display:block; position:relative; z-index:1;" allow="geolocation"></iframe>';

        window.removeEventListener("message", receiveGlsMessage);
        window.addEventListener("message", receiveGlsMessage, false);
    }

    function receiveGlsMessage(event) {
        var data = event.data;
        if (!data) return;

        console.log("GLS Event Received:", data);

        // Handle stringified JSON
        if (typeof data === 'string' && (data.indexOf('{') === 0 || data.indexOf('"') === 0)) {
            try { data = JSON.parse(data); } catch (e) { }
        }

        var point = null;
        if (data && typeof data === 'object') {
            // New structure found in logs: data.parcelshop.detail
            if (data.parcelshop && data.parcelshop.detail) point = data.parcelshop.detail;
            else if (data['gls-parcelshop-selected']) point = data['gls-parcelshop-selected'];
            else if (data.parcelshop) point = data.parcelshop;
            else if (data.glsParcelShop) point = data.glsParcelShop;
            else if (data.parcelshop_selected) point = data.parcelshop_selected;
            else if (data.pclshopid) point = data;
        }

        if (point && typeof point === 'object') {
            var id = point.pclshopid || point.id || point.parcelshop_id || point.Id;
            var name = point.name || point.shopname || point.Name || point.shop_name;
            var address = point.address || point.street || point.Street || point.address_street || "";
            var city = point.city || point.City || point.address_city || "";

            if (id && name) {
                console.log("GLS selected via postMessage:", id, name);
                window.processGlsCallback(id, name + (address ? ', ' + address : '') + (city ? ', ' + city : ''));
            }
        }
    }

    function saveWidgetSelection(type, id, name) {
        var typeId = (type === 'packeta' || type === 'zasilkovna') ? 'zasilkovna' : (type === 'ppl' ? 'ppl' : (type === 'gls' ? 'gls' : 'dpd'));
        document.getElementById(typeId + '_id').value = id;
        document.getElementById(typeId + '_name').value = name;
        var psCodeInput = document.getElementById('parcelshop_code');
        if (psCodeInput) psCodeInput.value = id;
        localStorage.setItem('pref_' + typeId + '_id', id);
        localStorage.setItem('pref_' + typeId + '_name', name);
        localStorage.setItem('pref_parcelshop_code', id);
        updateWidgetUI(typeId, name);
    }

    function updateWidgetUI(type, name) {
        // Find all radio inputs that use this widget type
        var radios = form.querySelectorAll('input[data-widget="' + type + '"]');

        radios.forEach(function (radioInput) {
            var container = radioInput.closest('.shipping-method-row');
            if (!container) return;

            var selectBtn = container.querySelector('.btn-select-point');
            if (selectBtn) selectBtn.style.display = 'none';

            var infoBox = container.querySelector('.selected-point-info');
            if (infoBox) {
                infoBox.style.display = 'flex';
                var nameSpan = infoBox.querySelector('.point-name');
                if (nameSpan) nameSpan.textContent = name;
            }
        });

        // Final refresh of buttons visibility based on current selection
        toggleWidgetButtons();
    }

    openWidgetBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
            var widgetType = this.getAttribute('data-widget');
            if (widgetType === 'packeta') openPacketaWidget();
            else if (widgetType === 'dpd') openDpdWidget();
            else if (widgetType === 'ppl') openPplWidget();
            else if (widgetType === 'gls') openGlsWidget();
        });
    });

    if (shippingWidgetClose) {
        shippingWidgetClose.addEventListener('click', function () {
            shippingWidgetOverlay.style.display = 'none';
            shippingWidgetContent.innerHTML = '';
        });
    }

    var shippingRadios = form.querySelectorAll('input[name="shipping"]');
    function toggleWidgetButtons() {
        document.querySelectorAll('.btn-select-point').forEach(function (b) { b.style.display = 'none'; });
        document.querySelectorAll('.selected-point-info').forEach(function (b) { b.style.display = 'none'; });
        var checked = form.querySelector('input[name="shipping"]:checked');
        if (checked && checked.classList.contains('has-widget')) {
            var widgetType = checked.getAttribute('data-widget');
            var typeId = (widgetType === 'packeta') ? 'zasilkovna' : (widgetType === 'ppl' ? 'ppl' : (widgetType === 'gls' ? 'gls' : 'dpd'));
            var pointIdInput = document.getElementById(typeId + '_id');
            var pointId = pointIdInput ? pointIdInput.value : '';
            var row = checked.closest('.shipping-method-row');
            if (pointId) {
                row.querySelector('.selected-point-info').style.display = 'flex';
            } else {
                row.querySelector('.btn-select-point').style.display = 'block';
            }
        } else {
            // Clear general parcelshop_code and specific IDs if switching to home delivery
            ['zasilkovna', 'ppl', 'gls', 'dpd'].forEach(function (t) {
                var el = document.getElementById(t + '_id');
                if (el) el.value = '';
                var elN = document.getElementById(t + '_name');
                if (elN) elN.value = '';
            });
            var psInput = document.getElementById('parcelshop_code');
            if (psInput) psInput.value = '';
        }
    }
    shippingRadios.forEach(function (r) { r.addEventListener('change', toggleWidgetButtons); });


    // --- C. ARES ---
    var btnLookup = document.getElementById('btn-company-lookup');
    var inputIco = document.getElementById('f_ico');

    function updateLookupButton() {
        if (!btnLookup) return;
        var countryChecked = form.querySelector('input[name="country"]:checked');
        var selectedCountry = (countryChecked ? countryChecked.value : 'cz');

        // Always show for CZ (ARES is free/built-in)
        if (selectedCountry === 'cz') {
            btnLookup.style.setProperty('display', 'inline-block', 'important');
        } else {
            var row = document.querySelector('.ares-search-row');
            var hasSkApi = row ? row.getAttribute('data-has-sk-api') === '1' : false;
            if (selectedCountry === 'sk' && !hasSkApi) {
                btnLookup.style.setProperty('display', 'none', 'important');
            } else {
                btnLookup.style.setProperty('display', 'inline-block', 'important');
            }
        }
        btnLookup.textContent = 'Vyplnit';
    }

    // Add listeners for country change to update button visibility
    form.querySelectorAll('input[name="country"]').forEach(function (radio) {
        radio.addEventListener('change', updateLookupButton);
    });

    if (btnLookup) {
        btnLookup.addEventListener('click', function () {
            var ico = inputIco.value;
            if (ico.length < 6) {
                var countryChecked = form.querySelector('input[name="country"]:checked');
                showNotification(countryChecked && countryChecked.value === 'sk' ? 'Zadajte platné IČO.' : 'Zadejte platné IČ.', 'warning');
                return;
            }

            var originalText = btnLookup.textContent;
            btnLookup.textContent = 'Hledám...';
            btnLookup.disabled = true;

            var countryChecked = form.querySelector('input[name="country"]:checked');
            var selectedCountry = (countryChecked ? countryChecked.value : 'cz');
            var endpoint = selectedCountry === 'sk' ? '/ajax_rpo.php' : '/ajax_ares.php';

            var xhr = new XMLHttpRequest();
            xhr.open('GET', endpoint + '?ico=' + encodeURIComponent(ico), true);
            xhr.onload = function () {
                btnLookup.textContent = originalText;
                btnLookup.disabled = false;
                if (xhr.status === 200) {
                    try {
                        var data = JSON.parse(xhr.responseText);
                        if (data.success) {
                            var companyEl = document.getElementById('f_company_name');
                            if (companyEl) companyEl.value = data.company;

                            document.getElementById('f_street').value = data.street;
                            if (data.house_number) {
                                document.getElementById('f_billing_house_number').value = data.house_number;
                            }
                            document.getElementById('f_city').value = data.city;
                            document.getElementById('f_zip').value = data.zip;
                            if (data.dic) document.getElementById('f_dic').value = data.dic;

                            ['f_company_name', 'f_street', 'f_billing_house_number', 'f_city', 'f_zip', 'f_dic'].forEach(id => {
                                var el = document.getElementById(id);
                                if (el) el.dispatchEvent(new Event('change'));
                            });
                        } else { showNotification('Chyba: ' + data.message, 'error'); }
                    } catch (e) { showNotification('Chyba při zpracování dat.', 'error'); }
                }
            };
            xhr.send();
        });
    }

    // Initial state
    updateLookupButton();


    // --- D. OBNOVENÍ STAVU (RESTORE STATE) & AUTO-SAVE ---
    function autoSaveProfile() {
        // Only if logged in (check existence of user dropdown or similar)
        if (!document.getElementById('user-icon-btn')) return;

        var countryCode = document.querySelector('input[name="country"]:checked')?.value || 'cz';
        var countryName = (countryCode === 'sk') ? 'Slovensko' : 'Česká republika';

        var data = {
            email: document.getElementById('f_email')?.value || '',
            phone: document.getElementById('f_phone')?.value || '',
            fullname: document.getElementById('f_fullname')?.value || '',
            street: document.getElementById('f_street')?.value || '',
            house_number: document.getElementById('f_billing_house_number')?.value || '',
            city: document.getElementById('f_city')?.value || '',
            zip: document.getElementById('f_zip')?.value || '',
            country: countryName,
            ico: document.getElementById('f_ico')?.value || '',
            dic: document.getElementById('f_dic')?.value || '',
            company_name: document.getElementById('f_company_name')?.value || '',
            // Delivery
            delivery_name: document.getElementById('d_fullname')?.value || '',
            delivery_street: document.getElementById('d_street')?.value || '',
            delivery_house_number: document.getElementById('d_house_number')?.value || '',
            delivery_city: document.getElementById('d_city')?.value || '',
            delivery_zip: document.getElementById('d_zip')?.value || ''
        };

        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/api_auth.php?action=update_profile', true);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log('Profile auto-saved');
            }
        };
        xhr.send(JSON.stringify(data));
    }

    var debouncedAutoSave = debounce(autoSaveProfile, 1000);

    function restoreState() {
        // 1. Textová pole
        var persistFields = ['f_email', 'f_phone', 'f_fullname', 'f_street', 'f_billing_house_number', 'f_city', 'f_zip', 'f_ico', 'f_dic', 'd_fullname', 'd_street', 'd_house_number', 'd_city', 'd_zip'];
        var isLoggedIn = document.getElementById('checkout-root-container')?.getAttribute('data-logged-in') === '1';

        persistFields.forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;

            var savedVal = localStorage.getItem(id);
            var currentVal = el.value; // Filled by PHP from DB

            if (isLoggedIn) {
                // If logged in, prioritize DB (currentVal). 
                // We only use localStorage if DB is empty and localStorage is not.
                if (!currentVal && savedVal) {
                    el.value = savedVal;
                } else if (currentVal) {
                    // Sync localStorage with DB if they differ
                    if (currentVal !== savedVal) {
                        localStorage.setItem(id, currentVal);
                    }
                }
            } else {
                // Guest: standard localStorage behavior
                if (savedVal) {
                    el.value = savedVal;
                }
            }

            el.addEventListener('input', function () {
                localStorage.setItem(id, this.value);
                debouncedAutoSave();
            });
            // Also listen for change to catch ARES/Autofill better
            el.addEventListener('change', function () {
                localStorage.setItem(id, this.value);
                debouncedAutoSave();
            });
        });

        // 2. Výdejní místa
        ['zasilkovna', 'dpd', 'ppl', 'gls'].forEach(function (type) {
            var savedId = localStorage.getItem('pref_' + type + '_id');
            var savedName = localStorage.getItem('pref_' + type + '_name');
            if (savedId && savedName) {
                var idInput = document.getElementById(type + '_id');
                var nameInput = document.getElementById(type + '_name');
                if (idInput) idInput.value = savedId;
                if (nameInput) nameInput.value = savedName;
                updateWidgetUI(type, savedName);
            }
        });

        var savedPsCode = localStorage.getItem('pref_parcelshop_code');
        if (savedPsCode) {
            var psCodeInput = document.getElementById('parcelshop_code');
            if (psCodeInput) psCodeInput.value = savedPsCode;
        }

        // 3. Rádia (Země -> Doprava -> Platba)
        // Musíme volat update funkce postupně, aby se odemkly další kroky

        var savedCountry = localStorage.getItem('pref_country');
        if (savedCountry) {
            var r = form.querySelector('input[name="country"][value="' + savedCountry + '"]');
            if (r) {
                r.checked = true;
                updateLookupButton();
                updateShippingOptions(); // Tím se odkryjí dopravy
            }
        }

        var savedShipping = localStorage.getItem('pref_shipping');
        if (savedShipping) {
            var r = form.querySelector('input[name="shipping"][value="' + savedShipping + '"]');
            // Zkusíme ho zaškrtnout, i když je skrytý, a pak zavoláme update
            if (r) {
                r.checked = true;
                updatePaymentOptions(); // Tím se odkryjí platby
                toggleWidgetButtons();
            }
        }

        var savedPayment = localStorage.getItem('pref_payment');
        if (savedPayment) {
            var r = form.querySelector('input[name="payment"][value="' + savedPayment + '"]');
            if (r) {
                r.checked = true;
            }
        }

        if (typeof recalculateTotal === 'function') {
            recalculateTotal();
        }

        // 4. Doručit na adresu - trigger logic
        var deliveryCheck = document.getElementById('f_delivery_same');
        var isLoggedIn = document.getElementById('checkout-root-container')?.getAttribute('data-logged-in') === '1';

        if (isLoggedIn && deliveryCheck) {
            localStorage.setItem('pref_delivery_same', deliveryCheck.checked ? '1' : '0');
        }

        var savedDeliverySame = localStorage.getItem('pref_delivery_same');
        if (savedDeliverySame !== null && deliveryCheck) {
            deliveryCheck.checked = (savedDeliverySame === '1');
            deliveryCheck.dispatchEvent(new Event('change'));
        }
    }



    // --- E. MANAŽER ZOBRAZENÍ + PŘEPOČET ---
    var countryRadios = form.querySelectorAll('input[name="country"]');
    var paymentRadios = form.querySelectorAll('input[name="payment"]');
    var paymentWrapper = document.getElementById('payment-options-wrapper');
    var paymentPlaceholder = document.getElementById('payment-placeholder');
    var allPaymentOptions = paymentWrapper.querySelectorAll('.payment-option');
    var allShippingOptions = document.getElementById('shipping-options-wrapper').querySelectorAll('.shipping-option');

    var deliveryCheck = document.getElementById('f_delivery_same');
    var deliveryWrap = document.getElementById('delivery-address-wrapper');
    if (deliveryCheck) {
        deliveryCheck.addEventListener('change', function () {
            localStorage.setItem('pref_delivery_same', this.checked ? '1' : '0');
            var dInputs = deliveryWrap.querySelectorAll('input');
            if (this.checked) {
                deliveryWrap.style.display = 'none';
                dInputs.forEach(function (i) {
                    i.required = false;
                    i.removeAttribute('required');
                });
            } else {
                deliveryWrap.style.display = 'block';
                deliveryWrap.style.maxHeight = '2000px';
                deliveryWrap.style.opacity = '1';
                deliveryWrap.style.marginTop = '20px';
                deliveryWrap.style.overflow = 'visible';
                dInputs.forEach(function (i) {
                    if (i.id !== 'd_fullname') { // Firm/Fullname in delivery is usually optional
                        i.required = true;
                        i.setAttribute('required', 'required');
                    }
                });
            }
        });
    }

    function updateActiveRadioRows() {
        form.querySelectorAll('.shipping-method-row, .payment-option').forEach(function (row) {
            var r = row.querySelector('input[type="radio"]');
            if (r && r.checked) row.classList.add('active');
            else row.classList.remove('active');
        });
    }

    function updatePaymentOptions() {
        var selectedCountryInput = form.querySelector('input[name="country"]:checked');
        var selectedCountry = selectedCountryInput ? selectedCountryInput.value : 'cz';
        var selectedShipping = form.querySelector('input[name="shipping"]:checked');

        for (var i = 0; i < allPaymentOptions.length; i++) {
            allPaymentOptions[i].classList.add('hidden-option');
        }

        if (selectedShipping) {
            paymentPlaceholder.classList.remove('is-visible');
            var shippingValue = selectedShipping.value;
            // Filter by BOTH shipping ID and country
            var selector = '.payment-option.country-' + selectedCountry + '.shipping-' + shippingValue;
            var visiblePayments = paymentWrapper.querySelectorAll(selector);
            for (var k = 0; k < visiblePayments.length; k++) {
                visiblePayments[k].classList.remove('hidden-option');
            }

            // Auto-select if current payment is hidden
            var activePayment = form.querySelector('input[name="payment"]:checked');
            if (!activePayment || activePayment.parentElement.classList.contains('hidden-option')) {
                var toSelect = paymentWrapper.querySelector(selector + '.is-default input[name="payment"]')
                    || paymentWrapper.querySelector(selector + ' input[name="payment"]');
                if (toSelect) {
                    toSelect.checked = true;
                }
            }


            toggleWidgetButtons();
            localStorage.setItem('pref_shipping', shippingValue);
        } else {
            paymentPlaceholder.classList.add('is-visible');
        }
        updateActiveRadioRows();
        recalculateTotal();
    }


    function updateShippingOptions() {
        var selectedCountry = form.querySelector('input[name="country"]:checked').value;
        localStorage.setItem('pref_country', selectedCountry);

        // Hide all shipping and payment options first
        for (var i = 0; i < allShippingOptions.length; i++) {
            allShippingOptions[i].classList.add('hidden-option');
        }
        for (var i = 0; i < allPaymentOptions.length; i++) {
            allPaymentOptions[i].classList.add('hidden-option');
        }

        // Show shipping for selected country
        var visibleShipping = document.querySelectorAll('.shipping-option.country-' + selectedCountry);
        for (var k = 0; k < visibleShipping.length; k++) {
            visibleShipping[k].classList.remove('hidden-option');
        }

        // Auto-select if none selected or the selected one is now hidden
        var activeShipping = form.querySelector('input[name="shipping"]:checked');
        if (!activeShipping || activeShipping.closest('.shipping-option').classList.contains('hidden-option')) {
            // Find a visible default or just the first visible
            var toSelect = document.querySelector('.shipping-option.country-' + selectedCountry + '.is-default input[name="shipping"]')
                || document.querySelector('.shipping-option.country-' + selectedCountry + ' input[name="shipping"]');
            if (toSelect) {
                toSelect.checked = true;
                toSelect.dispatchEvent(new Event('change'));
            }
        }

        updateActiveRadioRows();
        updatePaymentOptions();
    }


    countryRadios.forEach(r => r.addEventListener('change', function () {
        localStorage.setItem('pref_country', this.value);
        updateLookupButton();
        updateShippingOptions();
    }));
    form.querySelectorAll('input[name="shipping"]').forEach(r => r.addEventListener('change', updatePaymentOptions));
    paymentRadios.forEach(r => r.addEventListener('change', function () {
        localStorage.setItem('pref_payment', this.value);
        recalculateTotal(); // PŘEPOČÍTAT
    }));

    restoreState();
    updateShippingOptions();
}

// --- GLOBÁLNÍ FUNKCE PRO DETAIL PRODUKTU ---
function initializeProductDetailScripts(container) {
    var detailContainer = container.querySelector('.product-detail-container');
    if (!detailContainer) return;

    if (detailContainer.getAttribute('data-variants-system') === 'new') {
        console.log("Legacy initializeProductDetailScripts bypassed for new variants system.");
        initVariantSelection(detailContainer);
        return;
    }
    var jsonData = detailContainer.getAttribute('data-variants-json');
    var productData = null;
    if (jsonData) {
        try {
            productData = JSON.parse(jsonData);
        } catch (e) { console.error('Chyba při parsování JSON dat variant:', e); }
    }
    if (!productData || productData.length === 0) return;
    var form = detailContainer.querySelector('.detail-form');
    if (!form) return;
    var galleryImage = detailContainer.querySelector('#detail-main-image');
    var mainImageSrc = galleryImage ? galleryImage.getAttribute('data-main-image') : '';
    var priceVatEl = detailContainer.querySelector('#detail-price-vat');
    var priceNoVatEl = detailContainer.querySelector('#detail-price-novat');
    var availabilityEl = detailContainer.querySelector('#detail-availability');
    var skuEl = detailContainer.querySelector('#detail-sku');
    var stockEl = detailContainer.querySelector('#detail-stock-info');
    var addToCartBtn = detailContainer.querySelector('.btn-add-to-cart');
    var selectedSkuInput = form.querySelector('#selected-sku');
    var colorSelectors = form.querySelectorAll('[data-variant-type="color"]');
    var sizeSelectors = form.querySelectorAll('[data-variant-type="size"]');
    var defaultPriceVat = priceVatEl.textContent;
    var defaultPriceNoVat = priceNoVatEl.textContent;

    function updateVariantState() {
        var selectedColor = form.querySelector('[name="color"]:checked, select[name="color"] option:checked')?.value || null;
        var selectedSize = form.querySelector('[name="size"]:checked, select[name="size"] option:checked')?.value || null;
        if (selectedColor === "") selectedColor = null;
        if (selectedSize === "") selectedSize = null;
        var colorRequired = colorSelectors.length > 0;
        var sizeRequired = sizeSelectors.length > 0;
        var colorOk = !colorRequired || selectedColor !== null;
        var sizeOk = !sizeRequired || selectedSize !== null;
        var foundVariant = null, firstColorVariant = null;
        if (selectedColor) {
            for (var i = 0; i < productData.length; i++) {
                if (productData[i].colour == selectedColor) {
                    firstColorVariant = productData[i];
                    break;
                }
            }
        }
        if (colorOk && sizeOk) {
            for (var i = 0; i < productData.length; i++) {
                var v = productData[i];
                var colorMatch = !colorRequired || (v.colour == selectedColor);
                var sizeMatch = !sizeRequired || (v.size == selectedSize);
                if (colorMatch && sizeMatch) {
                    foundVariant = v;
                    break;
                }
            }
        }
        var variantToDisplay = foundVariant || firstColorVariant;
        if (variantToDisplay) {
            var price = parseFloat(variantToDisplay.your_price) || 0;
            var priceNoVat = price / 1.21;
            var rawStatus = (variantToDisplay.status && variantToDisplay.status.trim().toLowerCase() !== '') ? variantToDisplay.status.trim().toLowerCase() : '';
            var status = (rawStatus === 'actual') ? 'do 3 dnů' : 'není skladem';

            priceVatEl.textContent = price.toLocaleString('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kč';
            priceNoVatEl.textContent = '(' + priceNoVat.toLocaleString('cs-CZ', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' Kč bez DPH)';

            // Hide SKU (will be moved)
            if (skuEl) skuEl.style.display = 'none';
            if (selectedSkuInput) selectedSkuInput.value = variantToDisplay.sku;

            // Hide old availability
            if (availabilityEl) availabilityEl.style.display = 'none';

            // New Stock Logic
            var stockCount = parseInt(variantToDisplay.stock_count) || 0;
            // Force disable if no variant found (partial selection) ? 
            // Actually variantToDisplay is either foundVariant or firstColorVariant.
            // If foundVariant is null, we might not want to enable cart yet?

            // Logic:
            // If full variant selected (foundVariant) -> Check Stock -> Enable/Disable
            // If partial (variantToDisplay but !foundVariant) -> Disable?

            if (stockEl) {
                var stockTime = variantToDisplay.stock_last_updated;

                // Format Date: YYYY-MM-DD HH:MM:SS -> d.m.Y H:i
                var formattedTime = '';
                if (stockTime) {
                    try {
                        var dateParts = stockTime.split(' ');
                        var dParts = dateParts[0].split('-');
                        var tParts = dateParts[1].split(':');
                        formattedTime = dParts[2] + '.' + dParts[1] + '.' + dParts[0] + ' ' + tParts[0] + ':' + tParts[1];
                    } catch (e) { formattedTime = stockTime; }
                }

                var html = '';
                // Fix: Remove var to use outer scope variable
                // addToCartBtn is already defined in outer scope
                var qtyInput = container.querySelector('.quantity-input');

                // Determine if we should allow buying
                var canBuy = false;
                var stockStatusRaw = (variantToDisplay.stock_status) ? variantToDisplay.stock_status.trim().toLowerCase() : '';

                // Better stock status check
                if (stockCount > 0) {
                    canBuy = true;
                } else {
                    // Check text for "skladem" but NOT "není", "nejsou", "vyprodáno"
                    if (stockStatusRaw.indexOf('skladem') !== -1 &&
                        stockStatusRaw.indexOf('není') === -1 &&
                        stockStatusRaw.indexOf('nejsou') === -1 &&
                        stockStatusRaw.indexOf('nedostupné') === -1 &&
                        stockStatusRaw.indexOf('vyprodáno') === -1) {
                        canBuy = true;
                    }
                    if (stockStatusRaw.indexOf('do ') !== -1) {
                        // e.g. "do 3 dnů" -> usually allow buy (preorder)
                        canBuy = true;
                    }
                }

                // --- STOCK DISPLAY LOGIC FIX: ONLY SHOW IF VARIANT IS FULLY SELECTED ---
                if (foundVariant) {
                    // FLEX ROW START
                    html += '<div style="display: flex; justify-content: space-between; align-items: baseline; flex-wrap: wrap;">';
                    html += '<div>';

                    if (canBuy) {
                        // IN STOCK / PREORDER
                        stockEl.setAttribute('data-stock-status', 'in_stock'); // Robot friendly
                        var displayCount = (stockCount > 0) ? stockCount + ' ks' : 'Skladem';

                        // Use text from DB if available and 0 stock
                        if (stockCount <= 0 && (variantToDisplay.stock_status || variantToDisplay.status)) {
                            displayCount = variantToDisplay.stock_status || variantToDisplay.status;
                        }

                        html += '<span style="color: #28a745; font-size: 1.2em; font-weight: bold;">' + displayCount + '</span>';
                        if (formattedTime) {
                            html += '<span style="color: #aaa; font-size: 0.8em; margin-left: 10px;">(' + formattedTime + ')</span>';
                        }
                    } else {
                        // OUT OF STOCK
                        stockEl.setAttribute('data-stock-status', 'out_of_stock');
                        html += '<span style="color: #dc3545; font-size: 1.2em; font-weight: bold;">Není skladem</span>';
                        if (formattedTime) {
                            html += '<span style="color: #aaa; font-size: 0.8em; margin-left: 10px;">(' + formattedTime + ')</span>';
                        }
                    }

                    html += '</div>';
                    // SKU RIGHT
                    html += '<div style="font-weight: bold; color: #333;">Kód: ' + variantToDisplay.sku + '</div>';
                    html += '</div>';
                    // FLEX ROW END

                    if (canBuy && stockCount <= 0 && stockStatusRaw.indexOf('do ') === -1 && stockStatusRaw.indexOf('skladem') !== -1) {
                        // "Skladem (externě)" -> show delivery info?
                        html += '<div style="color: #888; font-size: 0.9em; margin-top: 2px;">do 3 dnů u vás</div>';
                    }
                } else {
                    // Variant not fully selected: Show generic message or nothing
                    // html = '<span style="color: #666;">Vyberte variantu pro zobrazení dostupnosti.</span>';
                    html = ''; // User prefers "nothing" until selected
                }

                stockEl.innerHTML = html;

                // Cart Button Logic
                if (addToCartBtn) {
                    if (canBuy) {
                        addToCartBtn.disabled = false;
                        addToCartBtn.innerHTML = CART_ICON_HTML;
                    } else {
                        addToCartBtn.disabled = true;
                        if (!foundVariant) {
                            addToCartBtn.innerHTML = 'Vyberte variantu';
                        } else {
                            addToCartBtn.innerHTML = 'Vyprodáno';
                        }
                    }
                }

                // Input Logic
                if (qtyInput) {
                    var pkgCount = parseInt(variantToDisplay.package_count) || 1;
                    if (pkgCount < 1) pkgCount = 1;

                    if (canBuy) {
                        qtyInput.disabled = false;
                        qtyInput.min = pkgCount;
                        qtyInput.step = pkgCount;
                        qtyInput.min = pkgCount;
                        qtyInput.step = pkgCount;

                        if (stockCount > 0) {
                            qtyInput.max = stockCount;
                        } else {
                            qtyInput.removeAttribute('max');
                        }

                        // Adjust current value if needed
                        var currVal = parseInt(qtyInput.value) || 0;
                        if (currVal < pkgCount || currVal % pkgCount !== 0) {
                            qtyInput.value = pkgCount;
                        } else if (stockCount > 0 && currVal > stockCount) {
                            qtyInput.value = Math.floor(stockCount / pkgCount) * pkgCount;
                        }
                    } else {
                        qtyInput.disabled = true;
                        if (!foundVariant) {
                            // Keep value if waiting for selection
                        } else {
                            qtyInput.value = pkgCount; // Show package count even if out of stock
                        }
                    }
                }
            }
            var packshot = '';
            // Prioritize main_photo (Editor/New System)
            if (variantToDisplay.main_photo) packshot = variantToDisplay.main_photo;
            // Then check image_url (Secondary Standard)
            else if (variantToDisplay.image_url) packshot = variantToDisplay.image_url;
            // Finally check packshot (Legacy)
            else if (variantToDisplay.packshot) packshot = variantToDisplay.packshot.trim();

            var newImageSrc = mainImageSrc;
            if (packshot !== '') {
                if (packshot.indexOf('http') === 0) {
                    newImageSrc = packshot;
                } else if (packshot.indexOf('uploads/') === 0 || packshot.indexOf('/uploads/') === 0 || packshot.indexOf('assets/') === 0 || packshot.indexOf('/assets/') === 0) {
                    newImageSrc = (packshot.indexOf('/') === 0) ? packshot : '/' + packshot;
                } else {
                    newImageSrc = 'https://akcniletaky.com/totalprotect/ftp_nove_obrazky/' + packshot;
                }
            }
            if (galleryImage.src !== newImageSrc) galleryImage.src = newImageSrc;
            var zoomLink = detailContainer.querySelector('#zoom-image-trigger');
            if (zoomLink) zoomLink.href = newImageSrc;
        } else {
            galleryImage.src = mainImageSrc;
            var zoomLink = detailContainer.querySelector('#zoom-image-trigger');
            if (zoomLink) zoomLink.href = mainImageSrc;
            priceVatEl.textContent = defaultPriceVat;
            priceNoVatEl.textContent = defaultPriceNoVat;
            availabilityEl.textContent = 'Zvolte variantu';
            availabilityEl.classList.remove('is-available');
            skuEl.textContent = '';
            selectedSkuInput.value = '';
            if (stockEl) stockEl.innerHTML = '';
            addToCartBtn.disabled = true;
            addToCartBtn.innerHTML = 'Vyberte variantu';
        }

        // --- UPDATE COLOR OPTIONS LABELS WITH STOCK (If Size Selected) ---
        if (selectedSize) {
            // 1. Handle SELECT
            var colorSelect = form.querySelector('select[name="color"]');
            if (colorSelect) {
                Array.from(colorSelect.options).forEach(opt => {
                    var cVal = opt.value;
                    if (!cVal) return; // Skip placeholder
                    // Find variant for this color + selectedSize
                    var v = productData.find(function (p) { return p.colour == cVal && p.size == selectedSize; });
                    var stock = v ? parseInt(v.stock_count) : 0;

                    // Clean previous count if any
                    var baseText = opt.textContent.split('(')[0].trim();

                    if (stock > 0) {
                        opt.textContent = baseText + ' (' + stock + ' ks)';
                        opt.classList.remove('out-of-stock-option');
                        opt.classList.add('in-stock-option');
                    } else {
                        opt.textContent = baseText + ' (Vyprodáno)';
                        opt.classList.remove('in-stock-option');
                        opt.classList.add('out-of-stock-option');
                    }
                });
            }

            // 2. Handle RADIOS
            var colorRadios = form.querySelectorAll('input[name="color"]');
            colorRadios.forEach(radio => {
                var cVal = radio.value;
                var v = productData.find(function (p) { return p.colour == cVal && p.size == selectedSize; });
                var stock = v ? parseInt(v.stock_count) : 0;

                var labelSpan = radio.nextElementSibling; // <span>ColorName</span>
                if (labelSpan) {
                    var baseText = labelSpan.innerText.split('(')[0].trim();
                    if (stock > 0) {
                        // Radio buttons CAN be styled nicely!
                        // We can use a flex/float approach here if needed, but keeping text simple for now to match select.
                        labelSpan.innerHTML = baseText + ' <span class="stock-badge-radio">(' + stock + ' ks)</span>';
                        radio.parentElement.classList.remove('out-of-stock-option');
                        radio.parentElement.classList.add('in-stock-option');
                    } else {
                        labelSpan.innerHTML = baseText + ' <span class="stock-badge-radio">(Vyprodáno)</span>';
                        radio.parentElement.classList.remove('in-stock-option');
                        radio.parentElement.classList.add('out-of-stock-option');
                    }
                }
            });
        } else {
            // Reset to clean names if no size selected
            var colorSelect = form.querySelector('select[name="color"]');
            if (colorSelect) {
                Array.from(colorSelect.options).forEach(opt => {
                    if (!opt.value) return;
                    opt.textContent = opt.textContent.split('(')[0].trim();
                    opt.classList.remove('out-of-stock-option');
                    opt.classList.remove('in-stock-option');
                });
            }
            var colorRadios = form.querySelectorAll('input[name="color"]');
            colorRadios.forEach(radio => {
                var labelSpan = radio.nextElementSibling;
                if (labelSpan) {
                    labelSpan.innerText = labelSpan.innerText.split('(')[0].trim();
                    // Remove span tags if any (innerText does it effectively if we reset text)
                    // Actually splitting by '(' works if logic is consistent.
                    radio.parentElement.classList.remove('out-of-stock-option');
                    radio.parentElement.classList.remove('in-stock-option');
                }
            });
        }
    }

    // ... [Inside updateDetailContent] ...
    updateVariantState();
} // END of updateDetailContent

// --- GLOBÁLNÍ FUNKCE PRO ZAVŘENÍ HLEDÁNÍ ---
function closeSearchModal() {
    var searchModal = document.getElementById('search-modal');
    var searchOverlay = document.getElementById('search-overlay');
    var searchInput = document.getElementById('search-input-field');
    var searchSuggester = document.getElementById('search-suggester');

    document.body.classList.remove('search-open');
    searchOverlay.classList.remove('is-visible');
    searchModal.classList.remove('is-visible');
    searchSuggester.innerHTML = '';
    searchInput.value = '';
}

// --- 10. FIXED: CONSOLIDATED GLOBAL AJAX FORM SUBMIT HANDLER ---
// This handler covers both the detail page and any other forms that add to cart or use data-ajax-submit.
// It prevents double-triggering by using a single delegated listener on document.
document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;

    // Identify if this is a cart addition form or an AJAX-enabled form
    var isAjaxForm = (form.getAttribute('data-ajax-submit') === 'true');
    var isCartAddForm = form.id === 'detail-form' ||
        form.classList.contains('add-to-cart-form') ||
        (form.getAttribute('action') && form.getAttribute('action').includes('/cart.php') && form.querySelector('input[name="action"][value="add"]'));

    // If not an add-to-cart form and not a general AJAX form, let it be
    if (!isCartAddForm && !isAjaxForm) return;

    e.preventDefault();
    console.log('Form submission intercepted via Consolidated Global Handler. Type:', isCartAddForm ? 'Cart' : 'AJAX');

    var formData = new FormData(form);
    if (isCartAddForm && !form.querySelector('input[name="action"]')) {
        formData.append('action', 'add');
    }
    formData.append('is_ajax', '1');

    var btn = form.querySelector('.btn-add-to-cart, .pcf-btn-cart, button[type="submit"]');
    var originalHtml = btn ? btn.innerHTML : CART_ICON_HTML;

    if (btn) {
        btn.innerHTML = '...';
        btn.disabled = true;
    }

    var xhr = new XMLHttpRequest();
    // For cart additions, prefer cart_ajax.php for cleaner JSON
    var targetUrl = isCartAddForm ? '/cart_ajax.php' : form.getAttribute('action');
    xhr.open('POST', targetUrl, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            // Restore button
            if (btn) {
                btn.innerHTML = originalHtml;
                btn.disabled = false;
            }

            if (xhr.status === 200) {
                try {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        if (isCartAddForm) {
                            // Update UI
                            updateCartContents();
                            openSlideCart();
                            updateCartBadge(response.item_count || response.total_items);

                            // Show Success Notification
                            showNotification(response.message || 'Položka byla přidána do košíku.', 'success');

                            // GA4 Tracking
                            if (typeof gtag === 'function' && response.sku) {
                                const unitPrice = parseFloat(response.price) || 0;
                                const qty = parseInt(response.quantity) || 1;
                                const eventData = {
                                    currency: 'CZK',
                                    value: unitPrice * qty,
                                    items: [{
                                        item_id: response.sku,
                                        item_name: response.name,
                                        price: unitPrice,
                                        quantity: qty
                                    }]
                                };
                                gtag('event', 'add_to_cart', eventData);
                                if (typeof fbq === 'function') {
                                    fbq('track', 'AddToCart', {
                                        content_ids: [response.sku],
                                        content_type: 'product',
                                        value: unitPrice * qty,
                                        currency: 'CZK'
                                    });
                                }
                                if (window.shopSettings && window.shopSettings.sem_id) {
                                    const novatUnitPrice = parseFloat((unitPrice / 1.21).toFixed(2));
                                    if (typeof window.SEM === 'function') {
                                        window.SEM('track', 'AddToCart', {
                                            currency: 'CZK',
                                            value: parseFloat((novatUnitPrice * qty).toFixed(2)),
                                            content_type: 'product',
                                            contents: [{ id: response.sku, content_name: response.name, unit_price: unitPrice, quantity: qty }]
                                        });
                                    }
                                }
                                console.log('Analytics add_to_cart sent:', eventData);
                            }
                        } else {
                            // General AJAX form success
                            showNotification(response.message || 'Akce proběhla úspěšně!', 'success');
                            if (response.redirect) window.location.href = response.redirect;
                        }

                        // Close Lightbox if open
                        if (typeof closeLightbox === 'function') closeLightbox();

                    } else {
                        showNotification(response.message || 'Chyba při zpracování požadavku.', 'error');
                    }
                } catch (err) {
                    console.error('AJAX Response JSON Parse Error:', err);
                    if (isCartAddForm) {
                        window.location.href = '/pokladna'; // Fallback
                    } else {
                        showNotification('Chyba při zpracování odpovědi ze serveru.', 'error');
                    }
                }
            } else {
                showNotification('Server vrátil chybu: ' + xhr.status, 'error');
            }
        }
    };
    xhr.send(formData);
});

// Re-attach change listener for main form if present on load (for variant steps)
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('detail-form');
    if (form && typeof updateVariantState === 'function') {
        form.addEventListener('change', updateVariantState);
    }
});

// --- FIX: TAB LOGIC (GLOBAL SCOPE) ---
document.body.addEventListener('click', function (e) {
    if (e.target && e.target.classList.contains('tab-link')) {
        e.preventDefault();
        var link = e.target;
        var tabId = link.getAttribute('data-tab');
        var container = link.closest('.detail-description-tabs');

        if (container && tabId) {
            var allLinks = container.querySelectorAll('.tab-link');
            var allContents = container.querySelectorAll('.tab-content');

            allLinks.forEach(function (el) { el.classList.remove('active'); });
            allContents.forEach(function (el) { el.classList.remove('active'); });

            link.classList.add('active');
            var targetContent = container.querySelector('#' + tabId);
            if (targetContent) targetContent.classList.add('active');
        }
    }
});

/* ======== PREMIUM CATEGORY FILTERS & SORTING LOGIC ======== */
document.addEventListener('DOMContentLoaded', function () {
    var triggerFilter = document.getElementById('trigger-filter');
    var triggerSort = document.getElementById('trigger-sort');
    var panelFilter = document.getElementById('panel-filter');
    var panelSort = document.getElementById('panel-sort');

    function closeAllPanels() {
        if (panelFilter) panelFilter.classList.remove('expanding');
        if (panelSort) panelSort.classList.remove('expanding');
        if (triggerFilter) triggerFilter.classList.remove('is-open');
        if (triggerSort) triggerSort.classList.remove('is-open');
    }

    function togglePanel(panel, trigger) {
        if (!panel) return;
        var isOpen = panel.classList.contains('expanding');

        if (isOpen) {
            panel.classList.remove('expanding');
            if (trigger) trigger.classList.remove('is-open');
        } else {
            closeAllPanels();
            panel.classList.add('expanding');
            if (trigger) trigger.classList.add('is-open');
        }
    }

    if (triggerFilter) {
        triggerFilter.addEventListener('click', function (e) {
            e.preventDefault();
            togglePanel(panelFilter, triggerFilter);
        });
    }

    if (triggerSort) {
        triggerSort.addEventListener('click', function (e) {
            e.preventDefault();
            togglePanel(panelSort, triggerSort);
        });
    }

    // Close buttons inside panels
    document.querySelectorAll('.panel-close-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            closeAllPanels();
        });
    });

    // --- PREMIUM PRICE SLIDER ---
    var inMin = document.getElementById('in-min');
    var inMax = document.getElementById('in-max');
    var valMin = document.getElementById('val-min');
    var valMax = document.getElementById('val-max');
    var fillTrack = document.getElementById('fill-track');

    if (inMin && inMax && fillTrack) {
        function updateSliderUI() {
            let min = parseInt(inMin.value);
            let max = parseInt(inMax.value);
            var absMin = parseInt(inMin.min);
            var absMax = parseInt(inMin.max);

            // Constraints
            if (min > max - 1) {
                if (this === inMin) inMin.value = max - 1;
                else inMax.value = min + 1;
                min = parseInt(inMin.value);
                max = parseInt(inMax.value);
            }

            // Labels
            if (valMin) valMin.textContent = new Intl.NumberFormat('cs-CZ').format(min);
            if (valMax) valMax.textContent = new Intl.NumberFormat('cs-CZ').format(max);

            // fill track
            var p1 = ((min - absMin) / (absMax - absMin)) * 100;
            var p2 = ((max - absMin) / (absMax - absMin)) * 100;
            fillTrack.style.left = p1 + '%';
            fillTrack.style.width = (p2 - p1) + '%';
        }

        inMin.addEventListener('input', updateSliderUI);
        inMax.addEventListener('input', updateSliderUI);
        updateSliderUI();
    }
});

/* --- PRODUCT CARD FUNCTIONS (Global) --- */
function cardGalleryHover(el, event) {
    var imagesVal = el.getAttribute('data-images');
    if (!imagesVal) return;
    let images = [];
    try { images = JSON.parse(imagesVal); } catch (e) { }
    if (images.length <= 1) return;

    var rect = el.getBoundingClientRect();
    var x = event.clientX - rect.left;
    var width = rect.width;
    var segmentWidth = width / images.length;
    let index = Math.floor(x / segmentWidth);
    if (index < 0) index = 0;
    if (index >= images.length) index = images.length - 1;

    var imgEl = el.querySelector('img.product-card-img');
    if (imgEl && images[index]) {
        if (imgEl.src !== images[index]) imgEl.src = images[index];
    }
    var dots = el.querySelectorAll('.card-gallery-dots span');
    dots.forEach(function (dot, i) {
        if (i === index) dot.classList.add('active');
        else dot.classList.remove('active');
    });
}

function cardGalleryLeave(el) {
    var imgEl = el.querySelector('img.product-card-img');
    var mainSrc = imgEl ? imgEl.getAttribute('data-main-src') : null;
    if (imgEl && mainSrc) imgEl.src = mainSrc;
    var dots = el.querySelectorAll('.card-gallery-dots span');
    dots.forEach(function (dot, i) {
        if (i === 0) dot.classList.add('active');
        else dot.classList.remove('active');
    });
}

function openLightboxFromList(linkEl) {
    // If we have a dedicated openLightbox function, use it.
    // Try to find URL from data cache or just main image?
    // User wants to open the IMAGE in lightbox.
    // We can pass the main image URL to openImageZoom OR openLightbox (which loads AJAX detail).
    // If settings say "Open Lightbox", it usually means Quick View (AJAX Detail).
    // Let's assume Quick View for now as that's what openLightbox does (fetches ?ajax=1).
    if (linkEl) {
        var card = linkEl.closest('.product-card');
        if (card) {
            var id = card.getAttribute('data-id');
            var url = '/produkt/quickview_' + id + '?ajax=1'; // Approximate URL
            // Better: Use the hidden link logic or read from a data attribute.
            // Let's check if product-card wraps it in a data attribute.
            // It doesn't currently. 
            // BUT wait, line 300 in script.js expects `data-ajax-url`.
            // I should update product-card.php to output `data-ajax-url` even if href is #.
        }
    }
    // Fallback: If we can't find URL easily, just return.
    // Actually, I'll update `product-card.php` to include `data-ajax-url` always.
    // And for now, I'll stub this function to prevent errors.
}

// --- GLOBÁLNÍ FUNKCE PRO SLOUČENÍ KOŠÍKU DO OBJEDNÁVKY ---
function mergeToOrder(oid) {
    if (!confirm("Vložit tyto položky do objednávky #" + oid + " a vrátit se do administrace?")) return;
    fetch("/editor/api_orders.php?action=merge_to_order", {
        method: "POST",
        body: JSON.stringify({ order_id: oid }),
        headers: { "Content-Type": "application/json" }
    })
        .then(function (res) { return res.json(); })
        .then(function (json) {
            if (json.status === "ok") {
                window.location.href = "/editor/order_detail.php?id=" + oid;
            } else {
                showNotification(json.message || "Chyba při slučování.", 'error');
            }
        })
        .catch(function (err) { console.error("Error merging order:", err); });
}




/* --- VARIANT SELECTION LOGIC (Moved from detail.php) --- */

/**
 * 1. Button Selection Handler
 */
function selectAttributeButton(btn) {
    if (btn.classList.contains('disabled')) return;
    var container = btn.closest('.variant-group'); // Corrected from .attribute-group
    if (!container) return;

    // Find parent product detail container for scoping
    var detailContainer = btn.closest('.product-detail-container') || document;

    // Deselect siblings
    var siblings = container.querySelectorAll('.attr-btn');
    siblings.forEach(function (b) { b.classList.remove('selected'); });

    // Select clicked
    btn.classList.add('selected');

    // Call resolution
    // We need to find the specific select relevant to this button group?
    // Or just resolve based on all selected buttons?
    // Resolve relies on finding selects or buttons.
    resolveVariantFromAttributes(detailContainer);
}

/**
 * 2. Main Logic to find matching variant
 */
function resolveVariantFromAttributes(context) {
    if (!context) return;
    console.log("resolveVariantFromAttributes START", context);
    // If context is an element (like a select), get container
    if (context.nodeType === 1 && !context.classList.contains('product-detail-container') && !context.classList.contains('product-card')) {
        var c = context.closest('.product-detail-container') || context.closest('.product-card');
        if (c) context = c;
        else if (context === document) context = document;
    }
    if (!context) return;

    // A. Gather selected attributes
    var selectedAttrs = {};

    // 1. Buttons (find all selected buttons in this context)
    var selectedBtns = context.querySelectorAll('.attr-btn.selected');
    selectedBtns.forEach(function (btn) {
        var group = btn.closest('.attribute-buttons');
        var attrId = group ? group.getAttribute('data-attr-id') : btn.getAttribute('data-attr-id');
        // Note: data-attr-id should be on the container or button.
        // In detail.php template: <div class="attribute-buttons" data-attr-id="...">
        // Button onclick passes it? No, button has no data-attr-id in previous template step?
        // Let's check template.
        // Template: <div class="attribute-buttons" data-attr-id="...">
        //           <div class="attr-btn" onclick="selectAttributeButton(this)">
        // So we get attrId from parent .attribute-buttons
        if (!attrId && btn.getAttribute('data-attr-id')) attrId = btn.getAttribute('data-attr-id');

        var val = btn.getAttribute('data-value');
        if (attrId && val) selectedAttrs[attrId] = val.trim().toLowerCase();
    });

    // 2. Selects (all visible selects in this context)
    var selects = context.querySelectorAll('select.attribute-select');
    selects.forEach(function (sel) {
        // Only include if visible (fallback logic) OR if it is the primary selector
        // But we want to support mixed button/select.
        var attrId = sel.getAttribute('data-attr-id');
        var val = sel.value;
        // If there are buttons for this attribute, we ignore the select (it should be hidden/synced)
        // Check if there are buttons for this attrId?
        var hasButtons = context.querySelector('.attribute-buttons[data-attr-id="' + attrId + '"]');
        if (!hasButtons && attrId && val) {
            selectedAttrs[attrId] = val.trim().toLowerCase();
        }
    });

    console.log("Selected Attributes:", selectedAttrs);

    // C. Find matching variant
    // We need access to the variants data.
    var productData = [];
    var rawData = context.getAttribute('data-variants-json') || (context.dataset ? context.dataset.variantsJson : null);

    // Fallback for product cards where data-variants-json is on an inner div
    if (!rawData) {
        var inner = context.querySelector('[data-variants-json]');
        if (inner) {
            rawData = inner.getAttribute('data-variants-json') || (inner.dataset ? inner.dataset.variantsJson : null);
        }
    }

    if (rawData) {
        try {
            productData = JSON.parse(rawData);
        } catch (e) { console.error("Error parsing variant JSON", e); }
    }

    console.log("Product Data Count:", productData.length);


    if (!productData || productData.length === 0) return;

    // Filter
    var matchingVariant = productData.find(function (v) {
        // Check if v matches ALL selectedAttrs
        var matchCount = 0;
        var requiredKeys = Object.keys(selectedAttrs);
        var requiredCount = requiredKeys.length;

        // If no attributes selected, but product has variants, we can't match specifically
        if (requiredCount === 0) return false;

        for (var reqId in selectedAttrs) {
            var reqVal = selectedAttrs[reqId];

            for (var i = 1; i <= 5; i++) {
                var colId = (i === 1) ? 'attribute_id' : 'attribute_id' + i;
                var colVal = (i === 1) ? 'attribute_value' : 'attribute_value' + i;

                var v_val = (v[colVal] || "").trim().toLowerCase();
                if (v[colId] == reqId && v_val == reqVal) {
                    matchCount++;
                    break;
                }
            }
        }

        return matchCount === requiredCount;
    });

    updateDetailPrice(matchingVariant, context);
    updateAttributeAvailability(context, selectedAttrs, productData);
}

/**
 * 3. Update UI Selector (used for URL sync)
 */
function updateUISelector(selector, value, context) {
    if (!selector) return;
    var val = (value || "").toString().trim().toLowerCase();

    // A. Handle Select
    if (selector.tagName === 'SELECT') {
        // Find option that matches (case insensitive)
        for (var i = 0; i < selector.options.length; i++) {
            if (selector.options[i].value.trim().toLowerCase() === val) {
                selector.selectedIndex = i;
                break;
            }
        }
    }

    // B. Handle Buttons (if they exist for this attribute)
    var attrId = selector.getAttribute('data-attr-id');
    if (attrId) {
        var btnGroup = context.querySelector('.attribute-buttons[data-attr-id="' + attrId + '"]');
        if (btnGroup) {
            var btns = btnGroup.querySelectorAll('.attr-btn');
            btns.forEach(function (btn) {
                var btnVal = (btn.getAttribute('data-value') || "").trim().toLowerCase();
                if (btnVal === val) {
                    btn.classList.add('selected');
                } else {
                    btn.classList.remove('selected');
                }
            });
        }
    }
}

/**
 * Update availability status for all attribute values based on PREVIOUS groups (unidirectional)
 */
function updateAttributeAvailability(context, selectedAttrs, productData) {
    if (!productData || productData.length === 0) return;

    // Find all attribute groups (buttons and selects) in DOM order
    var groups = context.querySelectorAll('.variant-group');

    // Track selections in groups processed so far (for top-down logic)
    var previousSelections = {};

    groups.forEach(function (group, index) {
        var groupSelector = group.querySelector('.attribute-buttons') || group.querySelector('select.attribute-select');
        if (!groupSelector) return;

        var attrId = groupSelector.getAttribute('data-attr-id');
        if (!attrId) return;

        // Collect all values in this group
        var valuesToUpdate = [];
        var buttons = group.querySelectorAll('.attr-btn');
        var options = group.querySelectorAll('option');

        buttons.forEach(function (btn) {
            valuesToUpdate.push({
                element: btn,
                value: (btn.getAttribute('data-value') || "").trim().toLowerCase(),
                type: 'button'
            });
        });

        options.forEach(function (opt) {
            if (!opt.value) return;
            valuesToUpdate.push({
                element: opt,
                value: opt.value.trim().toLowerCase(),
                type: 'option'
            });
        });

        // For each value in THIS group, check if it's compatible with PREVIOUS groups' selections
        valuesToUpdate.forEach(function (item) {
            var valToCheck = item.value;

            // Build temporary selection: Previous groups + THIS value
            var testSelection = Object.assign({}, previousSelections);
            testSelection[attrId] = valToCheck;

            // Check if ANY variant matches testSelection (only previous groups + this value)
            var possible = productData.some(function (v) {
                var requiredKeys = Object.keys(testSelection);
                var matchCount = 0;

                requiredKeys.forEach(function (reqId) {
                    var reqVal = testSelection[reqId];
                    for (var i = 1; i <= 5; i++) {
                        var colId = (i === 1) ? 'attribute_id' : 'attribute_id' + i;
                        var colVal = (i === 1) ? 'attribute_value' : 'attribute_value' + i;
                        var v_val = (v[colVal] || "").trim().toLowerCase();

                        if (v[colId] == reqId && v_val == reqVal) {
                            matchCount++;
                            break;
                        }
                    }
                });
                return matchCount === requiredKeys.length;
            });

            // Update UI
            if (item.type === 'button') {
                if (possible) {
                    item.element.classList.remove('disabled');
                } else {
                    item.element.classList.add('disabled');
                }
            } else if (item.type === 'option') {
                item.element.disabled = !possible;
            }
        });

        // Add THIS group's ACTUAL selection to previousSelections for the NEXT group in loop
        if (selectedAttrs[attrId]) {
            previousSelections[attrId] = selectedAttrs[attrId];
        }
    });
}

/**
 * 3. Update UI
 */
function updateDetailPrice(variant, context) {
    if (!context) context = document;

    // custom gift toggler: check if price is above 15000 to show/hide gift box on the left
    var giftContainer = context.querySelector('.detail-gift-container');
    if (giftContainer) {
        var priceValue = 0;
        if (variant) {
            priceValue = parseFloat(variant.active_price);
        } else {
            // Get base price from dataset or text
            var basePriceStr = context.dataset.basePriceVat || '0';
            priceValue = parseFloat(basePriceStr.replace(/[^0-9\.]/g, '')) || 0;
        }
        if (priceValue > 15000) {
            giftContainer.style.display = 'block';
        } else {
            giftContainer.style.display = 'none';
        }
    }

    var priceVatEl = context.querySelector('.price-vat'); // generic class
    var priceNoVatEl = context.querySelector('.price-novat');
    var stockEl = context.querySelector('#detail-availability') || context.querySelector('.availability-status');
    var dimEl = context.querySelector('#detail-dimensions');
    var dimWrapper = context.querySelector('#detail-dimensions-wrapper');
    var weightEl = context.querySelector('#detail-weight');
    var weightWrapper = context.querySelector('#detail-weight-wrapper');

    var paramDimEl = context.querySelector('#param-val-dimensions');
    var paramDimWrapper = context.querySelector('#params-dimensions');
    var paramWeightEl = context.querySelector('#param-val-weight');
    var paramWeightWrapper = context.querySelector('#params-weight');
    // Use class-based availability if possible. In template it is id="detail-availability"
    // For consistency, if context is specific, querySelector('#id') works inside it? No, IDs are global.
    // But duplicate IDs are invalid.
    // If lightbox copies HTML, we duplicate IDs.
    // We should treat context as root. context.querySelector('#id') finds the first one in subtree?
    // Yes.

    var btn = context.querySelector('.btn-add-to-cart');
    var variantInput = context.querySelector('[name="variant_id"]'); // Generic selector for input/select

    // Currency symbol
    var symbol = 'Kč'; // hardcoded or fetched?
    // We can try to get it from current text?

    var priceVatValueEl = context.querySelector('.price-value-vat');
    var priceNoVatValueEl = context.querySelector('.price-value-novat');
    var prefixOdEl = context.querySelector('.pcf-prefix-od');

    if (variant) {
        // Toggle Buy Box vs Inquiry Notice
        var buyBox = context.querySelector('.buy-box-container');
        var notice = context.querySelector('.not-orderable-notice');
        if (variant.not_orderable) {
            if (buyBox) buyBox.style.display = 'none';
            if (notice) notice.style.display = 'block';
        } else {
            if (buyBox) buyBox.style.display = 'block';
            if (notice) notice.style.display = 'none';
        }

        // Update price values
        if (priceVatValueEl) priceVatValueEl.innerText = formatPrice(variant.active_price);
        if (priceNoVatValueEl) {
            var p = parseFloat(variant.active_price);
            priceNoVatValueEl.innerText = formatPrice(p / 1.21);
        }
        // Hide "od" prefix
        if (prefixOdEl) prefixOdEl.style.display = 'none';

        // Update Stock/Availability
        if (stockEl) {
            var availText = '';
            var availNote = '';
            var availColor = '#333';

            // 1. Determine Text
            if (variant.stock > 0) {
                availText = 'Skladem (' + variant.stock + ' ks)';
                availColor = '#27ae60'; // Green
            } else {
                // Determine Out of Stock Status
                var mainData = context.querySelector('.detail-info-container')?.dataset;
                var oosId = mainData?.availabilityOutOfStock;

                var statusObj = null;
                if (oosId && oosId !== "0" && window.availabilityMap && window.availabilityMap[oosId]) {
                    statusObj = window.availabilityMap[oosId];
                } else {
                    // Fallback to variant's own availability_id if present
                    var aid = variant.availability_id;
                    if (window.availabilityMap && window.availabilityMap[aid]) {
                        statusObj = window.availabilityMap[aid];
                    }
                }

                if (statusObj) {
                    if (typeof statusObj === 'object') {
                        availText = statusObj.name || '';
                        availNote = statusObj.note || '';
                    } else {
                        availText = statusObj;
                    }
                } else if (variant.status) {
                    availText = variant.status;
                } else {
                    availText = 'Není skladem';
                }

                // 2. Determine Color based on Text
                var lower = availText.toLowerCase();
                if (lower.includes('skladem') && !lower.includes('není') && !lower.includes('nejsou') && !lower.includes('nedostupné')) {
                    availColor = '#27ae60'; // Green
                } else if (lower.includes('není') || lower.includes('vyprodáno') || lower.includes('nedostupné') || lower.includes('momentálně')) {
                    availColor = '#e74c3c'; // Red
                } else {
                    availColor = '#f39c12'; // Orange (Na dotaz, Do 3 dnů...)
                }
            }

            stockEl.innerText = availText;
            stockEl.style.color = availColor;

            if (availNote) {
                stockEl.setAttribute('data-tooltip', availNote);
                stockEl.removeAttribute('title');
                var icon = document.createElement('span');
                icon.className = 'availability-tooltip-icon';
                icon.textContent = '?';
                stockEl.appendChild(icon);
            } else {
                stockEl.removeAttribute('data-tooltip');
                stockEl.removeAttribute('title');
            }
        }

        // Update Dimensions & Weight
        var dims = (variant.dim_x || variant.dim_y || variant.dim_z) ? (variant.dim_x + ' x ' + variant.dim_y + ' x ' + variant.dim_z) : '';
        if (dimEl) dimEl.innerText = dims;
        if (dimWrapper) dimWrapper.style.display = dims ? 'inline' : 'none';
        if (paramDimEl) paramDimEl.innerText = dims;
        if (paramDimWrapper) paramDimWrapper.style.display = dims ? 'block' : 'none';

        if (weightEl) weightEl.innerText = variant.weight || '';
        if (weightWrapper) weightWrapper.style.display = variant.weight ? 'inline' : 'none';
        if (paramWeightEl) paramWeightEl.innerText = variant.weight || '';
        if (paramWeightWrapper) paramWeightWrapper.style.display = variant.weight ? 'block' : 'none';

        // Set Hidden Input
        if (variantInput) variantInput.value = variant.id;

        // Enable Button
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = (typeof CART_ICON_HTML !== 'undefined') ? CART_ICON_HTML : 'Do košíku';
        }

        // Update Image
        var mainImgEl = context.querySelector('#detail-main-image');
        var zoomEl = context.querySelector('#zoom-image-trigger');

        // Update Quantity Step if available in variant
        var qtyInput = context.querySelector('input[name="quantity"]') || context.querySelector('#qty-input');
        if (qtyInput && variant.packaging) {
            var vPackage = parseFloat(variant.packaging.toString().replace(/[^0-9\.]/g, '').replace(',', '.')) || 1;
            qtyInput.setAttribute('step', vPackage);
            qtyInput.setAttribute('min', vPackage);
            if (parseFloat(qtyInput.value) < vPackage) {
                qtyInput.value = vPackage;
            }
        }

        // Fix: logic to handle variant images correctly
        var packshot = '';
        if (variant.main_photo) packshot = variant.main_photo;
        else if (variant.image_url) packshot = variant.image_url;
        else if (variant.packshot) packshot = variant.packshot;

        if (mainImgEl && packshot) {
            var finalUrl = '';
            // Handle both raw paths (with leading slash) and trimmed paths
            if (packshot.indexOf('http') === 0) {
                finalUrl = packshot;
            } else if (packshot.indexOf('uploads/') === 0 || packshot.indexOf('/uploads/') === 0 ||
                packshot.indexOf('assets/') === 0 || packshot.indexOf('/assets/') === 0) {
                // Ensure leading slash
                finalUrl = (packshot.indexOf('/') === 0) ? packshot : '/' + packshot;
            } else {
                // Assume ancient legacy path ?
                // Or maybe we should strip leading slash for legacy CDN?
                var trimmed = packshot.replace(/^\//, "");
                finalUrl = 'https://akcniletaky.com/totalprotect/ftp_nove_obrazky/' + trimmed;
            }

            if (mainImgEl.src !== finalUrl) mainImgEl.src = finalUrl;
            if (zoomEl) zoomEl.href = finalUrl;

            // Fix: Sync Lightbox Index
            var lightboxGallery = context.querySelector('#product-lightbox-gallery');
            if (lightboxGallery && window.location.pathname.indexOf('/editor/') === -1) {
                var items = lightboxGallery.querySelectorAll('.gallery-item.lightbox');
                console.log("Syncing Lightbox. Items count:", items.length, "Target:", finalUrl);

                items.forEach(function (item, idx) {
                    var itemHref = item.getAttribute('href');
                    var normItems = itemHref.replace(/^https?:\/\/[^\/]+/, '');
                    var normFinal = finalUrl.replace(/^https?:\/\/[^\/]+/, '');

                    if (normItems === normFinal || normItems.indexOf(normFinal) !== -1 || normFinal.indexOf(normItems) !== -1) {
                        console.log("Lightbox Sync: Match at index", idx, itemHref);
                        if (typeof window.currentGalleryIndex !== 'undefined') {
                            window.currentGalleryIndex = idx;
                        }

                        // NEW: Highlight corresponding thumbnail
                        var thumbs = context.querySelectorAll('.thumb-item');
                        if (thumbs && thumbs.length > 0) {
                            thumbs.forEach(function (t) { t.classList.remove('active'); });
                            if (thumbs[idx]) thumbs[idx].classList.add('active');
                        }
                    }
                });
            }
        }

        // Update H1 / Title if main product
        // (Optional, simplified)

    } else {
        // Reset Visibility based on Base Product
        var buyBox = context.querySelector('.buy-box-container');
        var notice = context.querySelector('.not-orderable-notice');
        var isBaseNotOrderable = (context.dataset.baseNotOrderable === '1');

        if (isBaseNotOrderable) {
            if (buyBox) buyBox.style.display = 'none';
            if (notice) notice.style.display = 'block';
        } else {
            if (buyBox) buyBox.style.display = 'block';
            if (notice) notice.style.display = 'none';
        }

        // RESET to Base Product Values
        if (priceVatValueEl && context.dataset.basePriceVat) {
            priceVatValueEl.innerText = context.dataset.basePriceVat;
        }
        if (priceNoVatValueEl && context.dataset.basePriceNovat) {
            priceNoVatValueEl.innerText = context.dataset.basePriceNovat;
        }
        // Show "od" prefix if it was there initially
        if (prefixOdEl && context.dataset.showFrom === '1') {
            prefixOdEl.style.display = 'inline';
        }

        // Reset Variant Input
        if (variantInput) variantInput.value = '';

        // Reset Availability
        if (stockEl) {
            if (stockEl.dataset.baseAvailability) {
                stockEl.innerText = stockEl.dataset.baseAvailability;
                stockEl.style.color = stockEl.dataset.baseAvailabilityColor || '#333';
            }
        }

        // Handle Button (Disabled only if invalid choice, not if partial choice)
        if (btn) {
            // If it's the main detail page, we might want to show "Nedostupné"
            // For card, we just keep it or show a hint.
            if (context.classList.contains('product-detail-container')) {
                btn.disabled = true;
                btn.innerHTML = 'Nedostupné';
            } else {
                btn.disabled = false;
                // Keep original icon?
            }
        }

        // Revert to Main Image
        var mainData = null;
        if (context.dataset && context.dataset.mainJson) {
            try { mainData = JSON.parse(context.dataset.mainJson); } catch (e) { }
        }
        var mainImgEl = context.querySelector('#detail-main-image');
        var zoomEl = context.querySelector('#zoom-image-trigger');
        if (mainImgEl && mainData && mainData.image_url) {
            var packshot = mainData.image_url;
            var finalUrl = '';
            if (packshot.indexOf('http') === 0) {
                finalUrl = packshot;
            } else if (packshot.indexOf('uploads/') === 0 || packshot.indexOf('/uploads/') === 0 ||
                packshot.indexOf('assets/') === 0 || packshot.indexOf('/assets/') === 0) {
                finalUrl = (packshot.indexOf('/') === 0) ? packshot : '/' + packshot;
            } else {
                var trimmed = packshot.replace(/^\//, "");
                finalUrl = 'https://akcniletaky.com/totalprotect/ftp_nove_obrazky/' + trimmed;
            }

            if (mainImgEl.src !== finalUrl) mainImgEl.src = finalUrl;
            if (zoomEl) zoomEl.href = finalUrl;

            // Revert Lightbox Index to 0 (Main Image)
            if (typeof window.currentGalleryIndex !== 'undefined') {
                window.currentGalleryIndex = 0;
            }
        }
    }
}

// Helper
function formatPrice(val) {
    return new Intl.NumberFormat('cs-CZ', { style: 'currency', currency: 'CZK' }).format(val);
}

// Explicitly export globals to window to prevent ReferenceErrors if inside closure or module
window.cardGalleryHover = cardGalleryHover;
window.cardGalleryLeave = cardGalleryLeave;
window.openLightboxFromList = openLightboxFromList;
window.selectAttributeButton = selectAttributeButton;
window.resolveVariantFromAttributes = resolveVariantFromAttributes;
window.updateDetailPrice = updateDetailPrice;

/* ======== TOAST NOTIFICATION SYSTEM ======== */
function showNotification(message, type = 'success') {
    // 1. Prefer existing professional Toast system if available
    if (window.Toast && typeof window.Toast.show === 'function') {
        window.Toast.show(message, type);
        return;
    }
    if (typeof window.showToast === 'function') {
        window.showToast(message, type);
        return;
    }

    // 2. Fallback / Custom implementation (matching admin-toast.css classes)
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    // Icon selection (Simplified or matching Toast.icons)
    let icon = '';
    if (type === 'success') icon = '✓';
    else if (type === 'error') icon = '✕';
    else icon = 'ℹ';

    toast.innerHTML = `
        <div class="toast-icon">${icon}</div>
        <div class="toast-message">${message}</div>
        <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;

    container.appendChild(toast);

    // Trigger visibility
    requestAnimationFrame(() => {
        toast.classList.add('visible');
    });

    // Auto-remove
    setTimeout(() => {
        toast.classList.remove('visible');
        setTimeout(() => toast.remove(), 400);
    }, 5000);
}
window.showNotification = showNotification;

/**
 * NEW: Variant selection logic for V2 schema
 */
function initVariantSelection(container) {
    if (!container) return;

    // Use a more generic selector to find all variant-related controls
    var selectors = [].slice.call(container.querySelectorAll('.attribute-select, .variant-group'));
    if (selectors.length > 0) {
        var urlParams = new URL(window.location.href).searchParams;
        var urlVariantId = urlParams ? urlParams.get('variant') : null;

        // Only sync from URL if we are on the MAIN product page (not a secondary modal)
        // Check if container is NOT in a lightbox
        var isLightbox = container.closest('#lightbox-overlay');

        if (urlVariantId && !isLightbox && (container.dataset.variantsJson || container.getAttribute('data-variants-json'))) {
            try {
                var rawData = container.dataset.variantsJson || container.getAttribute('data-variants-json');
                var variants = JSON.parse(rawData);
                var variantData = variants.find(function (v) { return v.id == urlVariantId; });
                if (variantData) {
                    selectors.forEach(function (s) {
                        // The attr-id might be on the select itself or on a child button group
                        var subEl = s.querySelector('[data-attr-id]');
                        var aid = s.dataset.attrId || (subEl ? subEl.dataset.attrId : null);
                        if (!aid) return;

                        for (var i = 1; i <= 5; i++) {
                            var colId = (i === 1) ? 'attribute_id' : 'attribute_id' + i;
                            var colVal = (i === 1) ? 'attribute_value' : 'attribute_value' + i;
                            if (variantData[colId] == aid) {
                                updateUISelector(s, variantData[colVal], container);
                                break;
                            }
                        }
                    });
                }
            } catch (e) { console.error("Error parsing variants for URL sync:", e); }
        }
    }

    // Flag all as initial for the internal fallback logic
    selectors.forEach(function (s) { s.isInitial = true; });
    // Trigger resolution from the first found control
    if (selectors.length > 0) {
        resolveVariantFromAttributes(selectors[0]);
    }
}

// Explicitly export globals to window if needed
function openProductLightbox() {
    var hiddenItems = document.querySelectorAll('#product-lightbox-gallery .gallery-item.lightbox');
    if (hiddenItems && hiddenItems.length > 0) {
        if (typeof currentGalleryIndex === 'undefined') window.currentGalleryIndex = 0;
        var target = hiddenItems[window.currentGalleryIndex];
        if (target) target.click();
    }
}
// Auto-initialize cards with variants
function initCardsWithVariants(container) {
    if (!container) container = document;
    container.querySelectorAll('.product-card').forEach(function (card) {
        var variantSelectors = card.querySelectorAll('.attribute-select');
        if (variantSelectors.length > 0) {
            // resolve initial state (usually empty select)
            resolveVariantFromAttributes(card);
        }
    });
}
window.initCardsWithVariants = initCardsWithVariants;

document.addEventListener('DOMContentLoaded', function () {
    initCardsWithVariants();
});

/**
 * Inquiry Modal Functions
 */
function openInquiryModal() {
    var modal = document.getElementById('inquiryModal');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';

        // Set antispam token when opening
        var tokenInput = document.getElementById('antispam_token');
        if (tokenInput) tokenInput.value = 'verified_human';
    }
}

function closeInquiryModal() {
    var modal = document.getElementById('inquiryModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = '';
    }
}

function submitInquiry(event) {
    event.preventDefault();
    var form = event.target;
    var submitBtn = document.getElementById('inquirySubmitBtn');
    var resultDiv = document.getElementById('inquiryResult');
    var resultMsg = document.getElementById('inquiryResultMessage');

    if (submitBtn) {
        submitBtn.disabled = true;
        var originalText = submitBtn.innerText;
        submitBtn.innerText = 'Odesílám...';
    }

    var formData = new FormData(form);
    fetch('/api_inquiry.php', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
        .then(function (response) { return response.json(); })
        .then(function (data) {
            if (data.status === 'ok') {
                form.style.display = 'none';
                resultDiv.style.display = 'block';
                if (resultMsg) resultMsg.innerHTML = data.message || 'Děkujeme za poptávku!';
                if (typeof window.trackSklikInquiry === 'function') {
                    window.trackSklikInquiry();
                }
                if (typeof window.trackGadsInquiry === 'function') {
                    window.trackGadsInquiry();
                }
                if (window.shopSettings && window.shopSettings.sem_id) {
                    if (typeof window.SEM === "function") window.SEM('track', 'Lead', { currency: 'CZK', value: 0 });
                }
            } else {
                showNotification(data.message || 'Chyba při odesílání poptávky.', 'error');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = 'Odeslat poptávku';
                }
            }
        })
        .catch(function (err) {
            console.error('Inquiry Error:', err);
            showNotification('Chyba při komunikaci se serverem.', 'error');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerText = 'Odeslat poptávku';
            }
        });
}

/**
 * Essox Modal Functions
 */
function openEssoxModal(price) {
    window.open('/editor/esoxstart.php?price=' + price, 'EssoxKalkulacka', 'width=900,height=750,scrollbars=yes,resizable=yes');
}

function closeEssoxModal() {
    var overlay = document.getElementById('essox-overlay');
    if (overlay) {
        overlay.style.display = 'none';
        document.body.style.overflow = '';
    }
}

window.openInquiryModal = openInquiryModal;
window.closeInquiryModal = closeInquiryModal;
window.submitInquiry = submitInquiry;
window.openEssoxModal = openEssoxModal;
window.closeEssoxModal = closeEssoxModal;
window.openProductLightbox = openProductLightbox;

// Track tel: and mailto: clicks for SEM
document.addEventListener('click', function(e) {
    var target = e.target.closest('a');
    if (target && target.href) {
        if (target.href.startsWith('tel:') || target.href.startsWith('mailto:')) {
            if (window.shopSettings && window.shopSettings.sem_id) {
                if (typeof window.SEM === "function") window.SEM('track', 'Lead', { currency: 'CZK', value: 0 });
                console.log('SEM Lead track sent for:', target.href);
            }
        }
    }
});
