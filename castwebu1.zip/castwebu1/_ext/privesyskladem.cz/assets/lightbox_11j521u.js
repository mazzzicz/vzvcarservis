/**
 * Lightbox Logic
 * Handles image galleries with navigation and grouping.
 */
document.addEventListener('DOMContentLoaded', function () {
    var zoomOverlay = document.getElementById('image-zoom-overlay');
    var zoomContent = document.getElementById('image-zoom-content');
    var zoomClose = document.getElementById('image-zoom-close');

    if (!zoomOverlay || !zoomContent) return;

    var currentGroup = [];
    var currentIndex = 0;

    // Ensure Nav Buttons exist in zoomOverlay
    var zoomPrev = document.getElementById('zoom-prev');
    var zoomNext = document.getElementById('zoom-next');

    if (!zoomPrev) {
        zoomPrev = document.createElement('button');
        zoomPrev.id = 'zoom-prev';
        zoomPrev.className = 'lightbox-nav-btn zoom-prev';
        zoomPrev.innerHTML = '&#10094;';
        zoomOverlay.appendChild(zoomPrev);
    }
    if (!zoomNext) {
        zoomNext = document.createElement('button');
        zoomNext.id = 'zoom-next';
        zoomNext.className = 'lightbox-nav-btn zoom-next';
        zoomNext.innerHTML = '&#10095;';
        zoomOverlay.appendChild(zoomNext);
    }

    function updateNav() {
        if (currentGroup.length <= 1) {
            zoomPrev.style.display = 'none';
            zoomNext.style.display = 'none';
        } else {
            zoomPrev.style.display = 'flex';
            zoomNext.style.display = 'flex';
        }
    }

    function showItem(index) {
        if (index < 0) index = currentGroup.length - 1;
        if (index >= currentGroup.length) index = 0;
        currentIndex = index;

        var item = currentGroup[currentIndex];
        var src = item.getAttribute('href') || item.getAttribute('data-src');

        zoomContent.src = src;
        updateNav();
    }

    // Delegate clicks to handle dynamic content or static items
    document.addEventListener('click', function (e) {
        var target = e.target.closest('.gallery-item.lightbox, .product-image-link, .gallery-link, .zoom-image-trigger');
        if (!target) return;

        // If it's a .product-image-link and NOT inside a modal/lightbox, we might want to let script.v2.js handle the AJAX modal.
        // BUT the user said "clicking on photo launches gallery".
        // In detail.php, the trigger is: <a href="#" id="zoom-image-trigger" ... onclick="openProductLightbox(); return false;">
        // openProductLightbox() clicks the first .gallery-item.lightbox.

        // If the target is the ZOOM trigger or a gallery item, handle here.
        if (target.id === 'zoom-image-trigger' || target.classList.contains('gallery-item')) {
            e.preventDefault();
            e.stopPropagation();

            // Find siblings in the same gallery
            var groupAttr = target.getAttribute('data-gallery') || 'product-gallery';
            currentGroup = [].slice.call(document.querySelectorAll('[data-gallery="' + groupAttr + '"]'));

            if (currentGroup.length === 0) currentGroup = [target];

            currentIndex = currentGroup.indexOf(target);
            if (currentIndex === -1) currentIndex = 0;

            openGallery();
            showItem(currentIndex);
        }
    });

    function openGallery() {
        zoomOverlay.classList.add('is-visible');
        document.body.classList.add('zoom-open');
        document.body.classList.add('gallery-active');
    }

    function closeGallery() {
        zoomOverlay.classList.remove('is-visible');
        document.body.classList.remove('zoom-open');
        document.body.classList.remove('gallery-active');
        zoomContent.src = '';
    }

    // Nav Events
    zoomPrev.addEventListener('click', function (e) { e.stopPropagation(); showItem(currentIndex - 1); });
    zoomNext.addEventListener('click', function (e) { e.stopPropagation(); showItem(currentIndex + 1); });
    if (zoomClose) zoomClose.addEventListener('click', function (e) { e.stopPropagation(); closeGallery(); });

    zoomOverlay.addEventListener('click', function (e) {
        if (e.target === zoomOverlay) {
            closeGallery();
        }
    });

    // Keyboard Events
    document.addEventListener('keyup', function (e) {
        if (!zoomOverlay.classList.contains('is-visible')) return;

        if (e.key === 'Escape' || e.keyCode === 27) {
            e.preventDefault();
            e.stopPropagation();
            closeGallery();
        }
        if (e.key === 'ArrowLeft') showItem(currentIndex - 1);
        if (e.key === 'ArrowRight') showItem(currentIndex + 1);
    }, true); // Use capture phase to ensure we catch it before global script.v2.js listeners
});
