// assets/admin-toast.js
console.log('DEBUG: admin-toast.js loaded');

// Ensure container exists
if (!document.getElementById('toast-container')) {
    const container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
}

const Toast = {
    // Icons
    icons: {
        success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
        error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>',
        info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
        loading: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="2" x2="12" y2="6"></line><line x1="12" y1="18" x2="12" y2="22"></line><line x1="4.93" y1="4.93" x2="7.76" y2="7.76"></line><line x1="16.24" y1="16.24" x2="19.07" y2="19.07"></line><line x1="2" y1="12" x2="6" y2="12"></line><line x1="18" y1="12" x2="22" y2="12"></line><line x1="4.93" y1="19.07" x2="7.76" y2="16.24"></line><line x1="16.24" y1="7.76" x2="19.07" y2="4.93"></line></svg>'
    },

    show(message, type = 'info', duration = 3000) {
        const container = document.getElementById('toast-container');

        // Auto-dismiss loading toasts if showing any other message
        if (type !== 'loading') {
            const loadingToasts = container.querySelectorAll('.toast-loading');
            loadingToasts.forEach(t => t.remove());
        }

        const el = document.createElement('div');
        el.className = `toast toast-${type}`;
        el.innerHTML = `
            <div class="toast-icon">${this.icons[type] || this.icons.info}</div>
            <div class="toast-message">${message}</div>
            <button class="toast-close" onclick="this.parentElement.remove()">×</button>
        `;

        container.appendChild(el);

        // Trigger animation
        requestAnimationFrame(() => {
            el.classList.add('visible');
        });

        // Auto remove
        if (duration > 0 && type !== 'loading') {
            setTimeout(() => {
                this.remove(el);
            }, duration);
        }

        return el;
    },

    success(msg) { return this.show(msg, 'success'); },
    error(msg) { return this.show(msg, 'error', 5000); },
    info(msg) { return this.show(msg, 'info'); },
    loading(msg) { return this.show(msg, 'loading', 0); },

    remove(el) {
        if (!el) return;
        el.classList.remove('visible');
        el.addEventListener('transitionend', () => {
            el.remove();
        });
    }
};

window.showToast = function (msg, type, duration) { return Toast.show(msg, type, duration); };
window.Toast = Toast;
