/**
 * analytics.js
 * Handles loading of tracking scripts and event tracking.
 * Depends on window.shopSettings being populated in index.php
 */

(function () {
    const settings = window.shopSettings || {};

    // Helper to load scripts
    function loadScript(src, async = true) {
        const script = document.createElement('script');
        script.src = src;
        script.async = async;
        document.head.appendChild(script);
    }

    // GA4 Configuration and Enhanced Measurement
    if (settings.ga4_id) {
        // Prepare config parameters for Dynamic Remarketing
        const configParams = {
            'cookie_flags': 'SameSite=None;Secure'
        };

        if (settings.page_type) {
            configParams.page_type = settings.page_type;
            configParams.ecomm_pagetype = settings.page_type;
        }

        if (settings.product_id) {
            configParams.product_id = settings.product_id;
            configParams.ecomm_prodid = settings.product_id;
        }

        // Update config with dynamic parameters (initial config is in head)
        if (typeof gtag === 'function') {
            gtag('config', settings.ga4_id, configParams);
        }


        // Trigger view_item event for product pages
        if (settings.page_type === 'product' && settings.product_id) {
            if (typeof gtag === 'function') {
                gtag('event', 'view_item', {
                    currency: 'CZK',
                    items: [{
                        item_id: settings.product_id,
                        item_name: document.title.split('|')[0].trim(),
                    }]
                });
            }
            
            // Seznam Event Measurement (SEM): ViewContent
            if (settings.sem_id) {
                const getPrice = function(selector) {
                    const el = document.querySelector(selector);
                    if (!el) return 0;
                    return parseFloat(el.innerText.replace(/[^0-9,.-]/g, '').replace(',', '.')) || 0;
                };
                
                const semPayload = {
                    content_type: 'product',
                    currency: 'CZK',
                    contents: [{
                        id: settings.product_id,
                        content_name: document.title,
                        unit_price: getPrice('.product-price-vat')
                    }]
                };

                let semAttempts = 0;
                const trySem = setInterval(() => {
                    if (typeof window.SEM === 'function') {
                        clearInterval(trySem);
                        window.SEM('track', 'ViewContent', semPayload);
                    } else if (semAttempts > 50) {
                        clearInterval(trySem);
                    }
                    semAttempts++;
                }, 100);
            }
        }
    }

    // 2. Sklik Retargeting
    if (settings.sklik_id || window.seznam_retargeting_id) {
        const checkConsentAndLoadSklik = () => {
            let storedData = localStorage.getItem('cookie_consent');
            if (!storedData) {
                const cookieValue = document.cookie.split('; ').find(row => row.startsWith('cookie_consent='));
                if (cookieValue) storedData = decodeURIComponent(cookieValue.split('=')[1]);
            }

            const stored = JSON.parse(storedData || '{}');
            const isMarketingConsented = (stored.marketing === true || stored.marketing === 'true' || stored.marketing == 1);
            const isAnalyticsConsented = (stored.analytics === true || stored.analytics === 'true' || stored.analytics == 1);
            const consentValue = typeof stored.marketing !== 'undefined' ? (isMarketingConsented ? 1 : 0) : -1;
            const sklikId = parseInt(settings.sklik_id) || window.seznam_retargeting_id;

            // Initialize Sklik objects
            window.rc = window.rc || {};
            window.rc.retargeting = window.rc.retargeting || function () { (window.rc.retargeting.q = window.rc.retargeting.q || []).push(arguments); };

            window.seznam_retargeting_2 = window.seznam_retargeting_2 || {};
            window.seznam_retargeting_2.id = sklikId;

            window.sznConsent = window.sznConsent || {};
            if (consentValue !== -1) {
                window.seznam_retargeting_2.consent = consentValue;
                window.seznam_retargeting_consent = consentValue;
                window.sznConsent.marketing = isMarketingConsented;
            }

            console.log('Sklik Consent Status (analytics.js):', consentValue);

            // Prepare Retargeting Data
            if (consentValue !== -1) {
                if (settings.page_type) {
                    window.seznam_retargeting_2.rtype = settings.page_type === 'product' ? 'offerdetail' : settings.page_type;
                    window.seznam_retargeting_2.content = window.seznam_retargeting_2.content || {};

                    if (settings.product_id) {
                        const ids = Array.isArray(settings.product_id) ? settings.product_id : [settings.product_id];
                        window.seznam_retargeting_2.content.item = ids.map(id => ({ "id": id }));
                    }

                    if (settings.category) {
                        window.seznam_retargeting_2.content.categorytext = settings.category;
                    }
                }

                // Push to queue
                window.rc.retargeting(window.seznam_retargeting_2);
                console.log('Sklik Queue Push:', window.seznam_retargeting_2);
            }

            // Load Sklik script anyway, it will read the queue or global objects
            if (!document.querySelector('script[src*="retargeting.js"]')) {
                loadScript('https://c.imedia.cz/js/retargeting.js');
            }
        };

        // Check on load
        checkConsentAndLoadSklik();
    }

    // 2.1 Sklik Inquiry Event
    window.trackSklikInquiry = function () {
        const consent = JSON.parse(localStorage.getItem('cookie_consent') || 'null');
        const convId = settings.sklik_conversion_id || settings.sklik_id;
        if (consent && consent.marketing && convId) {
            var iframe = document.createElement('iframe');
            iframe.width = "1"; iframe.height = "1"; iframe.frameBorder = "0"; iframe.scrolling = "no";
            iframe.style.display = "none";
            iframe.src = `//c.imedia.cz/checkConversion?c=${convId}&color=ffffff&v=0`;
            document.body.appendChild(iframe);
            console.log('Sklik Inquiry Conversion Tracked with ID:', convId);
        }
    };

    // 2.2 Google Ads Inquiry Event
    window.trackGadsInquiry = function () {
        if (settings.gads_id && settings.gads_label) {
            let gid = settings.gads_id;
            if (!gid.startsWith('AW-')) gid = 'AW-' + gid;
            if (typeof gtag === 'function') {
                gtag('event', 'conversion', {
                    'send_to': gid + '/' + settings.gads_label,
                    'value': 0.0,
                    'currency': 'CZK'
                });
                console.log('Google Ads Inquiry Conversion Sent:', gid + '/' + settings.gads_label);
            }
        }
    };

    // 3. Event Listeners for generate_lead
    document.addEventListener('DOMContentLoaded', () => {
        // Track clicks using event delegation on document body to handle dynamic elements as well
        document.body.addEventListener('click', (e) => {
            const telLink = e.target.closest('a[href^="tel:"]');
            if (telLink) {
                if (typeof gtag === 'function') {
                    gtag('event', 'generate_lead', {
                        'event_category': 'Contact',
                        'event_label': 'Phone Call',
                        'value': 0
                    });
                }
                if (settings.sem_id && typeof window.SEM === 'function') {
                    window.SEM('track', 'Lead', { currency: 'CZK', value: 0 });
                }
                if (typeof window.trackGadsInquiry === 'function') {
                    window.trackGadsInquiry();
                }
            }

            const mailtoLink = e.target.closest('a[href^="mailto:"]');
            if (mailtoLink) {
                if (typeof gtag === 'function') {
                    gtag('event', 'generate_lead', {
                        'event_category': 'Contact',
                        'event_label': 'Email Click',
                        'value': 0
                    });
                }
                if (settings.sem_id && typeof window.SEM === 'function') {
                    window.SEM('track', 'Lead', { currency: 'CZK', value: 0 });
                }
                if (typeof window.trackGadsInquiry === 'function') {
                    window.trackGadsInquiry();
                }
            }
        });
    });

    // 5. Meta Pixel: ViewContent
    if (settings.fb_pixel_id && settings.page_type === 'product' && settings.product_id && typeof fbq === 'function') {
        fbq('track', 'ViewContent', {
            content_ids: [settings.product_id],
            content_type: 'product',
            contents: [{ id: settings.product_id, quantity: 1 }],
            value: (function () {
                const p = document.querySelector('.product-price-vat');
                return p ? parseFloat(p.innerText.replace(/[^\d]/g, '')) : 0;
            })(),
            currency: 'CZK'
        });
    }

    // 6. Meta Pixel & GA4: BEGIN CHECKOUT
    document.body.addEventListener('click', function (e) {
        if (e.target.matches('.btn-checkout') || e.target.closest('.btn-checkout')) {
            const totalEl = document.getElementById('final-price');
            let val = 0;
            if (totalEl) {
                val = parseFloat(totalEl.textContent.replace(/[^\d,]/g, '').replace(',', '.'));
            }

            if (typeof gtag === 'function') {
                gtag('event', 'begin_checkout', {
                    currency: 'CZK',
                    value: val,
                    items: []
                });
            }

            if (typeof fbq === 'function') {
                fbq('track', 'InitiateCheckout', {
                    value: val,
                    currency: 'CZK'
                });
            }

            if (settings.sem_id) {
                let semAttempts = 0;
                const trySem = setInterval(() => {
                    if (typeof window.SEM === 'function') {
                        clearInterval(trySem);
                        window.SEM('track', 'InitiateCheckout', {
                            currency: 'CZK',
                            value: parseFloat((val / 1.21).toFixed(2)),
                            content_type: 'product'
                        });
                    } else if (semAttempts > 50) {
                        clearInterval(trySem);
                    }
                    semAttempts++;
                }, 100);
            }
        }
    });

})();
