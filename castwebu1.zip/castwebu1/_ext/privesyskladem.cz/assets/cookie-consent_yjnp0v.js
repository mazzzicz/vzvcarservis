/**
 * cookie-consent.js
 * Handles cookie consent banner, storage, and GTM consent updates.
 */

(function () {
    const COOKIE_NAME = 'cookie_consent';
    const CONSENT_DEFAULTS = {
        necessary: true,
        analytics: false,
        marketing: false
    };

    function getConsent() {
        // Try localStorage first
        let stored = localStorage.getItem(COOKIE_NAME);
        if (stored) {
            try {
                return JSON.parse(stored);
            } catch (e) {
                console.error('Error parsing consent from localStorage', e);
            }
        }

        // Try cookie fallback
        const nameEQ = COOKIE_NAME + "=";
        const ca = document.cookie.split(';');
        for (let i = 0; i < ca.length; i++) {
            let c = ca[i].trim();
            if (c.indexOf(nameEQ) === 0) {
                try {
                    return JSON.parse(c.substring(nameEQ.length, c.length));
                } catch (e) {
                    console.error('Error parsing consent from cookie', e);
                }
            }
        }
        return null;
    }

    function saveConsent(consent) {
        const consentStr = JSON.stringify(consent);

        // 1. Save to localStorage
        localStorage.setItem(COOKIE_NAME, consentStr);

        // 2. Save to HTTP Cookie (1 year)
        const date = new Date();
        date.setFullYear(date.getFullYear() + 1);

        // Get base domain to share across subdomains if possible
        let domain = window.location.hostname;
        if (domain.indexOf('.') !== -1) {
            const parts = domain.split('.');
            if (parts.length > 2) {
                domain = parts.slice(-2).join('.');
            }
        }

        document.cookie = COOKIE_NAME + "=" + consentStr +
            "; expires=" + date.toUTCString() +
            "; path=/; domain=." + domain +
            "; SameSite=Lax";

        updateGtagConsent(consent);
        hideBanner();
    }

    function updateGtagConsent(consent) {
        const isMarketingGranted = (consent.marketing === true || consent.marketing === 'true' || consent.marketing == 1);
        const isAnalyticsGranted = (consent.analytics === true || consent.analytics === 'true' || consent.analytics == 1);

        if (typeof gtag === 'function') {
            gtag('consent', 'update', {
                'analytics_storage': isAnalyticsGranted ? 'granted' : 'denied',
                'ad_storage': isMarketingGranted ? 'granted' : 'denied',
                'ad_user_data': isMarketingGranted ? 'granted' : 'denied',
                'ad_personalization': isMarketingGranted ? 'granted' : 'denied'
            });
            console.log('GTM Consent Updated:', consent);
        }

        // Seznam Event Measurement (SEM) Consent Update
        let semAttempts = 0;
        const trySem = setInterval(() => {
            if (typeof window.SEM === 'function') {
                clearInterval(trySem);
                window.SEM('updateConsent', {
                    'ad_storage': isMarketingGranted ? 'granted' : 'denied',
                    'ad_user_data': isMarketingGranted ? 'granted' : 'denied',
                    'ad_personalization': isMarketingGranted ? 'granted' : 'denied',
                    'analytics_storage': isAnalyticsGranted ? 'granted' : 'denied',
                    'functionality_storage': 'denied'
                });
            } else if (semAttempts > 50) {
                clearInterval(trySem);
            }
            semAttempts++;
        }, 100);

        // Seznam Sklik Consent Update
        window.rc = window.rc || {};
        window.rc.retargeting = window.rc.retargeting || function () { (window.rc.retargeting.q = window.rc.retargeting.q || []).push(arguments); };

        window.seznam_retargeting_2 = window.seznam_retargeting_2 || {};
        const sklikVal = isMarketingGranted ? 1 : 0;
        window.seznam_retargeting_2.consent = sklikVal;
        window.seznam_retargeting_consent = sklikVal;
        window.sznConsent = window.sznConsent || {};
        window.sznConsent.marketing = isMarketingGranted;

        // Push update to Sklik
        window.rc.retargeting({ id: window.seznam_retargeting_2.id || window.seznam_retargeting_id, consent: sklikVal });
    }

    function showBanner() {
        console.log('Attempting to show banner...');
        const banner = document.getElementById('cookie-consent-banner');
        if (banner) {
            // Update checkboxes based on current consent
            const currentConsent = getConsent();
            if (currentConsent) {
                const analyticsCheckbox = document.getElementById('cookie-analytics');
                const marketingCheckbox = document.getElementById('cookie-marketing');

                if (analyticsCheckbox) analyticsCheckbox.checked = currentConsent.analytics;
                if (marketingCheckbox) marketingCheckbox.checked = currentConsent.marketing;
            }

            // Force critical styles inline to bypass potential CSS issues
            banner.style.display = 'block';
            banner.style.visibility = 'visible';
            banner.style.opacity = '1';
            banner.style.position = 'fixed';
            banner.style.bottom = '0';
            banner.style.left = '0';
            banner.style.width = '100%';
            banner.style.zIndex = '2147483647'; // Max z-index
            banner.style.backgroundColor = '#fff';
            banner.style.boxShadow = '0 -2px 10px rgba(0, 0, 0, 0.1)';
            banner.style.boxSizing = 'border-box';

            console.log('Banner styles forced inline: block, fixed, bottom 0, z-index max');
        } else {
            console.error('Banner element NOT found in DOM');
        }
    }

    function hideBanner() {
        const banner = document.getElementById('cookie-consent-banner');
        if (banner) banner.style.display = 'none';
    }

    function init() {
        if (window.cookieConsentInitialized) {
            console.warn('Cookie Consent already initialized, skipping.');
            return;
        }
        window.cookieConsentInitialized = true;

        console.log('Cookie Consent Init');
        const currentConsent = getConsent();

        if (!currentConsent) {
            console.log('No consent found, showing banner defaults');
            // Default state: Denied (except necessary)
            updateGtagConsent(CONSENT_DEFAULTS);
            showBanner();
        } else {
            console.log('Consent found:', currentConsent);
            updateGtagConsent(currentConsent);
        }

        // Event Listeners
        const acceptAllBtn = document.getElementById('cookie-accept-all');
        if (acceptAllBtn) {
            acceptAllBtn.addEventListener('click', function () {
                console.log('Accept All Clicked');
                saveConsent({
                    necessary: true,
                    analytics: true,
                    marketing: true
                });
            });
        }

        const rejectAllBtn = document.getElementById('cookie-reject-all');
        if (rejectAllBtn) {
            rejectAllBtn.addEventListener('click', function () {
                console.log('Reject All Clicked');
                saveConsent({
                    necessary: true,
                    analytics: false,
                    marketing: false
                });
            });
        }

        const saveSettingsBtn = document.getElementById('cookie-save-settings');
        if (saveSettingsBtn) {
            saveSettingsBtn.addEventListener('click', function () {
                console.log('Save Settings Clicked');
                const analytics = document.getElementById('cookie-analytics').checked;
                const marketing = document.getElementById('cookie-marketing').checked;
                saveConsent({
                    necessary: true,
                    analytics: analytics,
                    marketing: marketing
                });
            });
        }

        const openSettingsBtn = document.getElementById('open-cookie-settings-footer');
        if (openSettingsBtn) {
            console.log('Cookie Settings Button Found');
            openSettingsBtn.addEventListener('click', function (e) {
                e.preventDefault();
                console.log('Cookie Settings Clicked');
                showBanner();
            });
        }

        const btnSettings = document.getElementById('open-cookie-settings-footer'); // Assuming this is the same button or a new one
        if (btnSettings) {
            btnSettings.addEventListener('click', function (e) {
                e.preventDefault();
                const banner = document.getElementById('cookie-consent-banner'); // Get banner inside listener
                if (banner) {
                    banner.style.display = 'flex'; // Changed from 'block' to 'flex' as per common practice for banners
                    banner.classList.add('visible'); // Added class for potential CSS transitions
                }
            });
        }
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
