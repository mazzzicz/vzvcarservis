/* assets/auth.js */

async function authFetch(action, data = {}) {
    const res = await fetch(`/api_auth.php?action=${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    return await res.json();
}

function showModal(id) {
    document.querySelectorAll('.auth-modal').forEach(m => m.style.display = 'none');
    document.getElementById('auth-overlay').style.display = 'block';
    document.getElementById(`modal-${id}`).style.display = 'block';
}

function closeAuthModals() {
    document.getElementById('auth-overlay').style.display = 'none';
    document.querySelectorAll('.auth-modal').forEach(m => m.style.display = 'none');
}

async function handleLogin(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    if (btn) btn.disabled = true;

    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    try {
        const json = await authFetch('login', { email, password });
        if (json.status === 'ok') {
            location.reload();
        } else {
            Toast.error(json.message);
        }
    } catch (err) {
        Toast.error('Chyba při komunikaci se serverem.');
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleRegister(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    if (btn) btn.disabled = true;

    const fullname = document.getElementById('reg-fullname').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;

    try {
        const json = await authFetch('register', { email, password, fullname });
        if (json.status === 'ok') {
            location.reload();
        } else {
            Toast.error(json.message);
        }
    } catch (err) {
        Toast.error('Chyba při komunikaci se serverem.');
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleResetRequest(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    if (btn && btn.disabled) return; // Prevent double trigger
    if (btn) btn.disabled = true;

    const email = document.getElementById('reset-email').value;
    try {
        const json = await authFetch('reset_request', { email });
        if (json.status === 'ok') {
            Toast.success(json.message);
            closeAuthModals();
        } else {
            Toast.error(json.message);
        }
    } catch (err) {
        Toast.error('Chyba při odesílání požadavku.');
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function handleResetComplete(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type="submit"]');
    if (btn) btn.disabled = true;

    const token = document.getElementById('reset-token').value;
    const password = document.getElementById('reset-new-password').value;

    try {
        const json = await authFetch('reset_complete', { token, password });
        if (json.status === 'ok') {
            Toast.success('Heslo bylo úspěšně změněno. Nyní se můžete přihlásit.');
            showModal('login');
        } else {
            Toast.error(json.message);
        }
    } catch (err) {
        Toast.error('Chyba při komunikaci se serverem.');
    } finally {
        if (btn) btn.disabled = false;
    }
}

async function logout() {
    const json = await authFetch('logout');
    if (json.status === 'ok') {
        const persistFields = ['f_email', 'f_phone', 'f_fullname', 'f_street', 'f_city', 'f_zip', 'f_ico', 'f_dic', 'pref_country', 'pref_zasilkovna_id', 'pref_zasilkovna_name', 'pref_dpd_id', 'pref_dpd_name'];
        persistFields.forEach(f => localStorage.removeItem(f));
        location.href = '/';
    }
}

async function openManageModal() {
    const json = await authFetch('get_profile');
    if (json.status !== 'ok') {
        showModal('login');
        return;
    }

    const u = json.user;
    document.getElementById('m-fullname').value = u.fullname || '';
    document.getElementById('m-phone').value = u.phone || '';
    document.getElementById('m-street').value = u.street || '';
    document.getElementById('m-city').value = u.city || '';
    document.getElementById('m-zip').value = u.zip || '';
    document.getElementById('m-house-number').value = u.billing_house_number || '';
    document.getElementById('m-country').value = u.billing_country || 'Česká republika';

    document.getElementById('m-company').value = u.company_name || '';
    document.getElementById('m-ico').value = u.ico || '';
    document.getElementById('m-dic').value = u.dic || '';

    // Delivery fields
    document.getElementById('m-d-name').value = u.delivery_name || '';
    document.getElementById('m-d-street').value = u.delivery_street || '';
    document.getElementById('m-d-house-number').value = u.delivery_house_number || '';
    document.getElementById('m-d-city').value = u.delivery_city || '';
    document.getElementById('m-d-zip').value = u.delivery_zip || '';
    document.getElementById('m-d-country').value = u.delivery_country || '';

    const mMarketing = document.getElementById('m-consent-marketing');
    if (mMarketing) mMarketing.checked = parseInt(u.marketing_consent) === 1;

    const mUserReadonly = document.getElementById('m-username-readonly');
    if (mUserReadonly) mUserReadonly.value = u.email || '';

    const badge = document.getElementById('user-group-badge');
    if (u.group_name) {
        badge.innerText = u.group_name;
        badge.style.display = 'block';
    } else {
        badge.style.display = 'none';
    }

    showModal('manage');

    // Auto-save setup
    const form = document.getElementById('form-profile');
    if (form) {
        form.querySelectorAll('input, select').forEach(el => {
            el.addEventListener('input', () => {
                clearTimeout(window.profileSaveTimer);
                window.profileSaveTimer = setTimeout(() => handleUpdateProfile(), 500);
            });
        });
    }
}

async function handleUpdateProfile(e) {
    if (e) e.preventDefault();
    const data = {
        fullname: document.getElementById('m-fullname').value,
        phone: document.getElementById('m-phone').value,
        street: document.getElementById('m-street').value,
        house_number: document.getElementById('m-house-number').value,
        city: document.getElementById('m-city').value,
        zip: document.getElementById('m-zip').value,
        country: document.getElementById('m-country').value,
        company_name: document.getElementById('m-company').value,
        ico: document.getElementById('m-ico').value,
        dic: document.getElementById('m-dic').value,
        // Delivery
        delivery_name: document.getElementById('m-d-name').value,
        delivery_street: document.getElementById('m-d-street').value,
        delivery_house_number: document.getElementById('m-d-house-number').value,
        delivery_city: document.getElementById('m-d-city').value,
        delivery_zip: document.getElementById('m-d-zip').value,
        delivery_country: document.getElementById('m-d-country').value
    };

    const json = await authFetch('update_profile', data);
    if (json.status !== 'ok') {
        console.error('Profile update failed:', json.message);
    }
}

// Old updateConsents removed (redefined below)

async function handleChangePassword(e) {
    e.preventDefault();
    const old_password = document.getElementById('m-old-pass').value;
    const new_password = document.getElementById('m-new-pass').value;

    const json = await authFetch('change_password', { old_password, new_password });
    if (json.status === 'ok') {
        showNotification('Heslo bylo změněno.');
        document.getElementById('m-old-pass').value = '';
        document.getElementById('m-new-pass').value = '';
    } else {
        showNotification(json.message, 'error');
    }
}

async function confirmDeleteAccount() {
    if (!confirm('Opravdu chcete nenávratně smazat svůj účet? Všechny vaše údaje budou odstraněny.')) return;

    const json = await authFetch('delete_account');
    if (json.status === 'ok') {
        showNotification('Účet byl smazán.');
        location.href = '/';
    }
}

// Global initialization
document.addEventListener('DOMContentLoaded', () => {
    // Check for reset token in URL
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('reset_token');
    if (token) {
        document.getElementById('reset-token').value = token;

        // Fetch email for prefilling to support password managers
        authFetch('verify_token', { token }).then(json => {
            if (json.status === 'ok') {
                const emailInput = document.getElementById('reset-finish-email');
                if (emailInput) {
                    emailInput.value = json.email;
                    // Optional: Make it readonly if you want to prevent changes
                    emailInput.readOnly = true;
                }
            } else {
                Toast.error('Neplatný nebo vypršený odkaz na obnovu hesla.');
            }
        });

        showModal('reset-password');

        // Clean up URL without refreshing
        const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
        window.history.pushState({ path: newUrl }, '', newUrl);
    }

    // Toggle user dropdown
    const userBtn = document.getElementById('user-icon-btn');
    if (userBtn) {
        userBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            const dropdown = userBtn.closest('.user-icon-wrapper').querySelector('.user-dropdown');
            dropdown.classList.toggle('active');
        });
    }

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
        const dropdowns = document.querySelectorAll('.user-dropdown.active');
        dropdowns.forEach(dropdown => {
            if (!dropdown.contains(e.target) && !e.target.closest('#user-icon-btn')) {
                dropdown.classList.remove('active');
            }
        });
    });

    // ESC key to close modals
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeAuthModals();
            const activeDropdowns = document.querySelectorAll('.user-dropdown.active');
            activeDropdowns.forEach(d => d.classList.remove('active'));
        }
    });
});

/* MY ORDERS LOGIC */
let searchTimer;
function debounceOrdersSearch() {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(openMyOrders, 500);
}

async function openMyOrders() {
    showModal('my-orders');
    const list = document.getElementById('orders-list');
    const load = document.getElementById('loading-orders');
    const searchVal = document.getElementById('orders-search') ? document.getElementById('orders-search').value : '';

    list.style.display = 'none';
    load.style.display = 'block';

    try {
        const json = await authFetch('get_orders', { search: searchVal });
        if (json.status === 'ok') {
            renderOrders(json.orders);
        } else {
            list.innerHTML = '<p style="text-align:center; color:red;">Chyba při načítání: ' + json.message + '</p>';
        }
    } catch (e) {
        list.innerHTML = '<p style="text-align:center; color:red;">Chyba spojení.</p>';
    }

    load.style.display = 'none';
    list.style.display = 'flex';
}

function renderOrders(orders) {
    const list = document.getElementById('orders-list');
    if (!orders || orders.length === 0) {
        list.innerHTML = '<p style="text-align:center; color:#666; padding:30px;">Žádné objednávky neodpovídají hledání.</p>';
        return;
    }

    let html = '';
    orders.forEach(o => {
        let imgs = '';
        if (o.items && o.items.length > 0) {
            o.items.forEach(i => {
                const src = i.image ? i.image : '/assets/no-image.png';
                imgs += `<img src="${src}" alt="prod" width="40" height="40" style="object-fit:cover; margin-right:5px; border-radius:4px;">`;
            });
        }

        const date = new Date(o.created_at).toLocaleDateString('cs-CZ');
        const stColor = o.status_color || '#888';
        const currency = o.currency_symbol || 'Kč';

        html += `
        <div class="order-item-card">
            <div class="o-info" onclick="openOrderDetail(${o.id})" style="flex:1;">
                <h3 style="margin:0 0 5px; font-size:1.1em; color:#000;">${o.order_number} <span class="o-status" style="background:${stColor}22; color:${stColor}; font-size:0.7em; padding:2px 6px; border-radius:4px; vertical-align:middle;">${o.status_name}</span></h3>
                <div class="o-meta" style="font-size:0.9em; color:#777;">${date}</div>
                <div class="o-preview-imgs" style="margin-top:8px; display:flex;">${imgs}</div>
            </div>
            <div class="o-right" style="text-align:right;">
                <div class="o-price" style="font-weight:bold; font-size:1.1em; margin-bottom:8px;">${parseFloat(o.total_price).toLocaleString('cs-CZ')} ${currency}</div>
                <div style="display:flex; gap:5px; justify-content:flex-end;">
                     <button onclick="triggerReorder(${o.id})" class="btn-detail-view" style="color:#28a745; border-color:#28a745;" title="Objednat znovu">↻</button>
                     <button onclick="openOrderDetail(${o.id})" class="btn-detail-view" title="Detail">Detail ➜</button>
                </div>
            </div>
        </div>`;
    });
    list.innerHTML = html;
}

let currentOrderId = 0;

async function openOrderDetail(oid) {
    currentOrderId = oid;
    showModal('order-detail');
    const content = document.getElementById('order-detail-content');
    const load = document.getElementById('loading-od');

    content.style.display = 'none';
    load.style.display = 'block';

    try {
        const json = await authFetch('get_order_detail', { id: oid });
        if (json.status === 'ok') {
            renderDetail(json.order);
            content.style.display = 'block';
        } else {
            showNotification(json.message, 'error');
            showModal('my-orders');
        }
    } catch (e) {
        showNotification('Chyba spojení', 'error');
        showModal('my-orders');
    }
    load.style.display = 'none';
}

function renderDetail(o) {
    document.getElementById('od-title').innerText = `Objednávka ${o.order_number}`;
    document.getElementById('od-date').innerText = new Date(o.created_at).toLocaleDateString('cs-CZ') + ' ' + new Date(o.created_at).toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' });

    const stEl = document.getElementById('od-status');
    stEl.innerText = o.status_name;
    stEl.style.backgroundColor = (o.status_color || '#888') + '20';
    stEl.style.color = o.status_color || '#888';

    const currency = o.currency_symbol || 'Kč';

    document.getElementById('od-price').innerText = parseFloat(o.total_price).toLocaleString('cs-CZ') + ' ' + currency;
    document.getElementById('od-shipping').innerText = o.shipping_method;
    document.getElementById('od-payment').innerText = o.payment_method;

    const list = document.getElementById('od-items-list');
    let html = '';
    o.items.forEach(i => {
        const src = i.image ? i.image : '/assets/no-image.png';
        html += `
        <div class="od-item-row">
            <img src="${src}" class="od-item-img">
            <div class="od-item-info">
                <a href="${i.product_slug}" target="_blank" class="od-item-name">${i.name}</a>
                <div class="od-item-meta">${i.quantity} ks &times; ${parseFloat(i.price_per_unit).toLocaleString('cs-CZ')} ${currency}</div>
            </div>
            <div class="od-item-price">${(i.quantity * i.price_per_unit).toLocaleString('cs-CZ')} ${currency}</div>
        </div>`;
    });
    list.innerHTML = html;

    // Check if reorder logic needs disabled products handling UI-wise? 
    // Backend handles it, but maybe warn if some are inactive? 
    // We'll rely on backend message.
}

async function triggerReorder(oid) {
    const targetId = oid || currentOrderId;
    if (!targetId) return;
    if (!confirm('Vložit položky z této objednávky znovu do košíku?')) return;

    const btn = document.getElementById('btn-reorder');
    btn.disabled = true;
    btn.innerText = 'Zpracovávám...';

    try {
        const json = await authFetch('reorder', { order_id: targetId });
        if (json.status === 'ok') {
            if (json.skipped.length > 0) {
                showNotification(json.message + '\n\nNěkteré položky již nejsou dostupné:\n' + json.skipped.join(', '), 'warning');
            } else {
                Toast.success(json.message);
            }
            location.href = '/pokladna'; // Redirect to checkout/cart
        } else {
            Toast.error(json.message);
        }
    } catch (e) {
        Toast.error('Chyba spojení');
    }
    btn.disabled = false;
    btn.innerText = 'Objednat znovu';
}

// --- CONSENT MANAGEMENT ---
function loadConsentsToModal() {
    // 1. Load from LocalStorage (Cookie Consent)
    const stored = localStorage.getItem('cookie_consent');
    let analytics = false;
    let marketing = false;

    if (stored) {
        try {
            const c = JSON.parse(stored);
            analytics = c.analytics;
            marketing = c.marketing;
        } catch (e) { }
    }

    const chkAnalytics = document.getElementById('m-consent-analytics');
    const chkMarketing = document.getElementById('m-consent-marketing');

    if (chkAnalytics) chkAnalytics.checked = analytics;
    if (chkMarketing) chkMarketing.checked = marketing;
}

async function updateConsents() {
    const btn = document.getElementById('btn-save-consents');
    const msg = document.getElementById('consent-save-msg');

    const analytics = document.getElementById('m-consent-analytics').checked;
    const marketing = document.getElementById('m-consent-marketing').checked;

    btn.disabled = true;
    btn.textContent = 'Ukládám...';

    // 1. Save to LocalStorage (Frontend logic for Cookies)
    const consentObj = {
        necessary: true,
        analytics: analytics,
        marketing: marketing
    };
    localStorage.setItem('cookie_consent', JSON.stringify(consentObj));

    // Update GTM/Gtag immediately if script is present
    if (typeof gtag === 'function') {
        gtag('consent', 'update', {
            'analytics_storage': analytics ? 'granted' : 'denied',
            'ad_storage': marketing ? 'granted' : 'denied',
            'ad_user_data': marketing ? 'granted' : 'denied',
            'ad_personalization': marketing ? 'granted' : 'denied'
        });
    }
    // Also hide banner if open
    const banner = document.getElementById('cookie-consent-banner');
    if (banner) banner.style.display = 'none';

    // 2. Save Marketing Consent to DB User Profile (if logged in)
    try {
        await authFetch('update_profile', {
            marketing_consent: marketing ? 1 : 0
        });
    } catch (e) {
        console.log('User profile sync skipped or failed');
    }

    setTimeout(() => {
        btn.disabled = false;
        btn.textContent = 'Uložit nastavení cookies';
        msg.textContent = 'Nastavení uloženo.';
        msg.style.color = 'green';
        setTimeout(() => msg.textContent = '', 3000);
    }, 500);
}

// Hook into openManageModal to load consents
const originalOpenManageCtx = window.openManageModal;
window.openManageModal = function () {
    if (typeof originalOpenManageCtx === 'function') originalOpenManageCtx();
    setTimeout(loadConsentsToModal, 100);
};

// --- AUTO OPEN MODAL ON LOAD ---
document.addEventListener('DOMContentLoaded', () => {
    // Check hash for #muj-ucet or URL/mypage
    // User requested: https://vakuovani.getup.cz/stranka/muj-ucet#
    if (window.location.href.indexOf('/stranka/muj-ucet') > -1 || window.location.hash === '#muj-ucet') {
        if (typeof showModal === 'function') { // Check if auth.js is loaded enough to have showModal
            // We need to know if logged in globally or specific function.
            // If we blindly call openManageModal, it might fail if user not logged in (logic often inside).
            // Let's rely on backend session check rendered in page or try.
            // Usually `openManageModal` logic checks. Or we check DOM existence of user dropdown.
            const userIcon = document.querySelector('.user-ribbon');
            if (userIcon) {
                setTimeout(openManageModal, 500);
            } else {
                setTimeout(() => showModal('login'), 500);
            }
        }
    }
});
