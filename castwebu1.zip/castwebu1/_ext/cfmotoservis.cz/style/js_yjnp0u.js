
var http2 = false; if(navigator.appName == "Microsoft Internet Explorer") {  http2 = new ActiveXObject("Microsoft.XMLHTTP");} else {  http2 = new XMLHttpRequest();} 

function replace2(term){
var keyCode = ('which' in event) ? event.which : event.keyCode;
if(keyCode>46 || keyCode==8){
if(term.length >2){
  //document.getElementById('ui-autocomplete ui-front ui-menu ui-widget ui-widget-content').style.visibility='hidden';
  //document.getElementById('searchresult').innerHTML = '<div class="loader"></div>';
  http2.open("POST", "/search.php?term="+term);
  http2.onreadystatechange=function() {if(http2.readyState == 4) {document.getElementById('content').innerHTML = http2.responseText; }}
  http2.send(null);
};
};};

function setCookie(cname, cvalue, exdays,domain) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*7));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires + ";domain="+domain+";path=/";
    
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

$(document).ready(function() {
    $(window).scroll(function() {
        if($(this).scrollTop() > 100){
            $('#goTop').stop().animate({
                top: '150px'    
                }, 500);
        }
        else{
            $('#goTop').stop().animate({
               top: '-100px'    
            }, 500);
        }
    });
    $('#goTop').click(function() {
        $('html, body').stop().animate({
           scrollTop: 0
        }, 500, function() {
           $('#goTop').stop().animate({
               top: '-100px'    
           }, 500);
        });
    });


});


  $(document).ready(function () {

  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.dropdown-trigger');
    M.Dropdown.init(elems, {
      hover: true, // Open on hover
      coverTrigger: false, // Ensures dropdown appears below trigger
      constrainWidth: false, // Allows custom width
      alignment: 'left' // Aligns to the left
    });
    document.getElementById('search-dropdown1').style.width = '60vw';
  });
  


    $(".search-button").click(function (event) {
      $("#search-dropdown").fadeIn(500);
      $("#search1").focus(); 
    });

    $(".dropdown-button").click(function (event) {
      event.stopPropagation(); // Prevent immediate closure
    });


    // Close dropdown when clicking the close button
    $(".close-dropdown").click(function () {
      $("#search-dropdown").fadeOut(500);
    });

    // Keep dropdown open when clicking inside it
    $("#search-dropdown").click(function (event) {
      event.stopPropagation(); // Prevents closing when clicking inside
    });

    // Close dropdown when clicking outside
    $(document).click(function (event) {
      if (!$(event.target).closest("#search-dropdown, .dropdown-button").length) {
        $("#search-dropdown").fadeOut(500);
      }
    });
  });



document.addEventListener('DOMContentLoaded', function() {
    const logoBlock = document.querySelector('.logavyrobci');
    if (!logoBlock) return;
    let lastScrollPosition = window.scrollY;
    let ticking = false; // Optimalizace výkonu
    
    window.addEventListener('scroll', function() {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                const currentScrollPosition = window.scrollY;
                
                if (currentScrollPosition > lastScrollPosition && currentScrollPosition > 50) {
                    logoBlock.classList.add('hide-on-scroll');
                } else {
                    logoBlock.classList.remove('hide-on-scroll');
                }
                
                lastScrollPosition = currentScrollPosition;
                ticking = false;
            });
            ticking = true;
        }
    });
});


document.addEventListener('DOMContentLoaded', function() {

    // Najdeme potřebné prvky na stránce
    const banner = document.getElementById('slide-in-banner');
    const closeBtn = document.querySelector('.close-banner-btn');

    // Pokud banner nebo tlačítko na stránce neexistuje, skript se ukončí
    if (!banner || !closeBtn) {
        console.error("Banner nebo zavírací tlačítko nebylo nalezeno.");
        return;
    }

    // Název klíče pro uložení informace do lokálního úložiště prohlížeče
    const storageKey = 'bannerClosedTimestamp';

    // Získáme časovou značku, kdy byl banner naposledy zavřen
    const closedTimestamp = localStorage.getItem(storageKey);

    // Aktuální čas v milisekundách
    const now = new Date().getTime();

    // 24 hodin v milisekundách (24 hodin * 60 minut * 60 sekund * 1000 milisekund)
    const twentyFourHours = 24 * 60 * 60 * 1000;

    // Funkce pro zobrazení banneru
    function showBanner() {
        // Po 2 sekundách od načtení stránky banner zobrazíme přidáním třídy 'show'
        setTimeout(() => {
            banner.classList.add('show');
        }, 2000); // 2000 ms = 2 sekundy zpoždění
    }

    // Zkontrolujeme, zda banner máme zobrazit
    // Podmínka:
    // 1. V úložišti není žádný záznam (banner ještě nebyl zavřen)
    // NEBO
    // 2. Od zavření už uplynulo více než 24 hodin
    if (!closedTimestamp || (now - closedTimestamp > twentyFourHours)) {
        showBanner();
    }

    // Přidáme posluchač události na kliknutí na zavírací tlačítko
    closeBtn.addEventListener('click', function() {
        // Skryjeme banner odebráním třídy 'show'
        banner.classList.remove('show');

        // Uložíme aktuální časovou značku do lokálního úložiště
        // Prohlížeč si to bude pamatovat i po zavření okna
        const clickTime = new Date().getTime();
        localStorage.setItem(storageKey, clickTime);
    });

    // Inicializace rotujících promo sliderů (v detailu i ve slide-in banneru)
    function initPromoSliders() {
        function setupSlider(containerSelector, slideSelector, dotSelector) {
            var sliders = document.querySelectorAll(containerSelector);
            sliders.forEach(function(slider) {
                var slides = slider.querySelectorAll(slideSelector);
                var dots = slider.querySelectorAll(dotSelector);
                if (slides.length <= 1) return;
                var currentIndex = 0;
                var interval = null;

                function goToSlide(index) {
                    slides[currentIndex].classList.remove('active');
                    if (dots[currentIndex]) dots[currentIndex].classList.remove('active');
                    currentIndex = (index + slides.length) % slides.length;
                    slides[currentIndex].classList.add('active');
                    if (dots[currentIndex]) dots[currentIndex].classList.add('active');
                }

                function startTimer() {
                    if (interval) clearInterval(interval);
                    interval = setInterval(function() {
                        goToSlide(currentIndex + 1);
                    }, 4000);
                }

                dots.forEach(function(dot, idx) {
                    dot.addEventListener('click', function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        goToSlide(idx);
                        startTimer();
                    });
                });

                slider.addEventListener('mouseenter', function() {
                    if (interval) clearInterval(interval);
                });
                slider.addEventListener('mouseleave', function() {
                    startTimer();
                });

                startTimer();
            });
        }

        setupSlider('.product-promo-slider', '.promo-slide', '.promo-dot');
        setupSlider('.banner-slider', '.banner-slide', '.banner-dot');
    }

    initPromoSliders();

});   