import '/editor/cookieconsent.umd.js';

const CAT_NECESSARY = "necessary";
const CAT_ANALYTICS = "analytics";
const CAT_ADVERTISEMENT = "advertisement";
const CAT_FUNCTIONALITY = "functionality";
const CAT_SECURITY = "security";

const SERVICE_AD_STORAGE = 'ad_storage'
const SERVICE_AD_USER_DATA = 'ad_user_data'
const SERVICE_AD_PERSONALIZATION = 'ad_personalization'
const SERVICE_ANALYTICS_STORAGE = 'analytics_storage'
const SERVICE_FUNCTIONALITY_STORAGE = 'functionality_storage'
const SERVICE_PERSONALIZATION_STORAGE = 'personalization_storage'
const SERVICE_SECURITY_STORAGE = 'security_storage'

// Define dataLayer and the gtag function.
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}

// Set default consent to 'denied' (this should happen before changing any other dataLayer)
gtag('consent', 'default', {
    [SERVICE_AD_STORAGE]: 'denied',
    [SERVICE_AD_USER_DATA]: 'denied',
    [SERVICE_AD_PERSONALIZATION]: 'denied',
    [SERVICE_ANALYTICS_STORAGE]: 'denied',
    [SERVICE_FUNCTIONALITY_STORAGE]: 'denied',
    [SERVICE_PERSONALIZATION_STORAGE]: 'denied',
    [SERVICE_SECURITY_STORAGE]: 'denied',
});

/** 
 * Update gtag consent according to the users choices made in CookieConsent UI
 */
function updateGtagConsent() {
    gtag('consent', 'update', {
        [SERVICE_ANALYTICS_STORAGE]: CookieConsent.acceptedService(SERVICE_ANALYTICS_STORAGE, CAT_ANALYTICS) ? 'granted' : 'denied',
        [SERVICE_AD_STORAGE]: CookieConsent.acceptedService(SERVICE_AD_STORAGE, CAT_ADVERTISEMENT) ? 'granted' : 'denied',
        [SERVICE_AD_USER_DATA]: CookieConsent.acceptedService(SERVICE_AD_USER_DATA, CAT_ADVERTISEMENT) ? 'granted' : 'denied',
        [SERVICE_AD_PERSONALIZATION]: CookieConsent.acceptedService(SERVICE_AD_PERSONALIZATION, CAT_ADVERTISEMENT) ? 'granted' : 'denied',
        [SERVICE_FUNCTIONALITY_STORAGE]: CookieConsent.acceptedService(SERVICE_FUNCTIONALITY_STORAGE, CAT_FUNCTIONALITY) ? 'granted' : 'denied',
        [SERVICE_PERSONALIZATION_STORAGE]: CookieConsent.acceptedService(SERVICE_PERSONALIZATION_STORAGE, CAT_FUNCTIONALITY) ? 'granted' : 'denied',
        [SERVICE_SECURITY_STORAGE]: CookieConsent.acceptedService(SERVICE_SECURITY_STORAGE, CAT_SECURITY) ? 'granted' : 'denied',
    });
}

CookieConsent.run({
    // See: https://cookieconsent.orestbida.com/reference/configuration-reference.html#guioptions
    // ...
    
    // Trigger consent update when user choices change
    onFirstConsent: () => {
        updateGtagConsent();
    },
    onConsent: () => {
        updateGtagConsent();
    },
    onChange: () => {
        updateGtagConsent();
    },

    // Configure categories and services
    categories: {
        [CAT_NECESSARY]: {
            enabled: true,  // this category is enabled by default
            readOnly: true,  // this category cannot be disabled
        },
        [CAT_ANALYTICS]: {
            autoClear: {
                cookies: [
                    {
                        name: /^_ga/,   // regex: match all cookies starting with '_ga'
                    },
                    {
                        name: '_gid',   // string: exact cookie name
                    }
                ]
            },
            // See: https://cookieconsent.orestbida.com/reference/configuration-reference.html#category-services
            services: {
                [SERVICE_ANALYTICS_STORAGE]: {
                    label: 'Je pro analytické účely, sledujeme například délku návštěvy.',
                }
            }
        },
        [CAT_ADVERTISEMENT]: {
services: {
            [SERVICE_AD_STORAGE]: {
                label: 'Povoluje ukládání (např. cookies) související s reklamou.',
            },
            [SERVICE_AD_USER_DATA]: {
                label: 'Nastavuje souhlas s odesíláním uživatelských dat Googlu pro reklamní účely.',
            },
            [SERVICE_AD_PERSONALIZATION]: {
                label: 'Nastavuje souhlas s personalizovanou reklamou.',
            },
        }
        },
        [CAT_FUNCTIONALITY]: {
            services: {
                [SERVICE_FUNCTIONALITY_STORAGE]: {
                    label: 'Enables storage that supports the functionality of the website or app e.g. language settings.',
                },
                [SERVICE_PERSONALIZATION_STORAGE]: {
                    label: 'Enables storage related to personalization e.g. video recommendations.',
                },
            }
        },
        [CAT_SECURITY]: {
            services: {
                [SERVICE_SECURITY_STORAGE]: {
                    label: 'Enables storage related to security such as authentication functionality, fraud prevention, and other user protection.',
                },
            }
        }
    },

    language: {
        default: 'cs',
        translations: {
            cs: {
                // See: https://support.google.com/tagmanager/answer/10718549?hl=en
                consentModal: {
                    title: 'Tyto stránky používají soubory cookie',
                    description: 'Tyto webové stránky používají základní soubory cookie k zajištění svého správného fungování a sledovací soubory cookie k pochopení toho, jak s nimi pracujete. Ty se nastavují pouze po udělení souhlasu.',
                    acceptAllBtn: 'Povolit všechny',
                    acceptNecessaryBtn: 'Pouze nezbytné',
                    showPreferencesBtn: 'Podrobné nastavení'
                },
                preferencesModal: {
                    title: 'Podrobné nastavení',
                    acceptAllBtn: 'Povolit všechny',
                    acceptNecessaryBtn: 'Pouze nezbytné',
                    savePreferencesBtn: 'Potvrdit aktuální výběr',
                    closeIconLabel: 'Zavřít',
                    sections: [
                        {
                            title: "Použití cookies",
                            description: "Používáme cookies k zajištění základních funkcí webu a ke zlepšení pohodlí uživatele."
                        },
                        {
                            title: "Nutně nezbytné cookies",
                            description: "Tyto cookies jsou nezbytné pro správné fungování webu. Například anonymní ověření uživatele.",
                            linkedCategory: CAT_NECESSARY,
                        },
                        {
                            title: "Analytické údaje",
                            description: 'Cookies používané pro analýzy pomáhají sbírat údaje, které umožňují službám pochopit, jak uživatelé danou službu používají. Díky těmto informacím mohou služby vylepšovat obsah a vyvíjet lepší funkce, které zlepšují zkušenost uživatele.',
                            linkedCategory: CAT_ANALYTICS,
                            cookieTable: {
                                headers: {
                                    name: "Název",
                                    domain: "Služba",
                                    description: "Popis",
                                    expiration: "Platnost"
                                },
                                body: [
                                    {
                                        name: "_ga",
                                        domain: "Google Analytics",
                                        description: "Cookie nastaven nástrojem <a href=\"https://business.safety.google/adscookies/\">Google Analytics</a>",
                                        expiration: "12 dní"
                                    },
                                    {
                                        name: "_gid",
                                        domain: "Google Analytics",
                                        description: "Cookie nastaven nástrojem <a href=\"https://business.safety.google/adscookies/\">Google Analytics</a>",
                                        expiration: "Do zavření stránky"
                                    }
                                ]
                            }
                        },
                        
                        {
                            title: "Reklamní údaje",
                            description: 'Marketingové cookies nám pomáhají personalizovat obsah a reklamy přímo pro vás a analyzovat návštěvnost.',
                            linkedCategory: CAT_ADVERTISEMENT,
cookieTable: {
            headers: {
                name: "Název",
                domain: "Služba / Doména",
                description: "Účel / Popis",
                expiration: "Platnost"
            },
            body: [
                 {
                    name: "IDE",
                    domain: "Google / DoubleClick.net",
                    description: "Cookie pro cílení a zobrazování reklam Google na webech třetích stran. Obsahuje ID uživatele a preferenční údaje. <a href=\"https://business.safety.google/adscookies/\">Více informací</a>",
                    expiration: "1 rok (v EU)"
                },
                {
                    name: "sid", 
                    domain: "Sklik (Seznam.cz)",
                    description: "Identifikační cookie reklamního systému Sklik (Seznam.cz) používaná pro retargeting (cílení reklamy na uživatele, kteří již web navštívili) a měření konverzí. <a href=\"https://o.seznam.cz/ochrana-udaju/\" target=\"_blank\">Více informací</a>",
                    expiration: "30 dní"
                },
                 {
                    name: "sznc",
                    domain: "Seznam.cz",
                    description: "Cookie společnosti Seznam.cz sloužící k obecnému rozpoznání uživatele napříč službami Seznamu, může být využita i pro reklamní účely. <a href=\"https://o.seznam.cz/ochrana-udaju/personalizace-obsahu-a-reklamy/\" target=\"_blank\">Více informací</a>",
                    expiration: "Cca 18 měsíců"
                },
                {
                    name: "_fbp",
                    domain: "Facebook (Meta) Pixel",
                    description: "Cookie používaná Facebookem (Meta) k doručování reklamních produktů, jako je real-time bidding od inzerentů třetích stran, a k měření konverzí. <a href=\"https://www.facebook.com/policies/cookies/\" target=\"_blank\">Více informací</a>",
                    expiration: "90 dní"
                },
                 {
                    name: "_fbc",
                    domain: "Facebook (Meta) Pixel",
                    description: "Obsahuje informace o posledním kliknutí na reklamu Facebook (Meta), pokud uživatel přišel na web přes ni. Používá se pro atribuci konverzí. <a href=\"https://www.facebook.com/policies/cookies/\" target=\"_blank\">Více informací</a>",
                    expiration: "90 dní"
                 },
                 { 
                    name: "MUID",
                    domain: "Microsoft / Bing Ads",
                    description: "Unikátní identifikátor uživatele používaný společností Microsoft napříč jejími doménami (včetně Bing) pro personalizaci a cílení reklamy. <a href='https://privacy.microsoft.com/cs-cz/privacystatement' target='_blank'>Více informací</a>",
                    expiration: "1 rok"
                },
                { 
                    name: "_uetvid",
                    domain: "Microsoft / Bing Ads",
                    description: "Cookie univerzálního sledování událostí (UET) od Microsoft Advertising. Ukládá unikátní ID návštěvníka pro sledování konverzí a tvorbu remarketingových seznamů. <a href='https://about.ads.microsoft.com/cs-cz/resources/policies/microsoft-advertising-agreement' target='_blank'>Více informací</a>",
                    expiration: "1 rok"
                },
                 { 
                    name: "_uetsid",
                    domain: "Microsoft / Bing Ads",
                    description: "Cookie univerzálního sledování událostí (UET) od Microsoft Advertising. Identifikuje unikátní relaci (návštěvu) uživatele na webu. <a href='https://about.ads.microsoft.com/cs-cz/resources/policies/microsoft-advertising-agreement' target='_blank'>Více informací</a>",
                    expiration: "30 minut"
                 }
            ]
        }
                        }                        
                        
                        
                    ]
                }
            }
        }
    },

    guiOptions: {
        consentModal: {
            layout: 'box wide',
            position: 'middle center',
            flipButtons: false,
            equalWeightButtons: true
        },
        preferencesModal: {
            layout: 'box',
            // position: 'left right',
            flipButtons: false,
            equalWeightButtons: true
        }
    }
});